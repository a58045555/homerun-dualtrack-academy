# 小小探索學院：接手須知

先讀 handoff/PROJECT_HANDOFF.md、handoff/STATUS.json。這是一個既有網站的維護任務，使用者重視手機／平板能直接操作，不要重新做一個不同網址的網站。

## 啟動與驗證
- 純 HTML/CSS/JavaScript，沒有 package.json、不需 npm install，無後端或資料庫。
- 在此目錄執行 node preview.cjs，開啟 http://127.0.0.1:8765/。
- node handoff/VERIFY_PACKAGE.cjs：確認交接快照完整性；修改檔案後雜湊不符是預期結果。
- node run-checks.cjs --quick：年級／核心回歸、續作、已知平板語法相容性。
- node run-checks.cjs：完整離線測試。
- 預覽已啟動後執行 node run-checks.cjs --http：靜態資源檢查。
- verify-chinese-source.cjs 會連網並更新教材證據，只有需要重新核對來源時才執行。
- 所有命令從此 project 目錄執行。交接測試使用 Node 24.19.0；測試不讀取真實瀏覽器的孩子資料。

## 不可在未經使用者要求下改掉的行為
- 名稱：小小探索學院。四種風格：棒球、太空探險、公主城堡、可愛動物；舊配色已移除。
- 九九乘法完整1～9、81組，全混合且獨立於數學難度，不因低年級而刪掉。
- 無帳號、免費；不加贊助、付款、訂閱、Apple上架工作或雲端登入。
- 忘記家長密碼使用本機加法驗證；這是防誤入機制，不是雲端身分驗證。
- 多位孩子資料分開；不要清除或更名既有儲存鍵，也不要為除錯要求先清除網站資料。
- 保留啟動說明、家長區、紙上作答的播音聽寫、科學先學再練、太空課程與中斷續作。
- 國語二下目前是原創先修；不得標成已核對的115康軒課文、生字或圈詞。

## 程式結構提醒
assets/app.js 是大型 IIFE，許多函式在檔案後半段被重新指定。修改前找最後生效版本，尤其 generateQuestions、storyQuestion、calcQuestion、lineupQuestion、render、navigate、start、switchPlayer 和 visibleModes。
applyWorld 會改共享題庫；單純換風格不應改動國語、注音、英文、科學的語意或正解。年級入口集中在 practiceQuestions／effectiveLevel／canPractice。
app 底部有續作與 render/navigate 包裝；不要只改前面的同名函式而漏掉包裝。

## 資料與教材
保留既有 localStorage 鍵與 IndexedDB 錄音；資料損壞時保留原文，存檔失敗時顯示提示。
續作、答題和錯題排程一起保存，整回合完成只記一次。恢復後不自動播音、跳題或重複排程。
修改題庫時人工審查正解、解析與干擾選項；artifacts/curriculum-reviewed-content.json 的雜湊是內容稽核紀錄，不能只重算雜湊來掩蓋未審核的變更。

## 合作與發布
遵循 handoff/COORDINATION.md。ZIP沒有Git歷史，來源碼快照與遠端已部署程式一致；新增的交接文件與 run-checks.cjs 尚未提交遠端。
需要推送時使用新的 Git checkout／分支，先核對遠端 main，再比較變更。發布後必須確認正式網址的 academy-release 與實際檔案，而非只看到提交成功就宣稱已上線。
Vercel既有連線曾回403：可維持GitHub自動部署，但手動存取是否可用須重新驗證，不要在程式中放憑證或擅自變更團隊／權限。
