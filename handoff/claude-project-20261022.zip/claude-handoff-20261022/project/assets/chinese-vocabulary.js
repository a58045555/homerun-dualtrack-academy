// Names and curriculum classification from Ministry of Education Education Cloud, checked 2026-10-20.
window.HOMERUN_CHINESE_VOCAB={
  "year": 115,
  "semester": "upper",
  "source": "https://pedia.cloud.edu.tw/Bookmark/Textword?category=國語&degree=2&press=康軒版&year=115_1",
  "lessons": {
    "upper-01": {
      "characters": [
        "年",
        "希",
        "望",
        "坐",
        "位",
        "本",
        "淡",
        "書",
        "老",
        "師",
        "以",
        "為",
        "故",
        "用",
        "力",
        "只",
        "現",
        "還"
      ],
      "recognition": [
        "聲",
        "矮"
      ],
      "words": [
        "學年",
        "希望",
        "位子",
        "課本",
        "淡淡",
        "書香",
        "老師",
        "以前",
        "大聲",
        "成為",
        "故事",
        "用力",
        "現在"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150101"
    },
    "upper-02": {
      "characters": [
        "全",
        "蛋",
        "煎",
        "圓",
        "番",
        "茄",
        "切",
        "輪",
        "司",
        "夾",
        "吐",
        "中",
        "方",
        "城",
        "堡",
        "接",
        "畫",
        "臉"
      ],
      "recognition": [
        "餐",
        "醬"
      ],
      "words": [
        "早餐",
        "全家",
        "番茄",
        "輪子",
        "起司",
        "吐司",
        "四四方方",
        "城堡",
        "接著",
        "番茄醬",
        "笑臉"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150102"
    },
    "upper-03": {
      "characters": [
        "巷",
        "叔",
        "貓",
        "屋",
        "捧",
        "蝴",
        "蝶",
        "忙",
        "娶",
        "娘",
        "黃",
        "筆",
        "打",
        "扮",
        "樣",
        "越",
        "美",
        "麗"
      ],
      "recognition": [
        "牆",
        "模"
      ],
      "words": [
        "叔叔",
        "捧花",
        "蝴蝶",
        "新娘",
        "彩筆",
        "打扮",
        "模樣",
        "美麗"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150103"
    },
    "upper-04": {
      "characters": [
        "運",
        "動",
        "飄",
        "熱",
        "鬧",
        "舞",
        "哇",
        "往",
        "容",
        "步",
        "汗",
        "腳",
        "協",
        "聲",
        "河",
        "氣",
        "最",
        "可"
      ],
      "recognition": [
        "賽",
        "拔"
      ],
      "words": [
        "運動會",
        "熱鬧",
        "大會舞",
        "笑容",
        "跑步",
        "比賽",
        "汗水",
        "協力",
        "拔河",
        "力氣",
        "最後"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150104"
    },
    "upper-05": {
      "characters": [
        "竹",
        "籃",
        "鄉",
        "南",
        "暑",
        "假",
        "帶",
        "等",
        "跨",
        "划",
        "吹",
        "邊",
        "叫",
        "原",
        "近",
        "捕",
        "活",
        "識"
      ],
      "recognition": [
        "碗",
        "轉"
      ],
      "words": [
        "家鄉",
        "越南",
        "暑假",
        "碗公",
        "划船",
        "轉動",
        "一邊",
        "叫好",
        "原本",
        "近海",
        "捕魚",
        "活動",
        "認識"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150105"
    },
    "upper-06": {
      "characters": [
        "鎮",
        "餅",
        "節",
        "因",
        "此",
        "進",
        "排",
        "遠",
        "色",
        "愛",
        "月",
        "乾",
        "甜",
        "客",
        "買",
        "親",
        "如",
        "意"
      ],
      "recognition": [
        "柿",
        "埔"
      ],
      "words": [
        "小鎮",
        "因此",
        "走進",
        "金黃色",
        "可愛",
        "風乾",
        "遊客",
        "親朋好友",
        "如意"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150106"
    },
    "upper-07": {
      "characters": [
        "衣",
        "胖",
        "針",
        "簡",
        "單",
        "聰",
        "明",
        "臣",
        "敢",
        "東",
        "西",
        "直",
        "棒",
        "街",
        "滿",
        "眼",
        "哪",
        "思"
      ],
      "recognition": [
        "裳",
        "慌"
      ],
      "words": [
        "衣裳",
        "簡單",
        "聰明",
        "大臣",
        "不敢",
        "東西",
        "慌張",
        "一直",
        "大街",
        "滿街",
        "左思右想"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150107"
    },
    "upper-08": {
      "characters": [
        "渴",
        "烏",
        "喝",
        "瓶",
        "法",
        "森",
        "林",
        "物",
        "旅",
        "行",
        "午",
        "裝",
        "許",
        "石",
        "難",
        "忘",
        "哈",
        "但"
      ],
      "recognition": [
        "熊",
        "鴉"
      ],
      "words": [
        "口渴",
        "烏鴉",
        "瓶子",
        "方法",
        "森林",
        "動物",
        "旅行",
        "中午",
        "許多",
        "石頭",
        "難道",
        "但是"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150108"
    },
    "upper-09": {
      "characters": [
        "象",
        "操",
        "粗",
        "腿",
        "柱",
        "砍",
        "幾",
        "部",
        "搖",
        "沖",
        "首",
        "牽",
        "沉",
        "少",
        "沿",
        "然",
        "紀",
        "竟"
      ],
      "recognition": [
        "曹",
        "秤"
      ],
      "words": [
        "大象",
        "曹操",
        "粗大",
        "柱子",
        "部分",
        "搖頭",
        "首先",
        "下沉",
        "多少",
        "然後",
        "年紀",
        "竟然"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150109"
    },
    "upper-10": {
      "characters": [
        "雪",
        "梨",
        "夜",
        "卻",
        "冷",
        "冬",
        "臺",
        "季",
        "相",
        "反",
        "煙",
        "火",
        "待",
        "雖",
        "春",
        "貨",
        "期",
        "飯"
      ],
      "recognition": [
        "灣",
        "綻"
      ],
      "words": [
        "雪梨",
        "冬天",
        "臺灣",
        "季節",
        "相反",
        "煙火",
        "等待",
        "綻放",
        "雖然",
        "春節",
        "年貨",
        "期待",
        "年夜飯"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150110"
    },
    "upper-11": {
      "characters": [
        "皮",
        "具",
        "飛",
        "者",
        "洋",
        "寒",
        "北",
        "嘴",
        "伸",
        "飽",
        "沙",
        "急",
        "服",
        "站",
        "翅",
        "膀",
        "充",
        "念"
      ],
      "recognition": [
        "戴",
        "扁"
      ],
      "words": [
        "面具",
        "舞者",
        "海洋",
        "寒冷",
        "北方",
        "沙子",
        "著急",
        "衣服",
        "翅膀",
        "充滿",
        "思念"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150111"
    },
    "upper-12": {
      "characters": [
        "灰",
        "涼",
        "牠",
        "鼓",
        "絡",
        "欣",
        "發",
        "居",
        "冒",
        "冰",
        "圍",
        "咪",
        "幸",
        "團",
        "聚",
        "愉",
        "鍋",
        "妙"
      ],
      "recognition": [
        "聊"
      ],
      "words": [
        "牠們",
        "圓鼓鼓",
        "熱絡",
        "聊天",
        "欣喜",
        "發現",
        "居然",
        "冒煙",
        "笑咪咪",
        "幸福",
        "團聚",
        "愉快",
        "火鍋",
        "美妙"
      ],
      "source": "https://pedia.cloud.edu.tw/Bookmark/TCollection?TextNameId=0103021150112"
    }
  }
};
