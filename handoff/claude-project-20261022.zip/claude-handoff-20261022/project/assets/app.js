(function(){'use strict';
const KEY='baseball_dualtrack_v1';
const DEFAULT={settings:{math:1,english:1,logic:1,science:1,zhuyin:1,chinese:1,autoNext:false,reviewEnabled:true,autoRead:false,sound:true,roundSize:8},recent:{},sessions:[],reflections:[],reviewQueue:[]};
const MODES={english:[{id:'letters',icon:'🔡',name:'字母聽音小挑戰',label:'26 字母基礎',desc:'先認 A～Z 的大小寫，聽聲音再選答案。',skill:'en-letters'},{id:'vocab',icon:'🧢',name:'英文單字',label:'單字辨識',desc:'看英文，選出它的中文意思。',skill:'en-vocab'},{id:'sentence',icon:'📖',name:'短句閱讀',label:'閱讀理解',desc:'讀一小句英文，回答簡單問題。',skill:'en-sentence'},{id:'listening',icon:'🎧',name:'聽力接球',label:'英語聽力',desc:'聽英文發音，找出正確意思。',skill:'en-listening'},{id:'use',icon:'🗣️',name:'單字活用',label:'情境選字',desc:'把單字放進生活、課堂與棒球句子，理解後再選。',skill:'en-use'},{id:'deep',icon:'🧠',name:'深度閱讀',label:'文章思考',desc:'讀短篇故事，從線索推理、找原因、安排順序。',skill:'en-inference'},{id:'review',icon:'🔁',name:'英文錯題補強',label:'個人化複習',desc:'找出真正不熟的地方，分次練習而非硬背答案。',skill:'en-review'}],math:[{id:'calc',icon:'🧮',name:'計算打擊',label:'數與運算',desc:'從加減到乘除、整數四則與多步驟運算，難度分級。',skill:'math-calc'},{id:'story',icon:'⚾',name:'球場應用題',label:'情境解題',desc:'把生活與棒球情境變成算式。',skill:'math-story'},{id:'score',icon:'🏟️',name:'比分小教練',label:'數據判讀',desc:'看比分，理解差距與總分。',skill:'math-score'},{id:'reason',icon:'🧩',name:'策略解題',label:'多步驟推理',desc:'找未知數、讀表格、安排時間與零用錢；每題有思路解析。',skill:'math-reason'},{id:'pattern',icon:'🔎',name:'數列與規律',label:'找規則與數感',desc:'數列、位值、找規律、未知數，練數感而不是只背算式。',skill:'math-pattern'},{id:'measure',icon:'📐',name:'圖形與生活測量',label:'長度·時間·面積',desc:'圖形周長、面積、時間與單位換算，循序加深。',skill:'math-measure'},{id:'review',icon:'🔁',name:'數學錯題補強',label:'個人化複習',desc:'優先複習上次不熟的概念，慢慢建立信心。',skill:'math-review'}]};
const SKILLS={'en-letters':'字母與大小寫','en-vocab':'單字辨識','en-sentence':'閱讀理解','en-listening':'英語聽力','math-calc':'數與運算','math-story':'情境解題','math-score':'數據判讀','en-inference':'英文推理閱讀','en-order':'英文事件順序','en-context':'英文上下文','math-reason':'多步驟思考','math-data':'資料判讀','math-money':'金錢與時間','en-use':'情境單字活用','math-pattern':'數列規律與位值','math-measure':'圖形、時間與測量','en-review':'英文複習','math-review':'數學複習'};

// ===== v24：四科資訊、邏輯推理、科學探索、球場進度與徽章 =====
const SUBJECT_KEYS=['english','math','logic','science'];
const SUBJECT_META={
 english:{name:'英文',icon:'🔤',eyebrow:'ENGLISH PRACTICE',title:'🔤 英文練習場',route:'字母 → 單字 → 情境活用 → 短句與深度閱讀',desc:'先從 A～Z 的大小寫與聽音練起，再逐步認識單字、情境運用、短句及聽力。',tip:'建議每天聽 3～5 個字母，孩子先聽、再模仿、再選字母。一次聽一個字母，再跟著念；不必急著全部記住。',tile:'26 個字母、發音、單字與聽力',levelNote:'字母基礎練習不受此難度設定影響；單字和句子難度由家長調整。'},
 math:{name:'數學',icon:'🔢',eyebrow:'MATH PRACTICE',title:'🔢 數學練習場',route:'數與運算 → 生活應用 → 數列與規律 → 圖形測量 → 策略解題',desc:'選一個項目，完成一回合就能休息。答錯會有說明，別急著求快。',tip:'先讓孩子自己選答案，答錯時一起讀解析，不直接報答案。每次練習結束，可以問：「你是怎麼想的？」',tile:'計算、生活應用、看懂比分',levelNote:'難度不會自動升級；家長可依理解程度調整。'},
 logic:{name:'邏輯',icon:'🧠',eyebrow:'LOGIC TRAINING',title:'🧠 邏輯推理場',route:'找規律 → 分類找不同 → 打序推理 → 規則與因果',desc:'像教練排打序一樣想事情：找線索、排除不可能，再下結論。',tip:'邏輯題最重要的是「說出理由」。孩子答完後，請他用一句話說明：「因為……所以……」。答錯時一起把線索一條一條畫出來。',tile:'球隊推理、數獨、誰說謊、找規律',levelNote:'第1級 3 人打序與簡單規律；第2級 4 人打序與棒球規則；第3級加入「如果……就……」的推論。'},
 science:{name:'科學',icon:'🔬',eyebrow:'SCIENCE LAB',title:'🔬 科學探索場',route:'運動與身體 → 力與運動 → 天氣與自然 → 小小科學家',desc:'球為什麼會飛？運動後為什麼要喝水？從球場上的問題認識科學。',tip:'看完解析後，找機會在生活中「做一次」：一起丟球比較高度、量量跑步後的心跳。親手做過的科學最記得住。',tile:'先學習、太空、身體、自然與實驗',levelNote:'題目依難度累加：第2級也會出現第1級的題目，第3級涵蓋全部。'}
};
const subName=s=>SUBJECT_META[s]?.name||s;
Object.assign(MODES,{
 logic:[{id:'lineup',icon:'📋',name:'打序推理',label:'條件推理',desc:'根據教練給的線索，排出正確的打擊順序。',skill:'logic-order'},{id:'lpattern',icon:'🔁',name:'圖案規律',label:'找規律',desc:'看圖案怎麼重複，猜出下一個或第幾個。',skill:'logic-pattern'},{id:'odd',icon:'🔍',name:'哪個不一樣',label:'分類思考',desc:'找出不同類的一個，並說出分類的理由。',skill:'logic-classify'},{id:'rules',icon:'⚖️',name:'規則與推論',label:'因果判斷',desc:'認識棒球規則，練習「如果……就……」的推論。',skill:'logic-rule'},{id:'review',icon:'🔁',name:'邏輯錯題補強',label:'個人化複習',desc:'把想錯的地方再想一次，找出卡住的線索。',skill:'logic-review'}],
 science:[{id:'body',icon:'💪',name:'運動與身體',label:'人體與健康',desc:'心跳、流汗、肌肉與營養，打球的身體科學。',skill:'sci-body'},{id:'force',icon:'🚀',name:'力與運動',label:'物理入門',desc:'地心引力、摩擦力、球為什麼會飛得遠。',skill:'sci-force'},{id:'nature',icon:'⛅',name:'天氣與自然',label:'地球與自然',desc:'打雷要躲哪裡？影子為什麼會變長？',skill:'sci-nature'},{id:'lab',icon:'🧪',name:'小小科學家',label:'科學方法',desc:'預測、觀察、公平比較，像科學家一樣思考。',skill:'sci-lab'},{id:'mix',icon:'🎲',name:'科學綜合賽',label:'五類混合',desc:'身體、力、自然、實驗與太空題目一起練習。',skill:'sci-mix'},{id:'review',icon:'🔁',name:'科學錯題補強',label:'個人化複習',desc:'再看一次解析，把科學觀念弄懂。',skill:'sci-review'}]
});
Object.assign(SKILLS,{'logic-order':'打序條件推理','logic-pattern':'圖案規律','logic-classify':'分類找不同','logic-rule':'規則與推論','logic-review':'邏輯複習','sci-body':'運動與身體','sci-force':'力與運動','sci-nature':'天氣與自然','sci-lab':'科學方法','sci-mix':'科學綜合','sci-review':'科學複習'});
function normalizeSettings(raw){const o={};for(const k of SUBJECT_KEYS)o[k]=[1,2,3,4].includes(Number(raw?.[k]))?Number(raw[k]):1;o.autoNext=typeof raw?.autoNext==='boolean'?raw.autoNext:false;o.reviewEnabled=typeof raw?.reviewEnabled==='boolean'?raw.reviewEnabled:true;o.autoRead=raw?.autoRead===true;o.sound=raw?.sound!==false;o.roundSize=[5,8,10].includes(Number(raw?.roundSize))?Number(raw.roundSize):8;return o}

// --- 邏輯：打序推理（程式出題，並用窮舉驗證答案唯一） ---
const LINEUP_NAMES=['小安','阿哲','小美','阿宏','小婷','阿凱'];
function permutations(arr){if(arr.length<=1)return [arr.slice()];const out=[];arr.forEach((x,i)=>{for(const p of permutations(arr.filter((_,j)=>j!==i)))out.push([x,...p])});return out}
function lineupQuestion(level){
 const n=level===1?3:4,names=shuffle(LINEUP_NAMES).slice(0,n),order=shuffle(names),pos=Object.fromEntries(order.map((x,i)=>[x,i]));
 const all=permutations(names),cn=['一','二','三','四'];
 const makeClue=()=>{const t=rand(0,level===1?3:4);let a=one(names),b=one(names.filter(x=>x!==a));
  if(t===0){const k=rand(0,n-1);return pos[a]===k?null:{text:`${a}不是第${cn[k]}棒。`,ok:p=>p.indexOf(a)!==k,key:'not'+a+k}}
  if(t===1){if(pos[a]>pos[b])[a,b]=[b,a];return {text:`${a}比${b}先上場打擊。`,ok:p=>p.indexOf(a)<p.indexOf(b),key:'bf'+a+b}}
  if(t===2){const x=pos[a]===0?a:pos[a]===n-1?a:null;if(!x)return null;return pos[x]===0?{text:`${x}是第一棒。`,ok:p=>p[0]===x,key:'first'}:{text:`${x}是最後一棒。`,ok:p=>p[n-1]===x,key:'last'}}
  if(t===3){const k=pos[a];return k===0||k===n-1?null:{text:`${a}不是第一棒，也不是最後一棒。`,ok:p=>{const i=p.indexOf(a);return i!==0&&i!==n-1},key:'mid'+a}}
  const i=pos[a];if(i===n-1)return null;const nx=order[i+1];return {text:`${nx}緊接在${a}後面打擊。`,ok:p=>p.indexOf(nx)===p.indexOf(a)+1,key:'nx'+a}};
 let clues=[],guard=0;const fits=c=>all.filter(p=>c.every(x=>x.ok(p)));
 while(fits(clues).length>1&&guard++<200){const c=makeClue();if(!c||clues.some(x=>x.key===c.key))continue;const before=fits(clues).length;if(fits([...clues,c]).length<before)clues.push(c)}
 if(fits(clues).length!==1)return lineupQuestion(level);
 for(let i=clues.length-1;i>=0;i--){const t=clues.filter((_,j)=>j!==i);if(fits(t).length===1)clues=t}
 // 問一個沒有被線索直接說出的棒次
 const stated=new Set();for(const c of clues){if(c.key==='first')stated.add(0);if(c.key==='last')stated.add(n-1)}
 const ks=[...Array(n).keys()].filter(k=>!stated.has(k));const k=ks.length?one(ks):rand(0,n-1),ans=order[k];
 const choices=n===3?shuffle([...names,'線索不夠，無法確定']):shuffle(names);
 return {skill:'logic-order',prompt:'📋 教練的打序線索：排一排，再回答',main:clues.map((c,i)=>`${i+1}. ${c.text}`).join('\n'),second:`${names.join('、')} ${n} 人輪流打擊。誰是第${cn[k]}棒？`,answer:ans,choices,explain:`把線索一條條放進去，正確打序是：${order.map((x,i)=>`第${cn[i]}棒 ${x}`).join(' → ')}。`,hint:'先用最確定的線索固定一個人，再用「不是……」排除其他可能。可以在手寫草稿畫出 1、2、3 格子。',signature:'lineup-'+order.join('')+clues.map(c=>c.key).join(''),concept:'lineup-'+level,reason:true};
}
// --- 邏輯：圖案規律（程式出題） ---
const PATTERN_SYMBOLS=['⚾','🧤','🧢','⭐','🏆','👟'];
function logicPatternQuestion(level){
 const units=level===1?['AB','ABC','AAB']:level===2?['ABB','AABB','ABCD','ABAC']:['ABC','AABB','ABCD','ABBC'];
 const u=one(units),letters=[...new Set(u)],syms=shuffle(PATTERN_SYMBOLS).slice(0,letters.length),map=Object.fromEntries(letters.map((l,i)=>[l,syms[i]]));
 const at=i=>map[u[i%u.length]];let main,ans,explain,hint,second;
 if(level===1){const len=u.length*2+rand(0,u.length-1);main=[...Array(len)].map((_,i)=>at(i)).join(' ')+' ❓';ans=at(len);second='❓ 應該是哪一個？';explain=`每 ${u.length} 個一組重複：${[...u].map((_,i)=>at(i)).join(' ')}，所以下一個是 ${ans}。`;hint='先找出「一組」有幾個圖案，再接著往下排。'}
 else if(level===2){const len=u.length*3,blank=rand(u.length,len-2);main=[...Array(len)].map((_,i)=>i===blank?'❓':at(i)).join(' ');ans=at(blank);second='中間的 ❓ 應該是哪一個？';explain=`重複的一組是：${[...u].map((_,i)=>at(i)).join(' ')}。第 ${blank+1} 個位置是 ${ans}。`;hint='從頭開始一組一組圈起來，看 ❓ 落在一組裡的第幾個。'}
 else{const show=u.length*2,N=rand(12,24);main=[...Array(show)].map((_,i)=>at(i)).join(' ')+' …';ans=at(N-1);second=`照這個規律一直排下去，第 ${N} 個是哪一個？`;const r=N%u.length||u.length;explain=`每 ${u.length} 個一組。${N}÷${u.length}＝${Math.floor(N/u.length)} 餘 ${N%u.length}${N%u.length===0?'（剛好排完一組，是一組的最後一個）':''}，所以第 ${N} 個和每組第 ${r} 個一樣，是 ${ans}。`;hint='不用全部畫出來：用除法算出排了幾組，看餘數。'}
 const others=shuffle(PATTERN_SYMBOLS.filter(s=>s!==ans));const choices=shuffle([ans,...others.slice(0,3)]);
 return {skill:'logic-pattern',prompt:'🔁 找出圖案重複的規律',main,second,answer:ans,choices,explain,hint,signature:'lp-'+main+second,concept:'lpattern-'+u,reason:level>=3};
}
// --- 題庫格式：{l:級別, q:題目, a:答案, o:[四個選項], e:解析, h:提示} ---
const ODD_BANK=[
 {l:1,q:'哪一個不是球？',a:'🧤 手套',o:['⚾ 棒球','🏀 籃球','⚽ 足球','🧤 手套'],e:'棒球、籃球、足球都是球；手套是用來接球的用具。'},
 {l:1,q:'哪一個不是水果？',a:'球棒',o:['蘋果','香蕉','橘子','球棒'],e:'蘋果、香蕉、橘子都是水果，球棒是運動用品。'},
 {l:1,q:'哪一個不是顏色名稱？',a:'三角形',o:['紅色','藍色','綠色','三角形'],e:'紅、藍、綠是顏色；三角形是形狀。'},
 {l:1,q:'哪一個不是動物？',a:'汽車',o:['狗','貓','鳥','汽車'],e:'狗、貓、鳥都是動物，汽車是交通工具。'},
 {l:1,q:'哪一個數字不能兩個兩個分完，會剩下一個？',a:'7',o:['2','4','6','7'],e:'2、4、6 都是雙數（偶數），7 是單數（奇數）。',h:'試試看能不能平分成兩半。'},
 {l:1,q:'哪一個不是棒球場上的壘包？',a:'四壘',o:['一壘','二壘','三壘','四壘'],e:'棒球場有一壘、二壘、三壘和本壘，沒有「四壘」。'},
 {l:1,q:'哪一個不是穿在身上的？',a:'球棒',o:['帽子','球衣','球鞋','球棒'],e:'帽子、球衣、球鞋都穿戴在身上；球棒是拿在手上的用具。'},
 {l:1,q:'哪一個不是「星期幾」？',a:'晚餐',o:['星期一','星期三','星期六','晚餐'],e:'星期一、三、六都是星期幾；晚餐是一餐飯。'},
 {l:2,q:'哪一個不是球員？',a:'裁判',o:['投手','捕手','游擊手','裁判'],e:'投手、捕手、游擊手都是場上的球員；裁判負責判決，不屬於任何一隊。'},
 {l:2,q:'哪一個不是3的倍數？',a:'10',o:['3','6','9','10'],e:'3、6、9 都是 3 的倍數，10 不是。',h:'想想看 3 的乘法。'},
 {l:2,q:'哪一個不是季節？',a:'下雨',o:['春天','夏天','冬天','下雨'],e:'春夏冬是季節；下雨是天氣，任何季節都可能下雨。'},
 {l:2,q:'哪一個形狀沒有角？',a:'圓形',o:['正方形','長方形','三角形','圓形'],e:'正方形、長方形、三角形都有直直的邊和角；圓形沒有角。'},
 {l:2,q:'哪一個不是鳥？',a:'蝴蝶',o:['麻雀','鴿子','企鵝','蝴蝶'],e:'企鵝雖然不會飛，但有羽毛、會下蛋，是鳥；蝴蝶是昆蟲。',h:'會飛的不一定是鳥，不會飛的也可能是鳥。'},
 {l:2,q:'哪一個不是守備位置？',a:'打者',o:['一壘手','中外野手','捕手','打者'],e:'一壘手、中外野手、捕手都是守備位置；打者是進攻方。'},
 {l:2,q:'哪一個不是時間單位？',a:'公尺',o:['小時','分鐘','秒','公尺'],e:'小時、分鐘、秒都是時間單位；公尺是長度單位。'},
 {l:3,q:'哪一個不是哺乳類動物？',a:'鯊魚',o:['鯨魚','海豚','鯊魚','海豹'],e:'鯨魚、海豚、海豹用肺呼吸、會餵奶，是哺乳類；鯊魚用鰓呼吸，是魚類。',h:'住在海裡的不一定是魚。'},
 {l:3,q:'哪一個不是行星？',a:'太陽',o:['太陽','地球','火星','木星'],e:'地球、火星、木星都是繞著太陽轉的行星；太陽是自己會發光的恆星。'},
 {l:3,q:'哪一個不是水的固態、液態或氣態？',a:'木頭',o:['冰','水','水蒸氣','木頭'],e:'冰、水、水蒸氣都是「水」的不同樣子（固體、液體、氣體）；木頭不是。'},
 {l:3,q:'以下哪個情況會讓打者直接出局？',a:'第三好球被捕手合法接住',o:['安打','全壘打','四壞球保送','第三好球被捕手合法接住'],e:'第三好球被捕手合法接住時，打者三振出局；第三好球未被接住時，部分情況下打者仍可跑向一壘，不能一概說三振必定立刻出局。'},
 {l:3,q:'哪一個不是6的倍數？',a:'25',o:['12','18','24','25'],e:'12、18、24 都是 6 的倍數，25 不是。'},
 {l:3,q:'哪一個不是植物需要的？',a:'電視',o:['陽光','水','空氣','電視'],e:'植物需要陽光、水和空氣來生長。'},
 {l:3,q:'哪個詞表示不愉快的感受？',a:'難過',o:['開心','興奮','喜悅','難過'],e:'開心、興奮、喜悅是愉快的感覺；難過是不愉快的感覺。'}
];
const RULES_BANK=[
 {l:1,q:'打者第三個好球被捕手合法接住，會發生什麼事？',a:'三振出局',o:['三振出局','保送上一壘','得到一分','換投手'],e:'第三個好球被捕手合法接住時，打者三振出局；未接住第三好球的情況另有規則。'},
 {l:1,q:'投手投出四個壞球，打者可以怎麼做？',a:'直接走到一壘',o:['直接走到一壘','回到休息區','重新打擊一次','跑回本壘'],e:'四個壞球叫「四壞球保送」，打者可以安全走上一壘。'},
 {l:1,q:'防守的一方抓到三個出局後，會怎樣？',a:'攻守交換',o:['攻守交換','比賽重來','防守方得分','繼續打擊'],e:'每半局三個出局數，滿了就換另一隊進攻。'},
 {l:1,q:'跑者要怎麼跑才能得分？',a:'依序踩一、二、三壘，再回本壘',o:['依序踩一、二、三壘，再回本壘','直接從一壘跑回本壘','只要跑到二壘','繞著外野跑一圈'],e:'跑者要按照一壘 → 二壘 → 三壘 → 本壘的順序跑，回到本壘才得一分。'},
 {l:1,q:'打者擊出的高飛球，在落地前被防守球員接住，結果是？',a:'打者出局',o:['打者出局','打者上二壘','算是安打','重新投球'],e:'飛球在落地前被接住，打者就出局，這叫「接殺」。'},
 {l:1,q:'球賽結束時，誰獲勝？',a:'得分比較多的隊伍',o:['得分比較多的隊伍','安打比較多的隊伍','球衣比較好看的隊伍','先上場打擊的隊伍'],e:'棒球比的是得分，安打多不一定得分多。'},
 {l:1,q:'打出全壘打的打者可以怎麼做？',a:'繞完所有壘包回本壘得分',o:['繞完所有壘包回本壘得分','只能停在一壘','要重新打一次','換下一位打者'],e:'全壘打讓打者自己繞完一、二、三壘回到本壘，得一分；壘上的跑者也一起回來得分。'},
 {l:1,q:'在場上打擊和跑壘時，為什麼要戴頭盔？',a:'保護頭部安全',o:['保護頭部安全','讓自己跑比較快','因為比較好看','讓球打比較遠'],e:'球速很快，頭盔可以保護頭部，避免被球打傷。'},
 {l:2,q:'已經兩好球，打者揮棒打成未被接住的界外球（非觸擊、非擦棒球），現在是幾好球？',a:'還是兩好球',o:['還是兩好球','三好球，三振','一好球','壞球加一'],e:'兩好球後，這種未被接住的普通界外球不增加好球數；觸擊界外、被捕手合法接住的擦棒球等情況有不同規則。',h:'先確認題目排除了觸擊與擦棒球，再看普通界外球如何計數。'},
 {l:2,q:'一壘有跑者，這時打者被四壞球保送，一壘跑者要怎麼辦？',a:'被推進到二壘',o:['被推進到二壘','回到本壘','留在一壘不動','出局'],e:'打者要占用一壘，原本在一壘的跑者會被「擠」到二壘。'},
 {l:2,q:'好壞球數是兩好三壞，下一球是壞球，結果是？',a:'保送上一壘',o:['保送上一壘','三振出局','重新數球數','打者出局'],e:'壞球累積到四個就保送；三壞再加一壞就是四壞。'},
 {l:2,q:'每一局分成上半局和下半局。上半局通常由哪一隊進攻？',a:'客隊',o:['客隊','主隊','兩隊同時','裁判決定'],e:'棒球規定客隊先攻（上半局），主隊後攻（下半局）。'},
 {l:2,q:'最後一局的上半局結束時，主隊已經領先，下半局還要打嗎？',a:'不用打，主隊獲勝',o:['不用打，主隊獲勝','一定要打完','改由客隊再打一次','比賽重來'],e:'主隊後攻，如果最後一局上半結束時已經領先，客隊沒有機會再追，就不用打下半局。',h:'想想看：還有誰需要進攻？'},
 {l:2,q:'兩出局時，打者第三好球被捕手合法接住，接下來會？',a:'三出局，攻守交換',o:['三出局，攻守交換','打者再打一次','跑者全部得分','變成一出局'],e:'兩出局再多一個出局，就是三出局，換邊。'},
 {l:2,q:'投手每天能投的球數有限制，主要原因是？',a:'保護還在成長的手臂',o:['保護還在成長的手臂','讓比賽快一點','省下棒球','讓打者比較好打'],e:'小朋友的骨頭和關節還在發育，投太多球容易受傷，所以有投球數限制。'},
 {l:3,q:'假設一定遵守規則：「如果下雨，比賽就延期。」今天比賽照常舉行。可以推論什麼？',a:'今天沒有下雨',o:['今天沒有下雨','今天有下雨','明天一定下雨','無法知道比賽有沒有舉行'],e:'如果下雨一定會延期；今天沒延期，就代表沒有下雨。這叫反過來推論。',h:'假設今天下雨，會發生什麼？和事實一樣嗎？'},
 {l:3,q:'「如果打出全壘打，就一定會得分。」紅隊得分了，一定是打出全壘打嗎？',a:'不一定，安打也能送跑者回來得分',o:['不一定，安打也能送跑者回來得分','一定是全壘打','一定是三振','紅隊一定輸了'],e:'全壘打會得分，但得分不一定是全壘打，也可能是安打、高飛犧牲打等方式。',h:'「A 一定造成 B」不代表「B 一定來自 A」。'},
 {l:3,q:'假設大家都遵守「所有隊員打擊時都要戴頭盔」。小安是隊員，正在打擊。可以知道什麼？',a:'小安戴著頭盔',o:['小安戴著頭盔','小安沒戴頭盔','小安是投手','不知道小安是誰'],e:'規則說「所有隊員」打擊都要戴，小安是隊員又在打擊，所以他戴著頭盔。'},
 {l:3,q:'紅隊贏過藍隊，藍隊贏過綠隊。能確定紅隊和綠隊比賽時，紅隊一定贏嗎？',a:'不能確定，要真的比過才知道',o:['不能確定，要真的比過才知道','紅隊一定贏','綠隊一定贏','一定平手'],e:'比賽不像身高可以直接比，每場狀況不同；沒比過就不能確定結果。'},
 {l:3,q:'阿哲比小安高，小安比小美高。三個人裡誰最矮？',a:'小美',o:['小美','小安','阿哲','無法判斷'],e:'阿哲 > 小安 > 小美，所以小美最矮。身高可以這樣一路比下去。',h:'把三個人從高排到矮。'},
 {l:3,q:'假設大家遵守「只有完成暖身的人才能上場」。阿宏上場比賽了，可以知道什麼？',a:'阿宏有完成暖身',o:['阿宏有完成暖身','阿宏沒有暖身','阿宏是教練','所有人都上場了'],e:'沒暖身的人不能上場；阿宏上場了，所以他一定完成了暖身。'},
 {l:3,q:'投手、捕手、一壘手由小美、阿哲、小安擔任。阿哲是投手，小美不是捕手。小安守哪裡？',a:'捕手',o:['捕手','投手','一壘手','無法判斷'],e:'阿哲是投手；小美不是捕手，只能是一壘手；剩下的捕手就是小安。',h:'先把確定的人填進去，再看剩下的位置。'},
 {l:3,q:'只知道「有些球員是左撇子」，能確定每個球員都是左撇子嗎？',a:'不能確定，只知道至少有一人是',o:['不能確定，只知道至少有一人是','可以，大家都是','可以，只是說法不同','球員都不是左撇子'],e:'「有些」表示至少有一人符合，不能據此確定全部都符合，也不能確定一定有人不符合。'}
];
const SCIENCE_BANK={
 body:[
  {l:1,q:'打球流了很多汗之後，最應該做什麼？',a:'補充水分',o:['補充水分','馬上睡覺','吃很多糖果','繼續跑不休息'],e:'流汗會讓身體失去水分。適時補水和休息，有助避免脫水；若頭暈或抽筋，應停止活動並告訴大人。'},
  {l:1,q:'運動前先做暖身，主要是為了什麼？',a:'減少受傷',o:['減少受傷','讓自己變高','肚子比較不餓','讓球變輕'],e:'暖身讓肌肉和關節慢慢準備好，突然用力時比較不容易拉傷。'},
  {l:1,q:'跑完壘包後，摸摸胸口，心跳會怎樣？',a:'變快',o:['變快','變慢','停止','完全不變'],e:'運動時肌肉需要更多氧氣，心臟要跳得更快，把血液送到全身。'},
  {l:1,q:'晚上睡飽覺，對打球的小朋友有什麼幫助？',a:'身體恢復、長高長壯',o:['身體恢復、長高長壯','讓眼睛變大','不用再吃飯','讓頭髮變長'],e:'睡覺時身體會修復疲勞的肌肉，也是長高的重要時間。'},
  {l:1,q:'大太陽下練球，下面哪個做法最好？',a:'戴帽子、喝水、在陰涼處休息',o:['戴帽子、喝水、在陰涼處休息','穿厚外套','一直不喝水','整天站在太陽下'],e:'太熱容易中暑，戴帽子遮陽、多喝水、適時休息能保護身體。'},
  {l:1,q:'我們用什麼器官看到飛過來的球？',a:'眼睛',o:['眼睛','耳朵','鼻子','舌頭'],e:'眼睛看到球的位置和速度，大腦再指揮身體去接球。'},
  {l:1,q:'練球前，哪一種早餐比較好？',a:'吃一份正常的早餐',o:['吃一份正常的早餐','什麼都不吃','只喝汽水','只吃糖果'],e:'早餐提供能量，空著肚子運動容易沒力氣或頭暈。'},
  {l:2,q:'彎曲手臂投球時，是什麼拉動骨頭？',a:'肌肉',o:['肌肉','頭髮','指甲','皮膚'],e:'肌肉收縮時會拉動骨頭，讓手臂彎曲和伸直。'},
  {l:2,q:'跑步時呼吸變快，是因為身體需要更多什麼？',a:'氧氣',o:['氧氣','水','鹽','光'],e:'肌肉工作需要氧氣，呼吸加快可以吸進更多空氣。'},
  {l:2,q:'身體流汗的主要作用是什麼？',a:'幫助身體散熱降溫',o:['幫助身體散熱降溫','讓身體變重','讓皮膚變黑','讓自己長高'],e:'汗水蒸發時會帶走熱量，讓身體不會過熱。'},
  {l:2,q:'心臟的主要工作是什麼？',a:'把血液送到全身',o:['把血液送到全身','消化食物','呼吸空氣','思考事情'],e:'心臟像一個幫浦，不停把血液送到身體各處。'},
  {l:2,q:'投球後手臂很痠痛，應該怎麼做？',a:'休息並告訴大人或教練',o:['休息並告訴大人或教練','忍住繼續投','投更多球練習','不跟任何人說'],e:'痠痛是身體在提醒你需要休息，硬撐可能讓手臂受傷。'},
  {l:3,q:'吃蛋、魚、豆腐這類食物，主要提供哪種營養，幫助肌肉生長？',a:'蛋白質',o:['蛋白質','糖分','鹽分','咖啡因'],e:'蛋白質是修補和建造肌肉的重要材料。'},
  {l:3,q:'喝牛奶、吃小魚乾，可以補充鈣質，主要對什麼有幫助？',a:'骨頭和牙齒',o:['骨頭和牙齒','頭髮顏色','視力','心跳速度'],e:'鈣是骨頭和牙齒的重要成分，成長中的孩子特別需要。'},
  {l:3,q:'大熱天練球，覺得頭暈、想吐、皮膚很燙，最好怎麼做？',a:'停止活動，到陰涼處並立即告訴大人',o:['停止活動，到陰涼處並立即告訴大人','再多跑幾圈','穿上外套','自己忍著不說'],e:'這可能是熱傷害，要停止活動、到陰涼處降溫並立即找大人。只有意識清楚且能吞嚥時才可少量喝水；意識不清或情況嚴重時，大人應撥打119，不可強灌水。'},
  {l:3,q:'為什麼運動後要做緩和的伸展？',a:'維持關節活動範圍',o:['維持關節活動範圍','讓自己更累','讓骨頭變短','可以不用喝水'],e:'溫和伸展有助維持柔軟度與關節活動範圍，但不能保證減少隔天痠痛。有疼痛時要停止並告訴大人，不要勉強拉伸。'}
 ],
 force:[
  {l:1,q:'把球往上丟，為什麼它會掉下來？',a:'地心引力把球往下拉',o:['地心引力把球往下拉','球自己想回來','風把球吹下來','球累了'],e:'地球會把所有東西往下拉，這個力量叫做「地心引力」。'},
  {l:1,q:'同樣的球棒，用力揮和輕輕揮，哪一個通常讓球飛比較遠？',a:'用力揮',o:['用力揮','輕輕揮','一樣遠','都不會飛'],e:'給球的力量越大，球通常飛得越快、越遠。'},
  {l:1,q:'同樣力氣滾球，在哪裡滾得比較遠？',a:'平滑的水泥地',o:['平滑的水泥地','長長的草地','沙坑','泥巴地'],e:'草地、沙子比較粗糙，「摩擦力」大，會讓球比較快停下來。'},
  {l:1,q:'同一個箱子放在同樣地面，要推動時，裝滿球和空箱子通常哪個比較費力？',a:'裝滿球的箱子',o:['裝滿球的箱子','空箱子','一樣','都推不動'],e:'同一箱子與地面接觸條件相同時，裝得較重通常有較大的滑動阻力；若要得到相同加速度，也需要較大的合力。'},
  {l:1,q:'球從平順斜坡上由靜止開始往下滾，在尚未到坡底時通常會怎樣？',a:'越滾越快',o:['越滾越快','越滾越慢','速度不變','停在中間'],e:'重力沿斜坡向下的分量使球加速；這裡比較平順斜坡上、尚未到坡底的一段。'},
  {l:1,q:'打擊時，球會往反方向飛出去，是因為什麼？',a:'球棒把力量傳給了球',o:['球棒把力量傳給了球','球自己會轉彎','裁判喊了一聲','觀眾在加油'],e:'球棒撞到球，把力量傳給球，球就改變方向飛出去。'},
  {l:1,q:'球被丟出去後，最後停下來，主要和什麼有關？',a:'摩擦力和空氣阻力',o:['摩擦力和空氣阻力','球的顏色','球的名字','天氣好不好'],e:'空氣和地面會一直「擋」著球，讓它慢慢停下來。'},
  {l:2,q:'接球時，手套順著球的方向往身體收，為什麼手比較不痛？',a:'讓球慢慢停下來',o:['讓球慢慢停下來','讓球變輕','讓球變小','讓球飛走'],e:'讓球停下來的時間變長，手受到的衝擊就變小，所以比較不痛。'},
  {l:2,q:'跑者滑壘時，身體會在地上慢慢停住，是因為什麼力？',a:'摩擦力',o:['摩擦力','磁力','浮力','電力'],e:'身體和泥土摩擦，產生阻止滑動的力，讓跑者停下來。'},
  {l:2,q:'想把球丟最遠，大概往哪個方向丟比較好？',a:'斜斜往上丟',o:['斜斜往上丟','直直往上丟','直直往下丟','往地上丟'],e:'在相同拋出速度和起落高度、且不考慮風時，斜向上拋能兼顧水平速度與飛行時間；垂直向上拋幾乎沒有水平距離。'},
  {l:2,q:'球打到牆壁會彈回來，表示什麼？',a:'牆壁也對球施了力',o:['牆壁也對球施了力','牆壁會動','球不見了','球變重了'],e:'球推牆壁，牆壁也推回球，所以球會反彈。'},
  {l:2,q:'球棒的哪一部分打到球，球通常飛最遠？',a:'球棒前段較粗的「甜蜜點」附近',o:['球棒前段較粗的「甜蜜點」附近','握把','球棒最尾端的蓋子','都一樣'],e:'球棒前段有一個區域，打到時力量傳得最好、手也比較不麻，叫「甜蜜點」。'},
  {l:3,q:'忽略空氣阻力，以相同速度和向斜上方的角度，從平地拋出棒球。在月球會比在地球落得遠還是近？',a:'比較遠',o:['比較遠','比較近','一樣遠','球會往上飛走'],e:'在相同拋出速度、角度和起落高度，且忽略空氣阻力時，月球表面重力較小，球飛行較久，水平距離較遠。'},
  {l:3,q:'球在空中飛時，除了地心引力，什麼也會讓它慢下來？',a:'空氣阻力',o:['空氣阻力','陽光','聲音','影子'],e:'球要推開空氣才能前進，空氣會擋住它，這叫空氣阻力。'},
  {l:3,q:'變化球會在空中轉彎，主要原因是什麼？',a:'球旋轉，讓兩邊的空氣推力不一樣',o:['球旋轉，讓兩邊的空氣推力不一樣','球裡面有馬達','投手用魔法','球的顏色不同'],e:'球旋轉時，兩側空氣流動的情形不同，空氣就把球往一邊推，所以會轉彎。'},
  {l:3,q:'同一顆球以相同速度進入長草地和夯實平整的紅土，為什麼通常在長草地較快慢下來？',a:'長草造成的滾動阻力通常較大',o:['長草造成的滾動阻力通常較大','草地比較熱','草的顏色是綠的','外野比較遠'],e:'長草會彎曲、阻擋球並消耗動能，通常使球較快慢下來；實際情況還受草長、土質與濕度影響，不能說所有草地都一定比紅土阻力大。'}
 ],
 nature:[
  {l:1,q:'練球時聽到打雷、看到閃電，應該怎麼做？',a:'立刻停止，進到室內躲避',o:['立刻停止，進到室內躲避','躲到大樹下','繼續練球','站在空曠的球場中間'],e:'聽到雷聲應停止戶外活動，和大人進入堅固、封閉的建築物，或關好窗的硬頂車內；樹下、涼亭及開放式棚子不能當作安全避雷處。'},
  {l:1,q:'在台灣，太陽通常從哪個方向附近升起？',a:'東邊',o:['東邊','西邊','南邊','北邊'],e:'在台灣，太陽通常從東方附近升起、在西方附近落下；位置會隨季節改變，不是每天都正東正西。'},
  {l:1,q:'下過雨的球場，跑壘時要注意什麼？',a:'地很滑，要小心',o:['地很滑，要小心','地會變熱','球會變大','可以跑更快'],e:'地面有水會變滑，摩擦力變小，容易滑倒。'},
  {l:1,q:'球場的草要長得好，需要什麼？',a:'陽光、水和空氣',o:['陽光、水和空氣','只要黑暗','只要石頭','只要冰塊'],e:'綠色植物利用陽光、水和空氣中的二氧化碳進行光合作用，製造糖類等養分；生長也需要適合的溫度與礦物質。'},
  {l:1,q:'晚上的天空為什麼看得到月亮？',a:'月亮反射了太陽光',o:['月亮反射了太陽光','月亮自己點燈','月亮是一顆燈泡','因為有路燈'],e:'月亮自己不會發光，我們看到的是它反射的太陽光。'},
  {l:1,q:'哪一個季節通常最熱？',a:'夏天',o:['夏天','冬天','春天','都一樣'],e:'台灣的夏天氣溫最高，練球時要特別注意補水。'},
  {l:1,q:'冬天早上練球，嘴巴呼出的氣看起來白白的，是什麼？',a:'很小的水滴',o:['很小的水滴','煙','灰塵','雪'],e:'呼出的熱水氣遇到冷空氣，變成很小的水滴，看起來就像白霧。'},
  {l:2,q:'早上和傍晚的影子，比中午的影子怎樣？',a:'比較長',o:['比較長','比較短','一樣長','不見了'],e:'早晚太陽比較低，光斜斜照過來，影子就拉得長長的。'},
  {l:2,q:'先看到閃電，過幾秒才聽到雷聲，原因是？',a:'光跑得比聲音快',o:['光跑得比聲音快','聲音跑得比光快','雷聲比較懶','耳朵比較慢'],e:'閃電和雷其實同時發生，但光速比聲音快很多，所以先看到光。'},
  {l:2,q:'水放進冰箱冷凍庫，溫度到 0 度以下會怎樣？',a:'結成冰',o:['結成冰','變成水蒸氣','消失不見','變成牛奶'],e:'水在 0°C 以下會凍結成固體的冰。'},
  {l:2,q:'把濕球衣曬在太陽下，水到哪裡去了？',a:'蒸發到空氣中',o:['蒸發到空氣中','被衣服吃掉','流到地底','變成灰塵'],e:'太陽的熱讓水變成看不見的水蒸氣，跑進空氣裡，這叫蒸發。'},
  {l:2,q:'晴天白晝，除了太陽，為什麼大多數星星不容易用肉眼看見？',a:'陽光經大氣散射，使天空太亮',o:['陽光經大氣散射，使天空太亮','星星白天回家睡覺','星星只有晚上才存在','雲把星星吃掉'],e:'星星白天也存在。陽光經大氣散射，使天空明亮，多數星光因此不容易被肉眼看見；太陽本身也是恆星。'},
  {l:3,q:'雲是怎麼形成的？',a:'水蒸氣遇冷，形成小水滴或冰晶',o:['水蒸氣遇冷，形成小水滴或冰晶','工廠製造的','棉花飛上天','鳥的羽毛'],e:'空氣中的水蒸氣在適當條件下遇冷，可形成微小水滴或冰晶，懸浮在空氣中形成雲。雲不是氣態的水蒸氣本身。'},
  {l:3,q:'為什麼會有白天和黑夜？',a:'地球自己在轉動',o:['地球自己在轉動','太陽晚上關燈','月亮擋住太陽','雲遮住天空'],e:'地球每天自轉一圈，面向太陽的一面是白天，背對的一面是黑夜。'},
  {l:3,q:'颱風要來時，球隊最應該怎麼做？',a:'取消戶外練習，待在安全的室內',o:['取消戶外練習，待在安全的室內','趁風大練習打高飛球','到海邊看浪','照常比賽'],e:'颱風的強風和大雨會吹倒東西、造成危險，要聽從停課停班資訊，待在室內。'},
  {l:3,q:'夏天站在柏油路上比站在草地上熱，主要原因是？',a:'深色柏油吸收比較多太陽的熱',o:['深色柏油吸收比較多太陽的熱','草地比較靠近太陽','柏油會自己發熱','草地有冷氣'],e:'深色的東西吸收比較多陽光的熱，所以柏油路會變得很燙。'}
 ],
 lab:[
  {l:1,q:'想知道哪顆球彈得比較高，怎麼比較才公平？',a:'從同樣的高度放下兩顆球',o:['從同樣的高度放下兩顆球','一顆用丟的、一顆用放的','一顆從高處、一顆從低處','只試其中一顆'],e:'除了「球」不一樣，其他條件都要一樣，比出來的結果才公平。'},
  {l:1,q:'科學家做完實驗後，一定要做什麼？',a:'把結果記錄下來',o:['把結果記錄下來','馬上忘記','只告訴自己','把東西丟掉'],e:'記錄結果才能比較、分享，也能讓別人檢查。'},
  {l:1,q:'實驗前先猜猜看會發生什麼，這叫做什麼？',a:'預測',o:['預測','作弊','忘記','放棄'],e:'先預測，再觀察結果，比較一下猜得對不對，就是科學的思考方式。'},
  {l:1,q:'用眼睛仔細看、用耳朵仔細聽，記下發生的事，這叫做什麼？',a:'觀察',o:['觀察','睡覺','比賽','猜拳'],e:'觀察是科學家最基本的能力，要仔細又誠實。'},
  {l:1,q:'實驗的結果和你猜的不一樣，應該怎麼做？',a:'誠實記下來，再想想為什麼',o:['誠實記下來，再想想為什麼','偷偷改成猜的答案','假裝沒看到','不要再做了'],e:'猜錯沒關係，科學家常常從「意外的結果」學到新東西。'},
  {l:1,q:'想量球從投手丘丟到本壘要多少時間，用什麼工具最好？',a:'碼錶',o:['碼錶','尺','體重計','溫度計'],e:'碼錶用來量時間；尺量長度、體重計量重量、溫度計量溫度。'},
  {l:2,q:'想比較兩種手套哪一種接球比較不痛，應該怎麼做？',a:'只換手套，其他都一樣',o:['只換手套，其他都一樣','同時換手套和換球','一次用快球、一次用慢球','讓不同的人各試一種'],e:'一次只改變一個條件，才知道差別是不是手套造成的。'},
  {l:2,q:'為什麼同一個實驗要多做幾次？',a:'結果比較可靠',o:['結果比較可靠','比較好玩而已','讓時間過得快','因為第一次一定錯'],e:'只做一次可能是運氣，多做幾次結果都差不多，才比較可信。'},
  {l:2,q:'要比較誰跑壘最快，下面哪個做法最公平？',a:'大家跑同樣的距離，用同一個碼錶計時',o:['大家跑同樣的距離，用同一個碼錶計時','每個人跑不同的距離','有人用走的','看誰喊得最大聲'],e:'距離、計時方式都一樣，比較的才是真正的速度。'},
  {l:2,q:'把每天練習揮棒的次數畫成長條圖，有什麼好處？',a:'一眼看出哪天練得多、哪天練得少',o:['一眼看出哪天練得多、哪天練得少','讓球棒變輕','可以不用練習','讓數字變大'],e:'圖表把數字變成圖，比較起來更清楚。'},
  {l:2,q:'想知道植物需不需要陽光，應該怎麼安排？',a:'兩盆一樣的植物，一盆照光、一盆放暗處',o:['兩盆一樣的植物，一盆照光、一盆放暗處','兩盆都放在暗處','一盆澆水、一盆不澆水又不照光','只種一盆看看'],e:'只有「陽光」不同，其他像水、土都一樣，才知道陽光的影響。'},
  {l:3,q:'小安說：「今天吃了香蕉，所以打出全壘打。」只發生一次，可以這樣下結論嗎？',a:'不行，要多次比較才知道',o:['不行，要多次比較才知道','可以，一定是香蕉','可以，每次都會','香蕉讓球變重'],e:'一次的巧合不能證明原因，要比較吃與不吃很多次的結果才知道。'},
  {l:3,q:'想研究「球棒長度會不會影響打擊距離」，實驗中應該改變什麼？',a:'只改變球棒長度',o:['只改變球棒長度','球棒長度和打者都換','球的種類也一起換','什麼都不改變'],e:'要研究的條件（球棒長度）才改變，其他條件都維持一樣。'},
  {l:3,q:'測量球滾動的距離時，為什麼要用同一把捲尺？',a:'讓測量標準一致',o:['讓測量標準一致','捲尺比較好看','因為只有一把','可以量得比較長'],e:'使用相同單位、檢查過的工具和一致的測量方式，能減少工具差異；同一把尺仍可能有誤差，不能保證比較準確。'},
  {l:3,q:'實驗記錄：第1次 3 公尺、第2次 3 公尺、第3次 9 公尺。第 3 次最應該怎麼處理？',a:'檢查是不是哪裡出錯，再重做一次',o:['檢查是不是哪裡出錯，再重做一次','直接當成正確答案','把前兩次刪掉','改成 3 公尺'],e:'和其他結果差很多的數字，可能是操作出錯，要檢查原因並重做，不能隨便改數字。'},
  {l:3,q:'科學家發現新結果後，為什麼要請別人再做一次實驗？',a:'確認結果是真的，不是巧合或錯誤',o:['確認結果是真的，不是巧合或錯誤','因為自己懶得做','讓別人比較累','為了比賽'],e:'別人也做出一樣的結果，這個發現才更可信。'}
 ]
};
function bankQuestionFrom(item,skill,prompt,sig,reason=true){return {skill,prompt,main:item.q,answer:item.a,choices:shuffle(item.o),explain:item.e,hint:item.h||'先把每個選項想一遍，刪掉一定不對的，再從剩下的選。',signature:sig,concept:sig,reason}}
function pickBank(bank,lv,used,prefix){const tagged=bank.map((x,i)=>({x,i,sig:prefix+'-'+i}));const fresh=tagged.filter(t=>!used.has(t.sig)&&t.x.l<=lv);const same=fresh.filter(t=>t.x.l===lv);return one(same.length?same:fresh.length?fresh:tagged.filter(t=>t.x.l<=lv))}
function bankPoolSize(sub,m,lv){if(sub==='logic'){if(m==='odd')return ODD_BANK.filter(x=>x.l<=lv).length;if(m==='rules')return RULES_BANK.filter(x=>x.l<=lv).length;return 8}if(m==='mix')return 8;return (SCIENCE_BANK[m]||[]).filter(x=>x.l<=lv).length}
function logicQuestion(lv,m,used){
 if(m==='lineup')return lineupQuestion(lv);
 if(m==='lpattern')return logicPatternQuestion(lv);
 if(m==='odd'){const t=pickBank(ODD_BANK,lv,used,'odd');return bankQuestionFrom(t.x,'logic-classify','🔍 找出不同類的一個，想想分類的理由',t.sig,false)}
 const t=pickBank(RULES_BANK,lv,used,'rules');return bankQuestionFrom(t.x,'logic-rule','⚖️ 讀懂規則，再判斷結果',t.sig,true);
}
const SCI_PROMPT={body:'💪 運動與身體的科學',force:'🚀 球場上的力與運動',nature:'⛅ 天氣與自然觀察',lab:'🧪 像科學家一樣思考'};
function scienceQuestion(lv,m,used){const area=m==='mix'?one(Object.keys(SCIENCE_BANK)):m;const t=pickBank(SCIENCE_BANK[area],lv,used,'sci-'+area);return bankQuestionFrom(t.x,'sci-'+area,SCI_PROMPT[area],t.sig,true)}
function generateNewSubjectRound(sub,m,lv){const size=Math.min(8,bankPoolSize(sub,m,lv)),list=[],used=new Set();
 for(let i=0;i<size;i++){let q,k=0;do{q=sub==='logic'?logicQuestion(lv,m,used):scienceQuestion(lv,m,used);k++}while(used.has(q.signature)&&k<60);used.add(q.signature);list.push(q)}return list}
function freshNewSubjectReview(item){
 if(item.subject==='logic')return logicQuestion(effectiveLevel('logic',item.level),item.mode,new Set());
 const match=String(item.q.signature||'').match(/^sci-([a-z]+)-(\d+)$/),row=match&&SCIENCE_BANK[match[1]]?.[Number(match[2])];
 if(row&&row.l<=effectiveLevel('science',item.level))return bankQuestionFrom(row,'sci-'+match[1],SCI_PROMPT[match[1]],item.q.signature,true);
 const course=SCI_COURSES.courses.find(c=>c.id===item.q.sciCourseId),ix=Number(String(item.q.signature||'').split('-').slice(-1)[0]),r=course?.questions[ix];
 if(r)return {skill:'sci-'+course.area,prompt:course.title+'｜課後練習',main:r[0],answer:r[1],choices:shuffle(r.slice(1,5)),explain:r[5],signature:'course-'+course.id+'-'+ix,concept:'course-'+course.id,courseLabel:course.title,sciCourseId:course.id,reason:true};
 return scienceQuestion(effectiveLevel('science',item.level),item.mode==='lesson'?'mix':item.mode,new Set());
}

// --- 球場進度：每答對 1 題推進 1 個壘包，4 個壘包回本壘得 1 分 ---
function localDay(d){const x=new Date(d);return x.getFullYear()+'-'+(x.getMonth()+1)+'-'+x.getDate()}
function progressStats(){const today=localDay(Date.now());let todayCorrect=0,total=0;for(const s of data.sessions){total+=s.correct;if(localDay(s.date)===today)todayCorrect+=s.correct}
 return {todayCorrect,todayRuns:Math.floor(todayCorrect/4),runner:todayCorrect%4,toNext:4-todayCorrect%4,careerRuns:Math.floor(total/4),total}}
function dayStreak(){const days=[...new Set(data.sessions.map(s=>localDay(s.date)))].map(d=>{const [y,m,dd]=d.split('-').map(Number);return new Date(y,m-1,dd).getTime()}).sort((a,b)=>a-b);let best=0,cur=0,prev=null;for(const t of days){cur=prev!==null&&Math.round((t-prev)/86400000)===1?cur+1:1;best=Math.max(best,cur);prev=t}return best}
const BADGES=[
 {id:'debut',icon:'🎉',name:'開幕戰',desc:'完成第一回合練習',test:x=>x.sessions>=1},
 {id:'two-way',icon:'⚔️',name:'雙刀流',desc:'同一天練習兩科以上',test:x=>x.multiDay},
 {id:'all-four',icon:'🌈',name:'全能球員',desc:'英文、數學、邏輯、科學都練過',test:x=>x.subjects>=4},
 {id:'perfect',icon:'💯',name:'完全打擊',desc:'一回合全部答對',test:x=>x.perfect},
 {id:'runs10',icon:'🏃',name:'十分打線',desc:'生涯累積得 10 分',test:x=>x.runs>=10},
 {id:'runs50',icon:'🏟️',name:'五十分強打',desc:'生涯累積得 50 分',test:x=>x.runs>=50},
 {id:'runs100',icon:'👑',name:'百分球星',desc:'生涯累積得 100 分',test:x=>x.runs>=100},
 {id:'streak3',icon:'🔥',name:'連續出賽',desc:'連續 3 天都有練習',test:x=>x.streak>=3},
 {id:'streak7',icon:'🛡️',name:'鐵人一週',desc:'連續 7 天都有練習',test:x=>x.streak>=7},
 {id:'review10',icon:'🔁',name:'錯題剋星',desc:'複習題答對 10 題',test:x=>x.reviewHits>=10},
 {id:'logic5',icon:'🧠',name:'戰術大腦',desc:'完成 5 回合邏輯練習',test:x=>x.bySub.logic>=5},
 {id:'science5',icon:'🔬',name:'球場科學家',desc:'完成 5 回合科學練習',test:x=>x.bySub.science>=5}
];
function badgeFacts(){const bySub={english:0,math:0,logic:0,science:0},perDay={};let perfect=false,reviewHits=0;
 for(const s of data.sessions){bySub[s.subject]=(bySub[s.subject]||0)+1;const d=localDay(s.date);(perDay[d]=perDay[d]||new Set()).add(s.subject);if(s.total>=5&&s.correct===s.total)perfect=true;for(const a of s.attempts||[])if(a.review&&a.correct)reviewHits++}
 return {sessions:data.sessions.length,bySub,subjects:Object.values(bySub).filter(Boolean).length,multiDay:Object.values(perDay).some(x=>x.size>=2),perfect,reviewHits,runs:progressStats().careerRuns,streak:dayStreak()}}
function earnedBadgeIds(){const f=badgeFacts();return BADGES.filter(b=>b.test(f)).map(b=>b.id)}
function diamondSvg(runner){const pts={0:[60,104],1:[104,60],2:[60,16],3:[16,60]};const base=(k)=>{const [x,y]=pts[k],on=runner===k&&k>0;return k===0?`<polygon points="${x-7},${y-6} ${x+7},${y-6} ${x+7},${y+1} ${x},${y+7} ${x-7},${y+1}" fill="#fff" stroke="var(--navy)" stroke-width="2"/>`:`<rect x="${x-8}" y="${y-8}" width="16" height="16" transform="rotate(45 ${x} ${y})" fill="${on?'var(--lime)':'#fff'}" stroke="var(--navy)" stroke-width="2"/>`};
 const r=runner>0?`<g transform="translate(${pts[runner][0]},${pts[runner][1]-20})"><circle r="9" fill="var(--yellow)" stroke="var(--navy)" stroke-width="2"/><text y="4" text-anchor="middle" font-size="11">${themeCopy().runner}</text></g>`:'';
 return `<svg class="diamond" viewBox="0 0 120 120" role="img" aria-label="${runner?`跑者在${['','一','二','三'][runner]}壘`:'壘上沒有跑者'}"><polygon points="60,104 104,60 60,16 16,60" fill="#bfe3a9" stroke="#8fc078" stroke-width="2"/><circle cx="60" cy="62" r="6" fill="#e9c79b"/>${[1,2,3,0].map(base).join('')}${r}</svg>`}
function progressCard(){const p=progressStats(),earned=new Set(earnedBadgeIds());
 return `<section class="card ballpark"><div class="ballpark-top"><div>${diamondSvg(p.runner)}</div><div><h3>${themeCopy().ballpark}</h3><p class="ballpark-line">今天答對 <b>${p.todayCorrect}</b> 題＝推進 <b>${p.todayCorrect}</b> 個壘包</p><p class="ballpark-line">今日得分 <b class="runs">${p.todayRuns}</b> 分 · 生涯 <b>${p.careerRuns}</b> 分</p><p class="note" style="margin:6px 0 0">${p.todayCorrect?`再答對 ${p.toNext} 題，跑者就能跑回本壘得分！`:'每答對 1 題推進 1 個壘包，跑完 4 個壘包回本壘得 1 分。'}</p></div></div><details class="badges"><summary>🏅 我的${themeCopy().badgeWord} ${earned.size}／${BADGES.length}</summary><div class="badge-grid">${BADGES.map(b=>`<div class="badge ${earned.has(b.id)?'got':''}" title="${h(b.desc)}"><span>${earned.has(b.id)?b.icon:'🔒'}</span><strong>${h(b.name)}</strong><small>${h(b.desc)}</small></div>`).join('')}</div></details></section>`}

function resultBallpark(s){const p=progressStats(),nb=(s.newBadges||[]).map(id=>BADGES.find(b=>b.id===id)).filter(Boolean);return `<section class="card ballpark-result"><div>${diamondSvg(p.runner)}</div><div><strong>⚾ 這回合推進 ${s.correct} 個壘包</strong><p class="note" style="margin:4px 0 0">今日得分 ${p.todayRuns} 分 · 生涯 ${p.careerRuns} 分</p>${nb.length?`<div class="new-badges">${nb.map(b=>`<span class="badge got"><span>${b.icon}</span><strong>新徽章：${h(b.name)}</strong></span>`).join('')}</div>`:''}</div></section>`}
function selectView(){if(subject==='chinese')return chineseView();const meta=SUBJECT_META[subject],isEn=subject==='english',modes=visibleModes(subject);const due=dueReviews(subject).length;return `<div class="tipline">🌱 學習路線：${meta.route}。${due?`目前有 ${due} 道錯題可以複習。`:'沒有到期複習題，先探索新題目。'}</div><button class="back" data-action="nav-home">← 返回首頁</button><div class="pageheading"><div class="eyebrow">${meta.eyebrow}</div><h1>${meta.title}</h1><p>${meta.desc}</p></div>${isEn?`<section class="alpha-intro"><div><div class="eyebrow">${worldInfo().step}</div><strong>🔡 第一站｜認識 26 個英文字母</strong><p>每張字母卡都能聽字母與例字；可從 A 一張一張往下學。</p></div><button class="btn btn-dark" data-action="alphabet">🔊 開始學 ABC →</button></section>`:''}${subject==='zhuyin'?`<section class="alpha-intro"><div><div class="eyebrow">${worldInfo().step}</div><strong>ㄅ 第一站｜認識 37 個注音符號</strong><p>每張符號卡都有圖和語詞，可以聽聲音、跟著唸。</p></div><button class="btn btn-dark" data-action="zy-cards">🔊 開始看符號卡 →</button></section>`:''}${subject==='math'?'<section class="alpha-intro"><div><strong>✖️ 九九乘法表</strong><p>1～9 全部混合、獨立練習，不受數學難度影響。</p></div><button class="btn btn-dark" data-action="times-open">開始學九九乘法 →</button></section>':''}${subject==='science'?'<section class="alpha-intro"><div><strong>📖 科學小教室｜先學習，再練習</strong><p>12 堂可聽讀課程，包含 8 堂太空課程；本風格共 '+Object.values(SCIENCE_BANK).reduce((n,a)=>n+a.length,0)+' 道科學題目。</p></div><div class="times-actions"><button class="btn btn-dark" data-action="sci-open">先學科學 →</button><button class="btn btn-outline" data-action="sci-open" data-area="space">🪐 太空課程 →</button></div></section>':''}<p class="tipline">${h(gradeNote(subject))}</p><div class="modegrid">${modes.map(m=>`<button class="mode" data-action="start" data-mode="${m.id}"><span class="badge">${m.label}</span><div class="mode-icon" aria-hidden="true">${m.icon}</div><h3>${m.name} →</h3><p>${m.desc}</p></button>`).join('')}</div><div class="levelstrip"><div>🎚️ 目前難度：<strong>第 ${effectiveLevel(subject)} 級／${LEVEL_NAMES[effectiveLevel(subject)-1]}（依年級調整）</strong><br><span>${meta.levelNote}</span></div><button data-action="nav-parent">家長設定</button></div><section class="card" style="margin-top:17px"><h3>👨‍👩‍👧 給陪練大人的提醒</h3><p class="note" style="margin:0">${meta.tip}</p></section>`}
const SKILL_GROUPS={english:['en-letters','en-vocab','en-use','en-sentence','en-listening','en-inference','en-order','en-context'],math:['math-calc','math-story','math-score','math-reason','math-data','math-money','math-pattern','math-measure'],logic:['logic-order','logic-pattern','logic-classify','logic-rule'],science:['sci-body','sci-force','sci-nature','sci-lab']};



const SCI_COURSES=window.EXPLORER_SCIENCE;
SCIENCE_BANK.space=[];
SKILLS['sci-space']='太空與星體';SKILL_GROUPS.science.push('sci-space');
MODES.science.splice(4,0,{id:'space',icon:'🪐',name:'太空探索練習',label:'太空與星體',desc:'認識太陽、行星、地球、月亮與觀察方法。',skill:'sci-space'});
MODES.science.push({id:'lesson',icon:'📖',name:'課後小練習',label:'先學再練',desc:'讀完小課程，再回答對應的問題。',skill:'sci-mix',grades:[]});
SCI_PROMPT.space='🪐 太空與星體探索';
let sciArea='all',sciCourse='',sciPlanet=2;
function installScienceCourses(){for(const c of SCI_COURSES.courses)for(const r of c.questions)SCIENCE_BANK[c.area].push({l:c.level,q:r[0],a:r[1],o:r.slice(1,5),e:r[5],courseId:c.id})}
function scienceCourseRound(){
 const c=SCI_COURSES.courses.find(c=>c.id===sciCourse)||SCI_COURSES.courses[0];
 return shuffle(c.questions.map((r,i)=>({skill:'sci-'+c.area,prompt:c.icon+' '+c.title+'｜課後練習',main:r[0],answer:r[1],choices:shuffle(r.slice(1,5)),explain:r[5],signature:'course-'+c.id+'-'+i,concept:'course-'+c.id,courseLabel:c.title,sciCourseId:c.id,reason:true})));
}
function scienceLearnPage(){
 const course=SCI_COURSES.courses.find(c=>c.id===sciCourse);
 const tabs='<div class="cn-tabs" role="group" aria-label="科學課程分類">'+[['all','全部課程'],['core','生活科學'],['space','太空課程']].map(([id,name])=>'<button class="btn '+(sciArea===id?'btn-dark':'btn-outline')+'" data-action="sci-area" data-area="'+id+'" aria-pressed="'+(sciArea===id)+'">'+name+'</button>').join('')+'</div>';
 if(course)return '<button class="back" data-action="sci-list">← 回課程列表</button><div class="pageheading"><div class="eyebrow">先學習，再練習 · 每堂約 3～5 分鐘</div><h1>'+course.icon+' '+h(course.title)+'</h1></div><section class="card sci-reading"><button class="btn btn-outline" data-action="sci-read">🔊 聽這堂課</button><ol>'+course.points.map(p=>'<li>'+h(p)+'</li>').join('')+'</ol><div class="sci-activity"><h2>一起做做看</h2><p>'+h(course.activity)+'</p></div><button class="btn btn-dark" data-action="sci-practice">我學完了，練習 3 題 →</button>'+(course.source?'<p class="note"><a href="'+course.source+'" target="_blank" rel="noopener">科學參考：NASA</a> · 本站自編中文課程</p>':'')+'</section>';
 const courses=SCI_COURSES.courses.filter(c=>sciArea==='all'||(sciArea==='space'?c.area==='space':c.area!=='space'));
 const planet=SCI_COURSES.planets[sciPlanet];
 return '<button class="back" data-action="sci-back">← 返回科學</button><div class="pageheading"><h1>🔬 科學小教室</h1><p>先看圖文或聽讀，做個小觀察，再練習 3 題。共 12 堂課，其中 8 堂是太空課程。</p></div>'+tabs+
 (sciArea!=='core'?'<section class="card planet-explorer"><h2>☀️ 八大行星排排站</h2><p class="note">由靠近太陽到較遠排列。這是示意圖，大小、間距與顏色不代表精確比例。</p><div class="planet-grid" role="group" aria-label="選擇行星">'+SCI_COURSES.planets.map((p,i)=>'<button data-action="sci-planet" data-index="'+i+'" aria-pressed="'+(i===sciPlanet)+'"><span class="planet-orb" style="--planet-color:'+p.color+'"></span><strong>'+p.name+'</strong><small>第 '+p.order+' 顆</small></button>').join('')+'</div><div class="planet-fact" role="status"><strong>'+planet.name+'</strong><p>'+h(planet.fact)+'</p><button class="btn btn-outline" data-action="sci-planet-read">🔊 聽行星介紹</button></div></section>':'')+
 '<div class="modegrid">'+courses.map(c=>'<button class="mode" data-action="sci-course" data-course="'+c.id+'"><span class="badge">'+(c.area==='space'?'太空探索':'生活科學')+' · 3 題課後練習</span><div class="mode-icon" aria-hidden="true">'+c.icon+'</div><h2>'+h(c.title)+'</h2><p>'+h(c.points[0])+'</p></button>').join('')+'</div>';
}

let timesRow=0,timesHidden=false,timesRevealed=new Set();
MODES.math.unshift({id:'times',icon:'✖️',name:'九九乘法練習',label:'1～9 乘法',desc:'隨機練習九九乘法，答錯的題目會加入複習。',skill:'math-times'});
SKILLS['math-times']='九九乘法';SKILL_GROUPS.math.push('math-times');
function timesBank(row=0){
 return (row===0?[1,2,3,4,5,6,7,8,9]:[row]).flatMap(a=>Array.from({length:9},(_,i)=>{
 const b=i+1,n=a*b,wrong=shuffle(Array.from({length:81},(_,j)=>String(j+1)).filter(x=>Number(x)!==n)).slice(0,3);
 return {skill:'math-times',prompt:'九九乘法｜'+a+' 的乘法',main:a+' × '+b+' ＝ ？',answer:String(n),choices:shuffle([String(n),...wrong]),explain:a+' × '+b+' ＝ '+n+'。'+Array(b).fill(a).join('＋')+'＝'+n+'，每次多 '+a+'。',hint:'把 '+a+' 加 '+b+' 次；也可以從記住的乘法往上加。',concept:'times-'+a+'-'+b,signature:'times-'+a+'-'+b,reason:true};
 }));
}
function timesRound(){const recent=new Set(data.recent?.['math:times']||[]);return shuffle(timesBank(0)).sort((a,b)=>Number(recent.has(a.signature))-Number(recent.has(b.signature))).slice(0,data.settings.roundSize||8)}
function timesPage(){
 const rows=[1,2,3,4,5,6,7,8,9];
 return '<button class="back" data-action="times-back">← 返回數學</button><div class="pageheading"><div class="eyebrow">MULTIPLICATION · 1～9</div><h1>✖️ 九九乘法表</h1><p>1～9 全部一起練，不分難度。先看表、跟著念，再遮住答案自測。</p></div>'+
 '<section class="card times-tools"><h2>'+('完整九九乘法表')+'</h2><p class="note">每張卡片可聽算式；遮住答案時，按「看答案」再核對。</p><div class="times-actions"><button class="btn btn-outline" data-action="times-hide">'+(timesHidden?'顯示全部答案':'遮住答案自測')+'</button><button class="btn btn-dark" data-action="times-practice">開始'+('1～9 混合')+'乘法練習 →</button></div><p class="note">朗讀使用手機內建中文語音。練習紀錄與錯題會儲存在目前的小朋友資料。</p></section>'+
 '<div class="times-sections">'+rows.map(a=>'<section class="card"><h2>'+a+' 的乘法</h2><div class="times-cards">'+Array.from({length:9},(_,i)=>{const b=i+1,key=a+'-'+b,shown=!timesHidden||timesRevealed.has(key);return '<div class="times-card"><strong>'+a+' × '+b+' ＝ <span>'+(shown?a*b:'？')+'</span></strong><div><button data-action="times-speak" data-a="'+a+'" data-b="'+b+'" aria-label="聽 '+a+' 乘以 '+b+(shown?' 的答案':' 的題目')+'">🔊 '+(shown?'聽算式':'聽題目')+'</button>'+(shown?'':'<button data-action="times-reveal" data-a="'+a+'" data-b="'+b+'">看答案</button>')+'</div></div>'}).join('')+'</div></section>').join('')+'</div><section class="card"><h3>記不住時，這樣想</h3><p>例如 6 × 7 想不起來，先想 6 × 6 ＝ 36，再加一個 6，就是 42。交換兩個數字，乘積也一樣：6 × 7 ＝ 7 × 6。</p><button class="btn btn-outline" data-action="times-stop">停止朗讀</button></section>';
}


const CN_VOCAB=window.HOMERUN_CHINESE_VOCAB;
let dictKind='word',dictCount=10,dictExam=null;
const DICT_CUES={"年":"新年","希":"希望","望":"希望","坐":"坐下","位":"位子","本":"課本","淡":"淡淡","書":"書本","老":"老師","師":"老師","以":"以前","為":"成為","故":"故事","用":"用力","力":"用力","只":"只有","現":"現在","還":"還有","中":"中間","乾":"風乾","行":"旅行","難":"難道","少":"多少","相":"相反","待":"等待","衣":"衣服","哪":"哪裡","切":"切開","吐":"吐司","假":"暑假","幾":"幾個","沖":"沖水","發":"發現","朝":"朝陽","蛋":"雞蛋","煎":"煎蛋","夾":"夾子","畫":"畫圖","貓":"小貓","屋":"房屋","忙":"幫忙","娶":"娶妻","飄":"飄揚","哇":"哇哇叫","往":"來往","腳":"雙腳","帶":"帶路","跨":"跨過","吹":"吹風","排":"排隊","月":"月亮","買":"買菜","胖":"胖胖","針":"針線","棒":"棒球","眼":"眼睛","喝":"喝水","裝":"裝滿","忘":"忘記","哈":"哈哈笑","腿":"大腿","砍":"砍斷","牽":"牽手","沿":"沿路","卻":"退卻","皮":"皮膚","飛":"飛機","嘴":"嘴巴","伸":"伸手","飽":"吃飽","站":"站立","灰":"灰色","涼":"涼風","冰":"冰塊"};
function dictSource(){return cnSelected().map(l=>({lesson:l,vocab:CN_VOCAB.lessons[l.id]})).filter(x=>x.vocab)}
function dictItems(){
 const out=[];
 for(const {lesson,vocab} of dictSource()){
  const label=cnLabel(lesson);
  if(dictKind!=='word')for(const char of vocab.characters){
   const cue=DICT_CUES[char]||vocab.words.find(w=>w.includes(char))||Object.values(CN_VOCAB.lessons).flatMap(l=>l.words).find(w=>w.includes(char))||CN.words.find(w=>w[0].includes(char))?.[0];
   if(!cue||!cue.includes(char))throw Error('Missing dictation context: '+char);
   const position=[...cue].indexOf(char)+1;
   out.push({answer:char,label,kind:'生字',speech:cue+'。請寫這個詞的第'+position+'個字。'});
  }
  if(dictKind!=='char')for(const word of vocab.words)out.push({answer:word,label,kind:'語詞',speech:word+'。請寫'+[...word].length+'個字。'});
 }
 const seen=new Set();return out.filter(x=>{const key=x.kind+':'+x.answer;if(seen.has(key))return false;seen.add(key);return true});
}
function startDictation(){const pool=shuffle(dictItems());if(!pool.length){toast('這個學期的教材清單尚未核對，請先選二上。');return false}if(!('speechSynthesis' in window)){toast('此瀏覽器不支援朗讀，請改用手機 Chrome 或 Safari。');return false}stopEnglish();dictExam={items:pool.slice(0,dictCount||pool.length),index:0,answers:false};render();window.scrollTo(0,0);return true}
function playDictation(){if(!dictExam)return;const q=dictExam.items[dictExam.index];speakChinese(['第'+(dictExam.index+1)+'題。',q.speech,'再聽一次。',q.speech])}
function dictationPage(){
 if(dictExam){
  const e=dictExam;
  if(e.answers)return '<button class="back" data-action="dict-setup">← 回聽寫設定</button><div class="pageheading"><h1>📝 聽寫答案卷</h1><p>請家長對照紙本批改。本功能不會辨識或自動評分紙上的字。</p></div><button class="btn btn-outline" data-action="dict-resume">隱藏答案，返回考試</button><ol class="dict-answers">'+e.items.map((q,i)=>'<li><strong>'+h(q.answer)+'</strong><small>'+h(q.kind+' · '+q.label)+'</small></li>').join('')+'</ol>';
  return '<button class="back" data-action="dict-setup">← 回聽寫設定</button><section class="card dict-exam"><div class="eyebrow">紙本聽寫 · '+(dictKind==='char'?'生字':dictKind==='word'?'語詞':'生字＋語詞')+'</div><h1>第 '+(e.index+1)+'／'+e.items.length+' 題</h1><p>準備紙和筆，寫下聽到的字詞。</p><p>答案已隱藏。寫完再按下一題，不限時間。</p><button class="btn btn-dark dict-play" data-action="dict-play">🔊 播放本題（念兩次）</button><div class="times-actions"><button class="btn btn-outline" data-action="dict-prev" '+(e.index===0?'disabled':'')+'>← 上一題</button><button class="btn btn-dark" data-action="dict-next">'+(e.index===e.items.length-1?'寫完了，看答案':'下一題 →')+'</button><button class="btn btn-outline" data-action="dict-stop">停止播放</button></div><p class="note">可重複播放；每個生字都附詞語與字序提示，避免單讀多音字。語音由裝置提供，請家長先試聽多音字。</p></section>';
 }
 const source=dictSource(),pool=dictItems();
 return '<button class="back" data-action="dict-back">← 返回國語</button><div class="pageheading"><h1>📒 生字、圈詞與紙本聽寫</h1><p>範圍沿用國語頁選擇的學期與課次。</p></div><div class="cn-edition '+(source.length?'verified':'pending')+'"><strong>'+h(cnSemester==='upper'?'115 二上｜教育雲生字詞彙表':'二下教材清單待核對')+'</strong><p>語詞清單供圈詞練習使用；老師實際圈選的範圍請以課本為準。認讀字另列，不放進生字聽寫。</p></div>'+
 '<section class="card"><h2>播音考試，寫在紙上</h2><div class="dict-settings"><label>聽寫內容<select data-action="dict-kind"><option value="word" '+(dictKind==='word'?'selected':'')+'>語詞（圈詞練習）</option><option value="char" '+(dictKind==='char'?'selected':'')+'>生字</option><option value="mix" '+(dictKind==='mix'?'selected':'')+'>生字＋語詞</option></select></label><label>題數<select data-action="dict-count">'+[10,20,0].map(n=>'<option value="'+n+'" '+(dictCount===n?'selected':'')+'>'+(n?n+' 題':'全部')+'</option>').join('')+'</select></label></div><p>目前範圍共 '+pool.length+' 個不重複項目，隨機出題。開始後不顯示文字答案；寫完再核對。</p><button class="btn btn-dark" data-action="dict-start" '+(!pool.length?'disabled':'')+'>🎧 開始紙本聽寫</button></section>'+
 '<div class="times-sections">'+source.map(({lesson,vocab})=>'<details class="card dict-vocab"><summary>'+h(cnLabel(lesson))+' · 生字 '+vocab.characters.length+'／語詞 '+vocab.words.length+'</summary><h3>本課生字</h3><div class="dict-wordlist">'+vocab.characters.map(w=>'<button data-action="dict-word" data-word="'+h(w)+'">'+h(w)+'</button>').join('')+'</div><h3>認讀字（認識即可）</h3><div class="dict-wordlist">'+vocab.recognition.map(w=>'<button data-action="dict-word" data-word="'+h(w)+'">'+h(w)+'</button>').join('')+'</div><h3>語詞／圈詞練習</h3><div class="dict-wordlist">'+vocab.words.map(w=>'<button data-action="dict-word" data-word="'+h(w)+'">'+h(w)+'</button>').join('')+'</div><p><a href="'+vocab.source+'" target="_blank" rel="noopener">教育雲本課清單</a></p></details>').join('')+'</div>';
}

const CN=window.HOMERUN_CHINESE;
SUBJECT_KEYS.push('chinese');
SUBJECT_META.chinese={name:'國語',icon:'📚',eyebrow:'CHINESE · GRADE 2',title:'📚 國語練習場',route:'選學期與課次 → 字詞 → 句型 → 原創閱讀',desc:'二上依 115 學年度康軒課次編排；二下先提供原創能力練習，課次待核對。',tip:'先一起讀字詞，再讓孩子說說短文中的線索。題目與短文為本站自編，可搭配實體課本使用。',tile:'二上課次練習、二下原創先修',levelNote:'本區固定以二年級能力設計，依學期與課次選題。'};
Object.assign(SKILLS,{'cn-phonetic':'國語字音','cn-vocab':'國語詞義','cn-sentence':'國語句型與表達','cn-reading':'國語閱讀理解'});
SKILL_GROUPS.chinese=['cn-phonetic','cn-vocab','cn-sentence','cn-reading'];
MODES.chinese=[
{id:'mix',icon:'🎒',name:'綜合練習',label:'主題綜合',desc:'字音、詞義、句型和原創短文一起練習。',skill:'cn-vocab'},
{id:'word',icon:'🔤',name:'字詞練習',label:'字音與詞義',desc:'認識主題詞語的注音與意思；詞語為本站自編延伸。',skill:'cn-vocab'},
{id:'sentence',icon:'✏️',name:'句型與表達',label:'句子練習',desc:'選出完整、通順而符合情境的句子。',skill:'cn-sentence'},
{id:'reading',icon:'📖',name:'原創閱讀',label:'找線索與推理',desc:'閱讀本站短文，練習人物、順序、原因與主旨。',skill:'cn-reading'},
{id:'review',icon:'🔁',name:'國語錯題複習',label:'個人化複習',desc:'重新思考先前答錯的國語題目。',skill:'cn-reading'}];
let cnSemester='upper',cnLesson='all';
function cnLabel(lesson){return lesson.semester==='upper'?'二上第 '+Number(lesson.id.split('-')[1])+' 課 · '+lesson.title:'二下先修 '+Number(lesson.id.split('-')[1])+' · '+lesson.title}
function cnSelected(){return CN.lessons.filter(l=>l.semester===cnSemester&&(cnLesson==='all'||l.id===cnLesson))}
function cnChoices(value,pool){const other=shuffle([...new Set(pool)].filter(x=>x!==value)).slice(0,3);return shuffle([value,...other])}
function cnBank(lessons=cnSelected()){
 const dict=new Map(CN.words.map(w=>[w[0],w])),bank=[];
 for(const lesson of lessons){
  const base={concept:'cn-'+lesson.id,courseLabel:cnLabel(lesson),cnLessonId:lesson.id};
  lesson.words.forEach((word,i)=>{
   const row=dict.get(word);if(!row)throw new Error('Unknown Chinese word: '+word);
   bank.push({...base,skill:'cn-phonetic',kind:'word',prompt:base.courseLabel+'｜主題字音',main:'「'+word+'」的正確注音是哪一個？',answer:row[1],choices:cnChoices(row[1],CN.words.map(w=>w[1])),explain:word+'的注音是「'+row[1]+'」。',signature:'cn-'+lesson.id+'-phonetic-'+i,noReadOptions:true});
   bank.push({...base,skill:'cn-vocab',kind:'word',prompt:base.courseLabel+'｜主題詞義',main:'「'+word+'」在生活中是什麼意思？',answer:row[2],choices:cnChoices(row[2],CN.words.map(w=>w[2])),explain:word+'：'+row[2]+'。',signature:'cn-'+lesson.id+'-vocab-'+i});
  });
  lesson.sentences.forEach((r,i)=>bank.push({...base,skill:'cn-sentence',kind:'sentence',prompt:base.courseLabel+'｜原創句型',main:r[0],answer:r[1],choices:shuffle(r.slice(1,5)),explain:r[5],signature:'cn-'+lesson.id+'-sentence-'+i,reason:true}));
  lesson.read.forEach((r,i)=>bank.push({...base,skill:'cn-reading',kind:'reading',prompt:base.courseLabel+'｜原創延伸短文',main:lesson.story,second:r[0],answer:r[1],choices:shuffle(r.slice(1,5)),explain:r[5],signature:'cn-'+lesson.id+'-reading-'+i,readingOnly:true}));
 }
 return bank;
}
function generateChineseRound(m){
 const recent=new Set(data.recent?.['chinese:'+m]||[]);
 const pool=shuffle(cnBank().filter(q=>m==='mix'||q.kind===m));
 pool.sort((a,b)=>Number(recent.has(a.signature))-Number(recent.has(b.signature)));
 return pool.slice(0,data.settings.roundSize||8);
}
function chineseView(){
 const info=CN[cnSemester],lessons=CN.lessons.filter(l=>l.semester===cnSemester),chosen=lessons.find(l=>l.id===cnLesson),due=dueReviews('chinese').length;
 const progress=id=>data.sessions.flatMap(s=>s.attempts||[]).filter(a=>a.concept==='cn-'+id).length;
 return '<button class="back" data-action="nav-home">← 返回首頁</button><div class="pageheading"><div class="eyebrow">CHINESE · 二年級</div><h1>📚 國語練習場</h1><p>搭配課本，練習字詞、句型和閱讀。</p></div>'+
 '<div class="cn-tabs" role="group" aria-label="選擇國語學期"><button class="btn '+(cnSemester==='upper'?'btn-dark':'btn-outline')+'" data-action="cn-semester" data-semester="upper" aria-pressed="'+(cnSemester==='upper')+'">二上｜115 學年度</button><button class="btn '+(cnSemester==='lower'?'btn-dark':'btn-outline')+'" data-action="cn-semester" data-semester="lower" aria-pressed="'+(cnSemester==='lower')+'">二下｜原創先修</button></div>'+
 '<div class="cn-edition '+(info.verified?'verified':'pending')+'"><strong>'+(info.verified?'115 二上課次已核對':'115 二下課次待核對')+'</strong><p>'+h(info.note)+'</p></div>'+
 '<section class="card cn-picker"><label for="cn-lesson-select">選擇'+(cnSemester==='upper'?'課次':'練習主題')+'</label><select id="cn-lesson-select" data-action="cn-lesson"><option value="all" '+(cnLesson==='all'?'selected':'')+'>全部'+(cnSemester==='upper'?'課次':'主題')+'混合練習</option>'+lessons.map(l=>'<option value="'+l.id+'" '+(cnLesson===l.id?'selected':'')+'>'+h(cnLabel(l))+'</option>').join('')+'</select><p class="note">目前選擇：'+(chosen?h(cnLabel(chosen)):'全學期主題')+'。每回合最多 '+(data.settings.roundSize||8)+' 題；單課題數較少時不重複出題。</p></section>'+
 (chosen?'<section class="card cn-preview"><h2>'+h(chosen.title)+'</h2><p class="note">主題語詞（本站自編延伸，並非課本完整生字表）</p><div class="cn-word-list">'+chosen.words.map(word=>{const w=CN.words.find(r=>r[0]===word);return '<button type="button" data-action="cn-read-word" data-word="'+h(word)+'"><strong>'+h(word)+'</strong><small>'+h(w[1])+'</small></button>'}).join('')+'</div><details><summary>📖 先讀原創延伸短文</summary><p class="cn-story">'+h(chosen.story)+'</p><button type="button" class="btn btn-outline" data-action="cn-read-story">🔊 聽原創短文</button></details></section>':'')+
 '<section class="alpha-intro"><div><strong>📒 本課生字、圈詞與紙本聽寫</strong><p>查看教育雲完整生字語詞清單，手機播音，孩子在紙上寫。</p></div><button class="btn btn-dark" data-action="dict-open">生字圈詞・播音聽寫 →</button></section><div class="section-title"><h2>選一種方式練習</h2></div><div class="modegrid">'+MODES.chinese.map(m=>'<button class="mode" data-action="start" data-mode="'+m.id+'" '+(m.id==='review'&&!due?'disabled':'')+'><span class="badge">'+m.label+'</span><div class="mode-icon" aria-hidden="true">'+m.icon+'</div><h3>'+m.name+(m.id==='review'?' · '+due+' 題':'')+'</h3><p>'+m.desc+'</p></button>').join('')+'</div>'+
 '<div class="section-title"><h2>'+(cnSemester==='upper'?'課次一覽':'原創先修主題')+'</h2></div><div class="cn-lessons">'+lessons.map(l=>'<button data-action="cn-pick" data-lesson="'+l.id+'" aria-pressed="'+(cnLesson===l.id)+'"><small>'+(cnSemester==='upper'?'第 ':'先修 ')+Number(l.id.split('-')[1])+(cnSemester==='upper'?' 課':'')+'</small><strong>'+h(l.title)+'</strong><span>'+progress(l.id)+' 題練習紀錄</span></button>').join('')+'</div>'+
 '<section class="card cn-source"><h3>給陪練家長</h3><p>先讓孩子說說選答案的線索，再看解析。閱讀短文、句型與字詞練習由本站原創，不是康軒課文或習作原題。</p><p><a href="'+CN.source+'" target="_blank" rel="noopener">查看 115 二上課次參考來源</a>。二下正式課次待取得目錄後核對。</p></section>';
}

function levelRow(sub,id,note){return `<div class="settings-row"><label for="${id}">${subName(sub)}難度<small>${note}</small></label><select id="${id}" data-action="level" data-subject="${sub}">${[1,2,3,4].map(v=>`<option value="${v}" ${data.settings[sub]===v?'selected':''}>${v} ${LEVEL_NAMES[v-1]}</option>`).join('')}</select></div>`}


// ===== v25：多位球員、注音、中文朗讀、年級模式、主題 =====
// --- 球員檔案：第一位球員沿用原本的紀錄位置，舊資料完全不搬動 ---
const PROFILES_KEY='homerun_profiles_v1';
const GRADES={k:'幼兒園大班',g1:'一年級',g2:'二年級',g3:'三年級以上'};
const AVATARS=['⚾','🧢','🐰','🐱','🦄','🦖','🐼','🌟','🚀','🌸','🐯','🐬'];
const THEMES={field:{name:'棒球',icon:'⚾'},space:{name:'太空探險',icon:'🚀'}};
function cleanProfile(p){if(!p||typeof p!=='object'||typeof p.id!=='string'||!/^p[0-9a-z]{1,16}$/.test(p.id))return null;return {id:p.id,name:String(p.name||'球員').slice(0,12),avatar:AVATARS.includes(p.avatar)?p.avatar:'⚾',grade:GRADES[p.grade]?p.grade:'g2',theme:THEMES[p.theme]?p.theme:'field'}}
function loadProfiles(){try{const raw=JSON.parse(localStorage.getItem(PROFILES_KEY)||'null');const list=Array.isArray(raw?.list)?raw.list.map(cleanProfile).filter(Boolean).slice(0,6):[];if(list.length){const active=list.some(p=>p.id===raw.active)?raw.active:list[0].id;return {active,list}}}catch(_){}
 return {active:'p1',list:[{id:'p1',name:'球員 1',avatar:'⚾',grade:'g2',theme:'field'}]}}
let profiles=loadProfiles();
function saveProfiles(){try{localStorage.setItem(PROFILES_KEY,JSON.stringify(profiles))}catch(_){}}
function activeProfile(){return profiles.list.find(p=>p.id===profiles.active)||profiles.list[0]}
function dataKeyFor(id){return id==='p1'?'baseball_dualtrack_v1':'baseball_dualtrack_v1__'+id}
function dataKey(){return dataKeyFor(activeProfile().id)}
function grade(){return activeProfile().grade}
const GRADE_PRESETS={k:{english:1,math:1,logic:1,science:1,zhuyin:1,autoRead:true,roundSize:5},g1:{english:1,math:1,logic:1,science:1,zhuyin:2,autoRead:true},g2:{english:1,math:1,logic:1,science:1,zhuyin:2,autoRead:false},g3:{english:2,math:2,logic:2,science:2,zhuyin:3,autoRead:false}};
function applyProfileLook(){const p=activeProfile();try{document.body.dataset.theme=p.theme;document.body.classList.toggle('kid',p.grade==='k')}catch(_){}}

// --- 科目與題型依年級顯示 ---
SUBJECT_KEYS.push('zhuyin');
SUBJECT_META.zhuyin={name:'注音',icon:'ㄅ',eyebrow:'ZHUYIN · ㄅㄆㄇ',title:'ㄅ 注音練習場',route:'符號卡 → 聽音找符號 → 看圖找注音 → 聲調 → 拼音',desc:'從 37 個注音符號開始，聽一聽、看一看，再學聲調和拼音。每題都可以按 🔊 聽題目。',tip:'每個注音符號都有錄好的標準發音，點符號就能聽。建議「聽一次、跟著唸三次」；先練「聽音找符號」，熟了再練聲調、拼音和語詞注音。',tile:'37 個符號、聲調、拼音',levelNote:'第1級：符號辨認；第2級：加入聲調與拼音，選項更相近；第3級：容易混淆的符號一起出現。'};
const ZHUYIN_MODES=[{id:'listen',icon:'👂',name:'聽音找符號',label:'符號辨認',desc:'聽聲音，找出正確的注音符號。',skill:'zy-symbol'},{id:'picture',icon:'🖼️',name:'看圖找注音',label:'語詞開頭',desc:'看圖聽語詞，找出第一個注音。',skill:'zy-picture'},{id:'tone',icon:'🎵',name:'四個聲調',label:'聲調',desc:'一聲、二聲、三聲、四聲，聽聽看、認認看。',skill:'zy-tone'},{id:'spell',icon:'🧩',name:'拼一拼',label:'拼音',desc:'聽一個字的聲音，找出它的注音拼法。',skill:'zy-spell'},{id:'review',icon:'🔁',name:'注音錯題補強',label:'個人化複習',desc:'把不熟的符號再練一次。',skill:'zy-review'}];
MODES.zhuyin=ZHUYIN_MODES;
const KID_MATH_MODES=[{id:'count',icon:'🔢',name:'數一數',label:'數數',desc:'數數看有幾個，認識 1 到 20。',skill:'math-count',grades:['k','g1']},{id:'compare',icon:'⚖️',name:'比大小',label:'數的大小',desc:'找出最大或最小的數字。',skill:'math-compare',grades:['k','g1']},{id:'add10',icon:'🍎',name:'看圖加減',label:'10 以內加減',desc:'看圖片算加法和減法。',skill:'math-add10',grades:['k','g1']}];
MODES.math.unshift(...KID_MATH_MODES);
Object.assign(SKILLS,{'zy-symbol':'注音符號辨認','zy-picture':'語詞開頭注音','zy-tone':'聲調','zy-spell':'拼音','zy-review':'注音複習','math-count':'數數','math-compare':'數的大小','math-add10':'10以內加減'});
SKILL_GROUPS.zhuyin=['zy-symbol','zy-picture','zy-tone','zy-spell'];SKILL_GROUPS.math.unshift('math-count','math-compare','math-add10');
// 大班只顯示適合的題型；一年級隱藏太難的閱讀
const HIDE_BY_GRADE={
 k:{english:['sentence','use','deep','spell','order'],math:['calc','story','score','reason','pattern','measure','challenge'],logic:['lineup','rules','sudoku','truth'],zhuyin:['spell','word']},
 g1:{english:['sentence','use','deep','order'],math:['reason','pattern','measure','challenge'],logic:['lineup','rules','truth']},
 g2:{english:['use','deep'],math:['challenge'],logic:['truth']}
};
function effectiveLevel(sub,requested=data.settings[sub]){
 const n=Math.min(4,Math.max(1,Number(requested)||1)),g=grade();
 if(g==='g3'||sub==='chinese')return n;
 if(g==='k')return 1;
 if(g==='g1')return Math.min(n,sub==='zhuyin'?2:1);
 return Math.min(n,sub==='math'||sub==='english'||sub==='logic'||sub==='science'?1:3);
}
function canPractice(sub,m){
 if(!subjectsForGrade().includes(sub))return false;
 if(sub==='science'&&m==='lesson')return true;
 return visibleModes(sub).some(x=>x.id===m);
}
function gradeNote(sub){
 const g=grade();
 if(sub==='english'&&g!=='g3')return '英語啟蒙延伸：以字母、聽音和基礎單字為主，並非低年級必修課程。';
 if(sub==='science'&&g!=='g3')return '生活觀察與科學啟蒙：先聽課程、動手觀察；太空內容屬延伸探索，建議大人陪讀。';
 if(sub==='math')return g==='k'?'以數數、大小和10以內圖像加減為主；九九乘法保留完整1～9，屬自主延伸。':g==='g1'?'以加減與生活情境為主；九九乘法保留完整1～9，屬自主延伸。':g==='g2'?'以加減、乘法、兩步驟情境與具體測量為主。':'三年級以上共用題庫，進階挑戰含跨年級內容，請按孩子能力調整。';
 return g==='g3'?'三年級以上共用題庫；國語為二年級複習，其餘科目按能力選擇難度。':'依年級提供入門題型；可按朗讀並由大人陪練。';
}
function gradeCalculation(lv){
 const max=grade()==='k'?10:grade()==='g1'?20:lv===1?99:999;
 if(grade()==='g2'&&rand(0,2)===2){const a=rand(1,9),b=rand(1,9),n=a*b;return {skill:'math-calc',prompt:'算一算，選出正確答案',main:`${a} × ${b} ＝ ?`,answer:String(n),choices:choicesForAnswer(n,1),explain:`${a} 組，每組 ${b} 個，共 ${n} 個。`,signature:'grade-times-'+a+'-'+b}}
 const a=rand(1,max),add=rand(0,1)===0,b=rand(0,add?max-a:a),n=add?a+b:a-b,op=add?'＋':'−';
 return {skill:'math-calc',prompt:'算一算，選出正確答案',main:`${a} ${op} ${b} ＝ ?`,answer:String(n),choices:choicesForAnswer(n,1),explain:`${a} ${add?'加上':'減去'} ${b}，得到 ${n}。`,signature:'grade-calc-'+a+op+b};
}
function gradeStoryQuestion(){
 const a=rand(2,12),add=rand(0,1)===0,b=rand(1,add?20-a:a),n=add?a+b:a-b;
 return {skill:'math-story',prompt:'生活中的加減法',main:add?`盒子裡有 ${a} 顆球，又放進 ${b} 顆，現在共有幾顆？`:`盒子裡有 ${a} 顆球，拿走 ${b} 顆，還剩幾顆？`,answer:String(n),choices:choicesForAnswer(n,1),explain:`${a} ${add?'＋':'−'} ${b}＝${n} 顆。`,signature:'grade-story-'+a+(add?'+':'-')+b};
}
function practiceQuestions(sub,m,requested){
 if(!canPractice(sub,m))return [];
 const lv=effectiveLevel(sub,requested),g=grade();
 applyWorld();
 if(sub==='math'&&m==='calc'&&g!=='g3')return roundFrom(()=>worldize(gradeCalculation(lv),currentWorld()),data.settings.roundSize||8);
 if(sub==='math'&&m==='story'&&g==='g1')return roundFrom(()=>worldize(gradeStoryQuestion(),currentWorld()),data.settings.roundSize||8);
 if(sub==='math'&&m==='measure'&&g==='g2')return roundFrom(()=>worldize(measureQuestion(1,one([0,1,3,4,5,7])),currentWorld()),data.settings.roundSize||8);
 return generateQuestions(sub,m,lv);
}
function handCalculation(){return grade()==='g3'?calcQuestion(effectiveLevel('math')):gradeCalculation(effectiveLevel('math'))}
function visibleModes(sub){const g=grade(),hide=HIDE_BY_GRADE[g]?.[sub]||[];return MODES[sub].filter(m=>!hide.includes(m.id)&&(!m.grades||m.grades.includes(g)))}
function subjectsForGrade(){const g=grade();return g==='k'?['zhuyin','math','logic','science','english']:g==='g1'?['zhuyin','math','english','logic','science']:['chinese','english','math','logic','science','zhuyin']}

// --- 注音資料 ---
const ZHUYIN=[
 ['ㄅ','爸爸','ㄅㄚˋ ˙ㄅㄚ','👨','玻'],['ㄆ','葡萄','ㄆㄨˊ ㄊㄠˊ','🍇','坡'],['ㄇ','貓','ㄇㄠ','🐱','摸'],['ㄈ','飛機','ㄈㄟ ㄐㄧ','✈️','佛'],
 ['ㄉ','蛋','ㄉㄢˋ','🥚','得'],['ㄊ','兔子','ㄊㄨˋ ˙ㄗ','🐰','特'],['ㄋ','牛','ㄋㄧㄡˊ','🐮','訥'],['ㄌ','老虎','ㄌㄠˇ ㄏㄨˇ','🐯','勒'],
 ['ㄍ','狗','ㄍㄡˇ','🐶','哥'],['ㄎ','褲子','ㄎㄨˋ ˙ㄗ','👖','科'],['ㄏ','花','ㄏㄨㄚ','🌸','喝'],
 ['ㄐ','雞','ㄐㄧ','🐔','基'],['ㄑ','球','ㄑㄧㄡˊ','⚾','欺'],['ㄒ','西瓜','ㄒㄧ ㄍㄨㄚ','🍉','希'],
 ['ㄓ','豬','ㄓㄨ','🐷','知'],['ㄔ','車','ㄔㄜ','🚗','吃'],['ㄕ','獅子','ㄕ ˙ㄗ','🦁','詩'],['ㄖ','日','ㄖˋ','☀️','日'],
 ['ㄗ','嘴巴','ㄗㄨㄟˇ ˙ㄅㄚ','👄','資'],['ㄘ','草','ㄘㄠˇ','🌱','雌'],['ㄙ','傘','ㄙㄢˇ','☂️','思'],
 ['ㄧ','衣服','ㄧ ㄈㄨˊ','👕','衣'],['ㄨ','烏龜','ㄨ ㄍㄨㄟ','🐢','屋'],['ㄩ','魚','ㄩˊ','🐟','迂'],
 ['ㄚ','阿姨','ㄚ ㄧˊ','👩','啊'],['ㄛ','喔喔叫','ㄛ ㄛ ㄐㄧㄠˋ','🐓','喔'],['ㄜ','鵝','ㄜˊ','🦢','鵝'],['ㄝ','葉子','ㄧㄝˋ ˙ㄗ','🍃','耶'],
 ['ㄞ','愛心','ㄞˋ ㄒㄧㄣ','❤️','哀'],['ㄟ','杯子','ㄅㄟ ˙ㄗ','🥤','欸'],['ㄠ','帽子','ㄇㄠˋ ˙ㄗ','🧢','凹'],['ㄡ','猴子','ㄏㄡˊ ˙ㄗ','🐒','歐'],
 ['ㄢ','山','ㄕㄢ','⛰️','安'],['ㄣ','門','ㄇㄣˊ','🚪','恩'],['ㄤ','糖果','ㄊㄤˊ ㄍㄨㄛˇ','🍬','骯'],['ㄥ','燈','ㄉㄥ','💡','嗡'],['ㄦ','耳朵','ㄦˇ ˙ㄉㄨㄛ','👂','耳']
].map(([sym,word,zy,icon,sound])=>({sym,word,zy,icon,sound}));
const ZY_CONFUSE=[['ㄅ','ㄆ','ㄇ','ㄉ'],['ㄉ','ㄊ','ㄋ','ㄌ'],['ㄍ','ㄎ','ㄏ'],['ㄐ','ㄑ','ㄒ'],['ㄓ','ㄗ','ㄔ','ㄘ'],['ㄕ','ㄙ','ㄖ'],['ㄢ','ㄤ','ㄣ','ㄥ'],['ㄛ','ㄜ','ㄡ','ㄠ'],['ㄞ','ㄟ','ㄝ'],['ㄧ','ㄨ','ㄩ']];
// 拼音用字：字、注音
const ZY_SYLLABLES=[['爸','ㄅㄚˋ'],['怕','ㄆㄚˋ'],['媽','ㄇㄚ'],['麻','ㄇㄚˊ'],['馬','ㄇㄚˇ'],['罵','ㄇㄚˋ'],['發','ㄈㄚ'],['大','ㄉㄚˋ'],['他','ㄊㄚ'],['拿','ㄋㄚˊ'],['拉','ㄌㄚ'],['哥','ㄍㄜ'],['渴','ㄎㄜˇ'],['喝','ㄏㄜ'],['雞','ㄐㄧ'],['七','ㄑㄧ'],['西','ㄒㄧ'],['豬','ㄓㄨ'],['出','ㄔㄨ'],['書','ㄕㄨ'],['租','ㄗㄨ'],['粗','ㄘㄨ'],['蘇','ㄙㄨ'],['波','ㄅㄛ'],['摸','ㄇㄛ'],['衣','ㄧ'],['姨','ㄧˊ'],['椅','ㄧˇ'],['一','ㄧ'],['屋','ㄨ'],['五','ㄨˇ'],['魚','ㄩˊ'],['雨','ㄩˇ'],['杯','ㄅㄟ'],['飛','ㄈㄟ'],['黑','ㄏㄟ'],['包','ㄅㄠ'],['貓','ㄇㄠ'],['刀','ㄉㄠ'],['狗','ㄍㄡˇ'],['手','ㄕㄡˇ'],['山','ㄕㄢ'],['三','ㄙㄢ'],['門','ㄇㄣˊ'],['糖','ㄊㄤˊ'],['燈','ㄉㄥ'],['花','ㄏㄨㄚ'],['瓜','ㄍㄨㄚ'],['牛','ㄋㄧㄡˊ'],['球','ㄑㄧㄡˊ'],['車','ㄔㄜ'],['愛','ㄞˋ'],['耳','ㄦˇ'],['鵝','ㄜˊ'],['兔','ㄊㄨˋ'],['土','ㄊㄨˇ'],['筆','ㄅㄧˇ'],['米','ㄇㄧˇ'],['地','ㄉㄧˋ'],['路','ㄌㄨˋ'],['褲','ㄎㄨˋ'],['虎','ㄏㄨˇ']];
const TONE_NAMES=['一聲','二聲','三聲','四聲'];
function toneOf(zy){return zy.includes('ˊ')?1:zy.includes('ˇ')?2:zy.includes('ˋ')?3:zy.includes('˙')?4:0}
function zyChoicesFor(sym,lv){const set=new Set([sym]);if(lv>=2){const g=ZY_CONFUSE.find(g=>g.includes(sym));if(g)for(const s of shuffle(g))if(set.size<(lv===2?3:4))set.add(s)}for(const z of shuffle(ZHUYIN))if(set.size<4)set.add(z.sym);return shuffle([...set])}
function zhuyinQuestion(lv,m,used){
 if(m==='listen'){const pool=ZHUYIN.filter(z=>!used.has('zl-'+z.sym));const z=one(pool.length?pool:ZHUYIN);return {skill:'zy-symbol',prompt:'👂 聽一聽，找出聽到的注音符號',main:'🎧 按下「播放聲音」',answer:z.sym,choices:zyChoicesFor(z.sym,lv),explain:`聽到的是「${z.sym}」，就像「${z.word}」（${z.zy}）。`,signature:'zl-'+z.sym,zhSound:z.sound+'，'+z.word,noReadOptions:true,bigChoices:true,hint:`先聽符號發音，再對照「${z.word}」的完整注音 ${z.zy}。例詞裡的符號不一定在開頭。`}}
 if(m==='picture'){const pool=ZHUYIN.filter(z=>!used.has('zp-'+z.word));const z=one(pool.length?pool:ZHUYIN);const first=z.zy[0];return {skill:'zy-picture',prompt:'🖼️ 看圖聽一聽，這個語詞的第一個注音是什麼？',main:`${z.icon}  ${z.word}`,answer:first,choices:zyChoicesFor(first,lv),explain:`「${z.word}」的注音是 ${z.zy}，第一個符號是「${first}」。`,signature:'zp-'+z.word,zhSound:z.word,noReadOptions:true,bigChoices:true,hint:'慢慢唸這個語詞，注意嘴巴一開始的樣子。'}}
 if(m==='tone'){const pool=ZY_SYLLABLES.filter(([c,zy])=>!used.has('zt-'+c)&&toneOf(zy)<4);const [c,zy]=one(pool.length?pool:ZY_SYLLABLES.filter(([,zy])=>toneOf(zy)<4));const t=toneOf(zy);const marks=['沒有符號','ˊ','ˇ','ˋ'];return {skill:'zy-tone',prompt:'🎵 看注音、聽聲音，這是第幾聲？',main:`${c}　${zy}`,answer:TONE_NAMES[t],choices:TONE_NAMES.slice(),explain:`「${c}」（${zy}）是${TONE_NAMES[t]}。聲調符號：一聲不標、二聲 ˊ、三聲 ˇ、四聲 ˋ；這個字是「${marks[t]}」。`,signature:'zt-'+c,zhSound:c,noReadOptions:true,hint:'一聲平平、二聲往上、三聲先下再上、四聲往下。'}}
 const pool=ZY_SYLLABLES.filter(([c])=>!used.has('zs-'+c));const [c,zy]=one(pool.length?pool:ZY_SYLLABLES);const ini=zy[0],fin=zy.replace(/[ˊˇˋ˙]/g,'').slice(1),tone=toneOf(zy);
 const others=shuffle(ZY_SYLLABLES.filter(([c2,z2])=>z2!==zy&&(z2[0]===ini||z2.replace(/[ˊˇˋ˙]/g,'').slice(1)===fin||(lv>=2&&ZY_CONFUSE.some(g=>g.includes(ini)&&g.includes(z2[0]))))).map(x=>x[1]));
 const set=new Set([zy]);for(const z of others)if(set.size<4)set.add(z);for(const [,z] of shuffle(ZY_SYLLABLES))if(set.size<4)set.add(z);
 return {skill:'zy-spell',prompt:'🧩 聽一個字的聲音，找出正確的拼法',main:'🎧 按下「播放聲音」',answer:zy,choices:shuffle([...set]),explain:`聽到的是「${c}」，注音拼成 ${zy}。${fin?`（${ini}＋${fin}${tone?'，再加上聲調':''}）`:''}`,signature:'zs-'+c,zhSound:c,noReadOptions:true,bigChoices:true,hint:'先聽開頭的聲音，再聽後面的韻，最後注意聲調。'};
}
// --- 大班數學 ---
const COUNT_ICONS=['⚾','🍎','⭐','🐟','🧢','🌸','🚗','🍓'],COUNT_NAMES={'⚾':'棒球','🍎':'蘋果','⭐':'星星','🐟':'小魚','🧢':'帽子','🌸':'花','🚗':'車子','🍓':'草莓'};
function rows(icon,n){let s='';for(let i=0;i<n;i++){s+=icon;if(i%5===4&&i<n-1)s+='\n';else if(i<n-1)s+=' '}return s}
function kidMathQuestion(m,lv){const max=lv===1?10:20;
 if(m==='count'){const n=rand(lv===1?2:6,max),ic=one(COUNT_ICONS);return {skill:'math-count',prompt:`🔢 數一數，有幾個${COUNT_NAMES[ic]} ${ic}？`,main:rows(ic,n),answer:String(n),choices:choicesForAnswer(n,1,max+2),explain:`5 個一排比較好數：一共有 ${n} 個。`,signature:'cnt-'+n+ic,bigChoices:true,hint:'用手指一個一個點，邊點邊數。每一排有 5 個。',noReadMain:true}}
 if(m==='compare'){const big=rand(0,1)===0;const set=new Set();while(set.size<4)set.add(rand(1,max));const nums=[...set],ans=big?Math.max(...nums):Math.min(...nums);return {skill:'math-compare',prompt:big?'⚖️ 哪一個數字最大？':'⚖️ 哪一個數字最小？',main:big?'找出最大的數 ⬆️':'找出最小的數 ⬇️',answer:String(ans),choices:shuffle(nums).map(String),explain:`${nums.slice().sort((a,b)=>a-b).join(' < ')}，所以${big?'最大':'最小'}的是 ${ans}。`,signature:'cmp-'+nums.join(',')+big,bigChoices:true,hint:'數字越後面數到的越大。可以從 1 開始數數看。'}}
 const add=rand(0,1)===0,ic=one(COUNT_ICONS);
 if(add){const a=rand(1,max-1),b=rand(1,Math.min(max-a,lv===1?5:9));return {skill:'math-add10',prompt:'🍎 看圖算一算：合起來有幾個？',main:`${rows(ic,a)}\n＋\n${rows(ic,b)}`,second:`${a} ＋ ${b} ＝ ?`,answer:String(a+b),choices:choicesForAnswer(a+b,1,max+3),explain:`${a} 個再加 ${b} 個，一共 ${a+b} 個。`,signature:'add-'+a+'+'+b,bigChoices:true,hint:'先數第一堆，再接著往下數第二堆。',noReadMain:true}}
 const a=rand(3,max),b=rand(1,Math.min(a-1,lv===1?5:9));return {skill:'math-add10',prompt:`🍎 有 ${a} 個${COUNT_NAMES[ic]} ${ic}，拿走 ${b} 個，還剩幾個？`,main:rows(ic,a-b)+(b?'  '+'❌'.repeat(b):''),second:`${a} − ${b} ＝ ?`,answer:String(a-b),choices:choicesForAnswer(a-b,1,max),explain:`${a} 拿走 ${b}，剩下 ${a-b} 個（❌ 是拿走的）。`,signature:'sub-'+a+'-'+b,bigChoices:true,hint:'把拿走的蓋起來，數剩下的。',noReadMain:true}}
function roundFrom(fn,size=8){const list=[],used=new Set();for(let i=0;i<size;i++){let q,k=0;do{q=fn(used);k++}while(used.has(q.signature)&&k<60);used.add(q.signature);list.push(q)}return list}
function freshV25Review(item){if(item.subject==='zhuyin')return zhuyinQuestion(item.level,item.mode,new Set());if(item.subject==='math'&&['count','compare','add10'].includes(item.mode))return kidMathQuestion(item.mode,item.level);return null}

// --- 中文朗讀（裝置內建國語語音，免費） ---
function pickChineseVoice(){if(!('speechSynthesis' in window))return null;let vs=[];try{vs=speechSynthesis.getVoices()}catch(_){}const tw=vs.filter(v=>/zh[-_]TW/i.test(v.lang||'')),cn=vs.filter(v=>/zh[-_](CN|Hans)/i.test(v.lang||'')||/^zh$/i.test(v.lang||''));const rank=v=>(/premium|enhanced|neural|natural/i.test(v.name)?10:0)+(v.localService?2:0);return (tw.sort((a,b)=>rank(b)-rank(a))[0])||(cn.sort((a,b)=>rank(b)-rank(a))[0])||null}
function zhText(t){return String(t||'').replace(/\p{Extended_Pictographic}|\uFE0F|\u20E3/gu,' ').replace(/＋|\+/g,' 加 ').replace(/−|-(?=\s*\d)/g,' 減 ').replace(/×/g,' 乘以 ').replace(/÷/g,' 除以 ').replace(/＝|=/g,' 等於 ').replace(/□/g,' 空格 ').replace(/\?|？/g,'？').replace(/\n+/g,'，')}
function speakChinese(parts,{queue=false}={}){if(!('speechSynthesis' in window)){toast('這台裝置不支援語音朗讀');return}try{if(!queue){stopEnglish()}const v=pickChineseVoice();for(const p of [].concat(parts).filter(Boolean)){const u=new SpeechSynthesisUtterance(zhText(p));u.lang=v?.lang||'zh-TW';if(v)u.voice=v;u.rate=grade()==='k'?0.82:0.9;speechSynthesis.speak(u)}}catch(e){console.warn('Chinese speech failed',e)}}
const hasCJK=s=>/[一-鿿]/.test(String(s));
function questionReadParts(q){const parts=[];if(q.isEnglish){parts.push(q.prompt);if(hasCJK(q.main))parts.push(q.main);if(q.second&&hasCJK(q.second))parts.push(q.second)}else{parts.push(q.noReadMain||!hasCJK(q.main)?q.prompt:q.main);if(q.second)parts.push(q.second)}
 if(!q.noReadOptions&&q.choices.every(c=>hasCJK(c)||/^\d+(:\d+)?$/.test(c)))parts.push(q.choices.map((c,i)=>'ABCD'[i]+'，'+c).join('。'));return parts}
function speakQuestion(){if(!session)return;const q=session.items[session.idx];if(!q)return;speakChinese(questionReadParts(q));if(q.zhSound)speakChinese(['聽聲音：',q.zhSound],{queue:true})}
function speakZhSound(){if(!session)return;const q=session.items[session.idx];if(q?.zhSound)speakChinese(q.zhSound)}
let autoReadTimer=null;
function autoReadSoon(){clearTimeout(autoReadTimer);const current=session,q=session?.items[session.idx];if(page==='quiz'&&current&&!feedback&&data.settings.autoRead)autoReadTimer=setTimeout(()=>{if(!document.hidden&&page==='quiz'&&session===current&&session.items[session.idx]===q&&!feedback)speakQuestion()},350)}
// --- 答對音效（可在家長區關閉） ---
let audioCtx=null;
function chime(ok){if(!ok||data.settings.sound===false)return;try{audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();const t=audioCtx.currentTime;[[660,0],[880,0.12]].forEach(([f,d])=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='triangle';o.frequency.value=f;g.gain.setValueAtTime(0.0001,t+d);g.gain.exponentialRampToValueAtTime(0.18,t+d+0.02);g.gain.exponentialRampToValueAtTime(0.0001,t+d+0.22);o.connect(g).connect(audioCtx.destination);o.start(t+d);o.stop(t+d+0.25)})}catch(_){}}

// --- 注音符號卡 ---
let zyIndex=0;
function zhuyinPage(){const z=ZHUYIN[zyIndex];const groups=[['聲母',0,21],['介音',21,24],['韻母',24,37]];return `<button class="back" data-action="zy-back">← 回到注音練習場</button><div class="pageheading"><div class="eyebrow">ZHUYIN CARDS</div><h1>ㄅ 注音符號卡</h1><p>看符號、聽聲音、跟著唸。點下面的符號可以直接跳過去。</p></div><div class="alpha-layout"><section class="alpha-main"><div class="alpha-topline"><span>第 ${zyIndex+1} / 37 個符號</span><span>${zyIndex<21?'聲母':zyIndex<24?'介音':'韻母'}</span></div><div class="alpha-hero"><button type="button" class="alpha-symbol zy-symbol zy-big" data-action="zy-sound" aria-label="播放「${z.sym}」的發音">${z.sym}</button><div><span class="alpha-example-emoji" aria-hidden="true">${z.icon}</span><div class="alpha-word">${z.word}<small>${z.zy}</small></div></div></div><div class="alpha-audio"><button class="btn btn-dark" data-action="zy-sound">🔊 聽「${z.sym}」</button><button class="btn btn-outline" data-action="zy-word">🔈 聽「${z.word}」</button></div><div class="alpha-note"><strong>👂 小老師提醒：</strong>點大符號或下面的格子就會聽到發音。聽完跟著唸三次，再聽語詞。<br><small>注音發音：<a href="https://language.moe.gov.tw/001/Upload/files/site_content/M0001/juyin/html_ch/index.html" target="_blank" rel="noopener noreferrer">教育部《國語注音符號手冊》</a>音檔，CC BY 4.0，本站調整為 0.8 倍速並放大音量。</small></div><div class="alpha-controls"><button class="btn btn-outline" data-action="zy-prev" ${zyIndex===0?'disabled':''}>← 上一個</button><button class="btn btn-dark" data-action="zy-next">${zyIndex===36?'✅ 完成 37 個':'下一個 →'}</button></div></section><aside class="alpha-side"><section class="card"><h3>🎯 選一個符號</h3>${groups.map(([n,a,b])=>`<p class="note" style="margin:8px 0 4px">${n}</p><div class="alpha-grid">${ZHUYIN.slice(a,b).map((x,j)=>`<button class="alpha-item zy-item ${a+j===zyIndex?'selected':''}" data-action="zy-select" data-index="${a+j}" aria-label="符號 ${x.sym}">${x.sym}</button>`).join('')}</div>`).join('')}<div class="rowactions"><button class="btn btn-primary" data-action="start" data-mode="listen" style="width:100%">👂 做聽音找符號</button></div></section></aside></div>`}

// --- 球員頁 ---
function playersPage(){const cur=activeProfile();return `<button class="back" data-action="nav-home">← 回到學習區</button><div class="pageheading"><div class="eyebrow">PLAYERS</div><h1>👥 誰要上場？</h1><p>點自己的球員卡就能切換，每個人的紀錄和難度都分開保存。</p></div><div class="player-grid">${profiles.list.map(p=>`<button class="player-card ${p.id===cur.id?'current':''}" data-action="switch-player" data-id="${p.id}"><span class="player-avatar">${p.avatar}</span><strong>${h(p.name)}</strong><small>${GRADES[p.grade]}${p.id===cur.id?' · 上場中':''}</small></button>`).join('')}</div><section class="card" style="margin-top:17px"><h3>🎨 ${h(cur.name)} 的畫面主題</h3><div class="theme-row">${Object.entries(THEMES).map(([k,t])=>`<button class="theme-chip theme-${k} ${cur.theme===k?'selected':''}" data-action="set-theme" data-theme="${k}" aria-pressed="${cur.theme===k}"><span>${t.icon}</span>${t.name}</button>`).join('')}</div><p class="note">為 ${h(cur.name)} 選擇喜歡的探索風格，學習紀錄會保留。</p></section><section class="card" style="margin-top:14px"><h3>➕ 新增或修改小朋友</h3><p class="note" style="margin-top:0">新增球員、改名字或年級，請大人到家長區設定。</p><button class="btn btn-outline" data-action="nav-parent" style="width:100%">前往家長區 →</button></section>`}
function playerManager(){return `<div class="section-title"><div><h2>小朋友管理</h2><p>每位小朋友有自己的紀錄、難度和風格。小小探索學院提供四種畫面風格：⚾ 棒球、🚀 太空探險、👑 公主城堡、🐰 可愛動物。</p></div></div><section class="card">${profiles.list.map(p=>`<form class="player-form" data-player-form="${p.id}"><span class="player-avatar small">${p.avatar}</span><input name="name" value="${h(p.name)}" maxlength="12" aria-label="小朋友名字" required><select name="avatar" aria-label="頭像">${AVATARS.map(a=>`<option ${a===p.avatar?'selected':''}>${a}</option>`).join('')}</select><select name="grade" aria-label="年級">${Object.entries(GRADES).map(([k,v])=>`<option value="${k}" ${k===p.grade?'selected':''}>${v}</option>`).join('')}</select>${styleSelect(p.theme)}<button class="btn btn-outline" type="submit">儲存</button>${profiles.list.length>1?`<button class="btn btn-danger" type="button" data-action="delete-player" data-id="${p.id}">刪除</button>`:''}</form>`).join('')}${profiles.list.length<6?`<form class="player-form add" data-player-form="new"><span class="player-avatar small">➕</span><input name="name" placeholder="新小朋友名字" maxlength="12" required aria-label="新小朋友名字"><select name="avatar" aria-label="頭像">${AVATARS.map(a=>`<option>${a}</option>`).join('')}</select><select name="grade" aria-label="年級">${Object.entries(GRADES).map(([k,v])=>`<option value="${k}" ${k==='k'?'selected':''}>${v}</option>`).join('')}</select>${styleSelect('princess')}<button class="btn btn-dark" type="submit">新增小朋友</button></form>`:''}<p class="note">新增球員時會依年級自動設定難度（大班：全部第1級、每回合 5 題、自動朗讀）。之後可在下方逐科調整。刪除球員會一併刪除他在這台裝置上的紀錄。</p></section>`}
function handlePlayerForm(form){const id=form.dataset.playerForm,name=String(form.elements.namedItem('name').value||'').trim().slice(0,12),avatar=form.elements.namedItem('avatar').value,g=form.elements.namedItem('grade').value;if(!name){toast('請輸入名字');return}
 const th=form.elements.namedItem('theme')?.value;if(id==='new'||id==='new-login'){const nid='p'+Date.now().toString(36).slice(-8);const p=cleanProfile({id:nid,name,avatar,grade:g,theme:th||'field'});if(!p)return;profiles.list.push(p);saveProfiles();const preset=GRADE_PRESETS[p.grade];const fresh=structuredClone(DEFAULT);Object.assign(fresh.settings,preset);try{localStorage.setItem(dataKeyFor(nid),JSON.stringify(fresh))}catch(_){}if(id==='new-login'){pickPlayer(nid);return}toast(`已新增：${name}`);render();return}
 const p=profiles.list.find(x=>x.id===id);if(!p)return;const gradeChanged=p.grade!==g;Object.assign(p,cleanProfile({...p,name,avatar,grade:g,theme:th||p.theme}));saveProfiles();if(gradeChanged&&p.id===activeProfile().id){Object.assign(data.settings,GRADE_PRESETS[p.grade]);save()}toast(gradeChanged?`已更新 ${name}，並依年級重設難度`:`已更新 ${name}`);render()}
function switchPlayer(id){if(!profiles.list.some(p=>p.id===id))return;save();profiles.active=id;saveProfiles();data=safeLoad();parentUnlocked=false;applyProfileLook();navigate('home');toast(`${activeProfile().avatar} ${activeProfile().name} ${worldInfo().go}！`)}
function deletePlayer(id){if(profiles.list.length<2)return;const p=profiles.list.find(x=>x.id===id);if(!p)return;if(!confirm(`確定刪除「${p.name}」和他在這台裝置的所有紀錄嗎？`))return;try{localStorage.removeItem(dataKeyFor(id))}catch(_){}profiles.list=profiles.list.filter(x=>x.id!==id);if(profiles.active===id){profiles.active=profiles.list[0].id;data=safeLoad();applyProfileLook()}saveProfiles();toast('已刪除球員');render()}

const TILE_K={math:'數一數、比大小、看圖加減',logic:'圖案規律、找出不一樣',english:'26 個字母、聽單字'};
function tileText(sb){return (grade()==='k'&&TILE_K[sb])||SUBJECT_META[sb].tile}
const isEmojiMain=q=>!hasCJK(q.main)&&/\p{Extended_Pictographic}/u.test(q.main);


// ===== v26：更自然的朗讀、家長錄音、避免重複、更難的新題型 =====
// --- 新題型登記 ---
const insertBeforeReview=(sub,mode)=>{const arr=MODES[sub],i=arr.findIndex(m=>m.id==='review');arr.splice(i<0?arr.length:i,0,mode)};
insertBeforeReview('math',{id:'challenge',icon:'🏆',name:'思考挑戰',label:'數學思維',desc:'植樹、排隊、年齡、猜數字、雞兔同籠……真正需要動腦的題目。',skill:'math-challenge'});
insertBeforeReview('logic',{id:'sudoku',icon:'🔢',name:'4×4 數獨',label:'空間推理',desc:'每排、每列、每個田字格 1～4 各一次，推出 ？ 是多少。',skill:'logic-sudoku'});
insertBeforeReview('logic',{id:'truth',icon:'🕵️',name:'誰說謊？',label:'真假推理',desc:'只有一個人說謊（或只有一個人說真話），找出是誰做的。',skill:'logic-truth'});
insertBeforeReview('english',{id:'spell',icon:'✏️',name:'拼字挑戰',label:'拼字',desc:'依圖示與中文意思，選出符合意思的英文單字。',skill:'en-spell'});
insertBeforeReview('english',{id:'order',icon:'🧱',name:'聽音排句子',label:'聽音與句型',desc:'先聽完整英文，選出與錄音順序完全相同的句子。',skill:'en-order-sentence'});
insertBeforeReview('zhuyin',{id:'word',icon:'📝',name:'語詞注音',label:'完整拼寫',desc:'看圖聽語詞，選出完全正確的注音（包含聲調）。',skill:'zy-word'});
Object.assign(SKILLS,{'math-challenge':'數學思考挑戰','logic-sudoku':'數獨推理','logic-truth':'真假推理','en-spell':'英文拼字','en-order-sentence':'句子重組','zy-word':'語詞注音'});
SKILL_GROUPS.math.push('math-challenge');SKILL_GROUPS.logic.push('logic-sudoku','logic-truth');SKILL_GROUPS.english.push('en-spell','en-order-sentence');SKILL_GROUPS.zhuyin.push('zy-word');
// 不再依年級隱藏題型：大班與一年級先排適合的，其他題型照樣可以挑戰
// 年級限制由 HIDE_BY_GRADE 與 practiceQuestions 一致執行。
GRADE_PRESETS.k.roundSize=5;GRADE_PRESETS.g1.roundSize=8;GRADE_PRESETS.g2.roundSize=8;GRADE_PRESETS.g3.roundSize=10;

// --- 數學思考挑戰（每題都由程式計算答案） ---
const WEEK=['星期日','星期一','星期二','星期三','星期四','星期五','星期六'];
function guessNumberPuzzle(){
 for(let tries=0;tries<400;tries++){const n=rand(10,99),a=Math.floor(n/10),b=n%10;
  const gens=shuffle([
   ()=>{const lo=a*10;return {t:`比 ${lo} 大、比 ${lo+10} 小`,f:x=>x>lo&&x<lo+10,ok:n>lo}},
   ()=>({t:n%2?'是單數（奇數）':'是雙數（偶數）',f:x=>x%2===n%2,ok:true}),
   ()=>({t:`十位和個位加起來是 ${a+b}`,f:x=>Math.floor(x/10)+x%10===a+b,ok:true}),
   ()=>a===b?{ok:false}:{t:a>b?'十位數字比個位數字大':'個位數字比十位數字大',f:x=>a>b?Math.floor(x/10)>x%10:x%10>Math.floor(x/10),ok:true},
   ()=>{const k=one([3,4,5].filter(k=>n%k===0));return k?{t:`是 ${k} 的倍數`,f:x=>x%k===0,ok:true}:{ok:false}},
   ()=>{const d=b-a;return d>=1&&d<=4?{t:`個位數字比十位數字多 ${d}`,f:x=>x%10-Math.floor(x/10)===d,ok:true}:{ok:false}}
  ]);
  const props=[];for(const g of gens){const p=g();if(!p.ok||!p.t)continue;props.push(p);const c=[...Array(90)].map((_,i)=>i+10).filter(x=>props.every(q=>q.f(x)));if(c.length===1)break}
  const cand=[...Array(90)].map((_,i)=>i+10).filter(x=>props.every(q=>q.f(x)));
  if(cand.length===1&&cand[0]===n&&props.length>=2&&props.length<=4){const marks='①②③④';const first=[...Array(90)].map((_,i)=>i+10).filter(x=>props[0].f(x)&&props[1].f(x));
   return {main:'我是一個兩位數：\n'+props.map((p,i)=>marks[i]+' '+p.t).join('\n')+'\n我是多少？',ans:n,exp:`同時符合①②的數：${first.slice(0,12).join('、')}${first.length>12?'……':''}${props.length>2?'；再用後面的線索一個一個刪掉':''}，最後只剩 ${n}。`,hint:'先用一條線索列出可能的數，再用其他線索一個一個刪掉。',sig:'guess-'+n+props.map(p=>p.t).join()}}}
 return {main:'我是一個兩位數：\n① 十位和個位加起來是 9\n② 十位數字比個位數字多 5\n我是多少？',ans:72,exp:'和是 9、差是 5：十位 7、個位 2，所以是 72。',hint:'和與差都知道，可以先試試看。',sig:'guess-72'};
}
function challengeQuestion(lv,used){
 const kinds=lv===1?['queue','saw','stairs','weekday','flags','coins']:lv===2?['queue','saw','stairs','weekday','flags','flags0','age','sumdiff','handshake','guess','coins']:['flags0','circle','age2','sumdiff','handshake','guess','chicken','times','balance','weekday','stairs'];
 let kind=one(kinds),g=0;while(used.has('chk-'+kind)&&g++<20)kind=one(kinds);
 let main,ans,exp,hint,sig,choices=null;
 if(kind==='queue'){if(rand(0,1)){const a=rand(3,12),b=rand(2,12);ans=a+b-1;main=`小明排隊，從前面數是第 ${a} 個，從後面數是第 ${b} 個。這一排共有幾個人？`;exp=`${a}＋${b}＝${a+b}，但小明被數了兩次，要減 1：${ans} 人。`;hint='畫圈圈試試看，小明被算了幾次？'}else{const a=rand(2,12),b=rand(2,12);ans=a+b+1;main=`小明排隊，他前面有 ${a} 個人，後面有 ${b} 個人。這一排共有幾個人？`;exp=`前面 ${a} 人＋後面 ${b} 人＋小明自己 1 人＝${ans} 人。`;hint='別忘了算小明自己。'}sig='queue'+main}
 else if(kind==='saw'){const n=rand(3,8),t=rand(2,6);ans=(n-1)*t;main=`把一根木頭鋸成 ${n} 段，每鋸一次要 ${t} 分鐘。一共要鋸幾分鐘？`;exp=`鋸成 ${n} 段只要鋸 ${n-1} 次（鋸 1 次變 2 段）。${n-1}×${t}＝${ans} 分鐘。`;hint='鋸 1 次會變成幾段？鋸 2 次呢？';sig='saw'+n+t}
 else if(kind==='stairs'){const n=rand(3,lv===1?5:8),s=lv===1?rand(5,12):rand(12,22);ans=(n-1)*s;main=`從 1 樓走到 ${n} 樓，每一層樓梯有 ${s} 階。一共要爬幾階？`;exp=`1 樓到 ${n} 樓只要爬 ${n-1} 層。${n-1}×${s}＝${ans} 階。`;hint='1 樓到 2 樓爬幾層？1 樓到 3 樓呢？';sig='stairs'+n+s}
 else if(kind==='weekday'){const w=rand(0,6),n=lv===1?rand(2,9):lv===2?rand(10,30):rand(30,100),r=n%7;ans=WEEK[(w+r)%7];main=`今天是${WEEK[w]}，再過 ${n} 天是星期幾？`;exp=`一個星期 7 天。${n}÷7＝${Math.floor(n/7)} 餘 ${r}，所以從${WEEK[w]}往後數 ${r} 天，是${ans}。`;hint='每過 7 天又回到同一個星期幾。';choices=shuffle([ans,...shuffle(WEEK.filter(x=>x!==ans)).slice(0,3)]);sig='wd'+w+'-'+n}
 else if(kind==='flags'){const d=one([2,3,5,10]),k=rand(3,10),L=d*k;ans=k+1;main=`一條長 ${L} 公尺的步道，每隔 ${d} 公尺插一面旗子，頭和尾都要插。一共要插幾面旗子？`;exp=`${L}÷${d}＝${k} 個間隔；頭尾都插，旗子比間隔多 1：${ans} 面。`;hint='先畫一段短的試試：3 個間隔要插幾面？';sig='fl'+L+d}
 else if(kind==='flags0'){const d=one([2,3,5,10]),k=rand(4,10),L=d*k;ans=k-1;main=`兩棵大樹之間相距 ${L} 公尺，中間每隔 ${d} 公尺種一棵小樹（兩端大樹所在的位置不種）。中間要種幾棵小樹？`;exp=`${L}÷${d}＝${k} 個間隔；兩端已經是大樹，小樹比間隔少 1：${ans} 棵。`;hint='兩端都不種的時候，樹比間隔多還是少？';sig='f0'+L+d}
 else if(kind==='circle'){const d=one([2,5,10]),k=rand(5,15),L=d*k;ans=k;main=`一個圓形跑道一圈是 ${L} 公尺，每隔 ${d} 公尺站一位小朋友。一共站了幾位？`;exp=`繞一圈頭尾接在一起，人數等於間隔數：${L}÷${d}＝${ans} 位。`;hint='圓形的頭和尾是同一個點。';sig='ci'+L+d}
 else if(kind==='coins'){const X=rand(3,19)*5;ans=Math.floor(X/10)+(X%10?1:0);main=`只用 10 元和 5 元硬幣，要湊出 ${X} 元，最少要幾枚硬幣？`;exp=`盡量用 10 元：${Math.floor(X/10)} 枚 10 元${X%10?'，再加 1 枚 5 元':''}，共 ${ans} 枚。`;hint='想要硬幣少，就先用大的。';sig='co'+X}
 else if(kind==='age'){const a=rand(8,12),b=rand(3,7),y=rand(2,7),S=a+b+2*y;ans=y;main=`哥哥今年 ${a} 歲，妹妹今年 ${b} 歲。再過幾年，兩人的年齡加起來是 ${S} 歲？`;exp=`現在合計 ${a+b} 歲，還差 ${S-a-b} 歲。每過一年兩人一共多 2 歲：${S-a-b}÷2＝${ans} 年。`;hint='每過 1 年，兩個人加起來會多幾歲？';sig='ag'+a+b+S}
 else if(kind==='age2'){const m=rand(6,10),k=one([4,5]),T=m*(k+1);ans=m;main=`爸爸的年齡是小明的 ${k} 倍，兩人年齡加起來是 ${T} 歲。小明幾歲？`;exp=`把小明看成 1 份，爸爸是 ${k} 份，一共 ${k+1} 份。${T}÷${k+1}＝${ans} 歲。`;hint='畫線段：小明 1 段，爸爸幾段？';sig='a2'+m+k}
 else if(kind==='sumdiff'){const b=rand(2,12),D=rand(1,7),S=2*b+D;ans=b+D;main=`紅隊和藍隊一共得了 ${S} 分，紅隊比藍隊多 ${D} 分。紅隊得幾分？`;exp=`先把紅隊多的 ${D} 分拿掉：${S}−${D}＝${2*b}，兩隊一樣多，各 ${b} 分；紅隊再加回 ${D}：${ans} 分。`;hint='如果兩隊一樣多，各是幾分？';sig='sd'+S+D}
 else if(kind==='handshake'){const n=rand(3,lv===2?5:7);ans=n*(n-1)/2;main=`${n} 個小朋友見面，每兩個人都要握一次手。一共握了幾次手？`;exp=`第 1 人和其他 ${n-1} 人握，第 2 人再和剩下 ${n-2} 人握……${[...Array(n-1)].map((_,i)=>n-1-i).join('＋')}＝${ans} 次。`;hint='把每個人要握的次數列出來，注意不要重複算。';sig='hs'+n}
 else if(kind==='guess'){const p=guessNumberPuzzle();main=p.main;ans=p.ans;exp=p.exp;hint=p.hint;sig=p.sig}
 else if(kind==='chicken'){const n=rand(5,10),r=rand(1,n-1),f=2*n+2*r;ans=r;main=`籠子裡有雞和兔子共 ${n} 隻，數一數腳一共有 ${f} 隻。兔子有幾隻？`;exp=`假設全部是雞：${n}×2＝${2*n} 隻腳，比實際少 ${f-2*n} 隻。每把一隻雞換成兔子多 2 隻腳：${f-2*n}÷2＝${ans} 隻兔子。`;hint='先假設全部都是雞，腳會少幾隻？';sig='ch'+n+f}
 else if(kind==='times'){const b=rand(2,7),k=rand(2,4),T=b*(k+1);ans=b*k;main=`紅隊的得分是藍隊的 ${k} 倍，兩隊一共得了 ${T} 分。紅隊得幾分？`;exp=`藍隊 1 份、紅隊 ${k} 份，共 ${k+1} 份。每份 ${T}÷${k+1}＝${b} 分，紅隊 ${b}×${k}＝${ans} 分。`;hint='把藍隊看成 1 份。';sig='ti'+b+k}
 else{const n=rand(2,4),x=rand(2,9)*10,w=one([50,100]),T=n*x+w;ans=x;main=`天平左邊放 ${n} 顆一樣重的球和一個 ${w} 克的砝碼，右邊放 ${T} 克的砝碼，剛好平衡。一顆球幾克？`;exp=`${n} 顆球＝${T}−${w}＝${T-w} 克；一顆球 ${T-w}÷${n}＝${ans} 克。`;hint='先把兩邊都拿掉 '+w+' 克。';sig='ba'+n+x+w}
 return {skill:'math-challenge',prompt:'🏆 思考挑戰：先想清楚，再選答案',main,answer:String(ans),choices:choices||choicesForAnswer(ans,lv),explain:exp,hint,signature:'chl-'+sig,concept:'chk-'+kind,reason:true};
}

// --- 4×4 數獨（答案唯一） ---
function sudokuSolutions(g,limit=2){const cells=[];for(let i=0;i<16;i++)if(!g[i])cells.push(i);let count=0;const ok=(i,v)=>{const r=Math.floor(i/4),c=i%4;for(let k=0;k<4;k++){if(g[r*4+k]===v||g[k*4+c]===v)return false}const br=r-r%2,bc=c-c%2;for(let y=br;y<br+2;y++)for(let x=bc;x<bc+2;x++)if(g[y*4+x]===v)return false;return true};
 const go=k=>{if(count>=limit)return;if(k===cells.length){count++;return}const i=cells[k];for(let v=1;v<=4;v++)if(ok(i,v)){g[i]=v;go(k+1);g[i]=0}};go(0);return count}
function sudokuQuestion(lv){let base=[[1,2,3,4],[3,4,1,2],[2,1,4,3],[4,3,2,1]];const map=shuffle([1,2,3,4]);base=base.map(r=>r.map(v=>map[v-1]));
 const bands=shuffle([0,1]).flatMap(b=>shuffle([0,1]).map(r=>b*2+r)),stacks=shuffle([0,1]).flatMap(s=>shuffle([0,1]).map(c=>s*2+c));let sol=bands.map(r=>stacks.map(c=>base[r][c]));if(rand(0,1))sol=sol[0].map((_,c)=>sol.map(r=>r[c]));
 const flat=sol.flat(),g=flat.slice(),target=lv===1?5:lv===2?8:10;for(const i of shuffle([...Array(16).keys()])){if(16-g.filter(Boolean).length>=target)break;const keep=g[i];g[i]=0;if(sudokuSolutions(g.slice())!==1)g[i]=keep}
 const blanks=[...Array(16).keys()].filter(i=>!g[i]),t=one(blanks),full='０１２３４';
 const row=r=>[0,1,2,3].map(c=>{const i=r*4+c;return i===t?'？':g[i]?full[g[i]]:'□'}).reduce((s,ch,c)=>s+(c===2?'　｜　':c?'　':'')+ch,'');
 const main=[row(0),row(1),'－－－－＋－－－－',row(2),row(3)].join('\n');const ans=flat[t];
 return {skill:'logic-sudoku',prompt:'🔢 數獨：每一橫排、每一直排、每個田字格，1～4 都只出現一次。？ 要填多少？',main,answer:String(ans),choices:['1','2','3','4'],explain:`？ 在第 ${Math.floor(t/4)+1} 排第 ${t%4+1} 格。完整答案：${[0,1,2,3].map(r=>flat.slice(r*4,r*4+4).join(' ')).join('／')}，所以填 ${ans}。`,hint:'看 ？ 所在的橫排、直排和田字格，已經出現哪些數字？剩下的就是答案。也可以先填別的空格。',signature:'sdk-'+g.join('')+t,concept:'sudoku-'+lv,reason:true,gridMain:true,noReadMain:true,noReadOptions:true}}

// --- 誰說謊？（窮舉驗證答案唯一） ---
const TRUTH_EVENTS=['打破了花瓶','吃掉了蛋糕','把球打到窗戶上','把手套藏起來','在牆上畫畫'];
function truthQuestion(lv){const names=shuffle(LINEUP_NAMES).slice(0,3),event=one(TRUTH_EVENTS),oneTruth=lv>=3&&rand(0,1)===1,K=oneTruth?2:1;
 for(let tries=0;tries<500;tries++){const st=names.map(sp=>{const others=names.filter(x=>x!==sp),x=one(others),t=rand(0,3);
   return t===0?{who:sp,text:'不是我做的。',f:c=>c!==sp}:t===1?{who:sp,text:`是${x}做的。`,f:c=>c===x}:t===2?{who:sp,text:`不是${x}做的。`,f:c=>c!==x}:{who:sp,text:'是我做的。',f:c=>c===sp}});
  const fits=names.filter(c=>st.filter(s=>!s.f(c)).length===K);if(fits.length!==1)continue;const ans=fits[0];
  const check=st.map(s=>`${s.who}說「${s.text}」→${s.f(ans)?'真話':'說謊'}`).join('；');
  return {skill:'logic-truth',prompt:'🕵️ 偵探時間：讀完每個人說的話，再推理',main:st.map(s=>`${s.who}：「${s.text}」`).join('\n'),second:`這件事是三人中的一人做的。三個人裡，${oneTruth?'只有一個人說真話':'只有一個人說謊'}。是誰${event}？`,answer:ans,choices:shuffle([...names,'無法判斷']),explain:`假設是${ans}做的：${check}。剛好${oneTruth?'只有一人說真話':'只有一人說謊'}，符合條件；換成其他人都不符合。`,hint:'一個一個假設：「如果是其中一人做的」，數數看有幾個人說謊。',signature:'tr-'+names.join('')+st.map(s=>s.text).join(),concept:'truth-'+K,reason:true}}
 return truthQuestion(lv)}

// --- 英文：拼字挑戰、句子重組 ---
function misspellings(w){const all=new Set(Object.values(VOCAB).flat().map(v=>v[0]));const out=new Set();const vowels='aeiou';let guard=0;
 while(out.size<3&&guard++<200){let x=w;const t=rand(0,3),i=rand(0,w.length-1);
  if(t===0&&w.length>3){const j=Math.min(i,w.length-2);x=w.slice(0,j)+w[j+1]+w[j]+w.slice(j+2)}
  else if(t===1&&w.length>3)x=w.slice(0,i)+w.slice(i+1);
  else if(t===2)x=w.slice(0,i+1)+w[i]+w.slice(i+1);
  else{const vi=[...w].map((c,k)=>vowels.includes(c)?k:-1).filter(k=>k>=0);if(vi.length){const k=one(vi);x=w.slice(0,k)+one([...vowels].filter(v=>v!==w[k]))+w.slice(k+1)}}
  if(x!==w&&!all.has(x))out.add(x)}return [...out]}
function spellQuestion(lv,used){const pool=VOCAB[lv].filter(v=>v[0].length>=3&&!used.has('sp-'+v[0]));const [w,mean,icon]=one(pool.length?pool:VOCAB[lv]);const wrong=misspellings(w);if(wrong.length<3)return spellQuestion(lv,used);
 return {skill:'en-spell',prompt:'✏️ 哪個英文單字的拼寫符合這個中文意思？',main:`${icon||'📘'}  ${mean}`,answer:w,choices:shuffle([w,...wrong]),explain:`「${mean}」的英文是 ${w}，拼法：${w.split('').join('-')}。`,hint:'可以先按播放聽發音，再一個字母一個字母比對。',signature:'sp-'+w,isEnglish:true,speech:w,noReadOptions:true}}
const NAMES_EN=['I','Tom','Mia','Ben','Lily','Sam','Amy','Dad','Grandma','Sundays','Saturday'];
function orderQuestion(lv,used){const pool=[...READ[lv].map(x=>x[0]),...WORD_USE[lv].map(x=>x[0].replace('___',x[1]))].filter(s=>!/[?“"]/.test(s)&&s.split(' ').length>=4&&s.split(' ').length<=(lv===1?6:lv===2?8:10));
 const fresh=pool.filter(s=>!used.has('or-'+s));const s=one(fresh.length?fresh:pool);const toks=s.replace(/[.!]$/,'').split(' ').map((w,i)=>i===0&&!NAMES_EN.includes(w.replace(/[,’']/g,''))?w.toLowerCase():w);
 const fmt=a=>{const t=a.join(' ');return t.charAt(0).toUpperCase()+t.slice(1)+'.'};const correct=fmt(toks);const set=new Set([correct]);let g=0;
 while(set.size<4&&g++<300){const a=toks.slice(),t=rand(0,1);if(t===0){const i=rand(0,a.length-1),j=rand(0,a.length-1);[a[i],a[j]]=[a[j],a[i]]}else{const i=rand(0,a.length-1),[x]=a.splice(i,1);a.splice(rand(0,a.length),0,x)}if(/^(is|are|can|do|does)$/i.test(a[0]))continue;set.add(fmt(a))}
 return {skill:'en-order-sentence',prompt:'🧱 先聽英文，選出與錄音順序完全相同的句子',main:shuffle(toks).join(' / '),answer:correct,choices:shuffle([...set]),explain:`錄音的句子是：${correct}。這題核對的是錄音中的字詞順序。`,hint:'先按播放，可以重複聽；逐字核對錄音與選項的順序。',signature:'or-'+s,isEnglish:true,speech:correct,isListening:true,noReadOptions:true}}

// --- 注音：語詞完整拼寫 ---
const ZY_WORDS=[['棒球','ㄅㄤˋ ㄑㄧㄡˊ','⚾'],['學校','ㄒㄩㄝˊ ㄒㄧㄠˋ','🏫'],['老師','ㄌㄠˇ ㄕ','🧑‍🏫'],['蘋果','ㄆㄧㄥˊ ㄍㄨㄛˇ','🍎'],['香蕉','ㄒㄧㄤ ㄐㄧㄠ','🍌'],['媽媽','ㄇㄚ ˙ㄇㄚ','👩'],['書包','ㄕㄨ ㄅㄠ','🎒'],['月亮','ㄩㄝˋ ㄌㄧㄤˋ','🌙'],['太陽','ㄊㄞˋ ㄧㄤˊ','☀️'],['星星','ㄒㄧㄥ ㄒㄧㄥ','⭐'],['雨傘','ㄩˇ ㄙㄢˇ','☂️'],['手套','ㄕㄡˇ ㄊㄠˋ','🧤'],['火車','ㄏㄨㄛˇ ㄔㄜ','🚆'],['熊貓','ㄒㄩㄥˊ ㄇㄠ','🐼'],['蝴蝶','ㄏㄨˊ ㄉㄧㄝˊ','🦋'],['冰淇淋','ㄅㄧㄥ ㄑㄧˊ ㄌㄧㄣˊ','🍦'],['恐龍','ㄎㄨㄥˇ ㄌㄨㄥˊ','🦖'],['牙齒','ㄧㄚˊ ㄔˇ','🦷'],['飛機','ㄈㄟ ㄐㄧ','✈️'],['西瓜','ㄒㄧ ㄍㄨㄚ','🍉'],['老虎','ㄌㄠˇ ㄏㄨˇ','🐯'],['葡萄','ㄆㄨˊ ㄊㄠˊ','🍇'],['烏龜','ㄨ ㄍㄨㄟ','🐢'],['糖果','ㄊㄤˊ ㄍㄨㄛˇ','🍬'],['花朵','ㄏㄨㄚ ㄉㄨㄛˇ','🌸'],['鉛筆','ㄑㄧㄢ ㄅㄧˇ','✏️'],['跑步','ㄆㄠˇ ㄅㄨˋ','🏃'],['游泳','ㄧㄡˊ ㄩㄥˇ','🏊']];
const TONE_MARKS=['','ˊ','ˇ','ˋ'];
function markedSyllable(base,mark){return mark==='˙'?'˙'+base:base+mark}
function mutateSyllable(s){const base=s.replace(/[ˊˇˋ˙]/g,''),mark=(s.match(/[ˊˇˋ˙]/)||[''])[0],t=rand(0,2);
 if(t===0)return base+one(TONE_MARKS.filter(m=>m!==mark));
 if(t===1){const g=ZY_CONFUSE.find(g=>g.includes(base[0]));if(g)return markedSyllable(one(g.filter(x=>x!==base[0]))+base.slice(1),mark)}
 const swaps={'ㄢ':'ㄤ','ㄤ':'ㄢ','ㄣ':'ㄥ','ㄥ':'ㄣ','ㄠ':'ㄡ','ㄡ':'ㄠ','ㄞ':'ㄟ','ㄟ':'ㄞ','ㄛ':'ㄜ','ㄜ':'ㄛ','ㄧ':'ㄩ','ㄩ':'ㄧ'};const last=base.slice(-1);return swaps[last]?markedSyllable(base.slice(0,-1)+swaps[last],mark):base+one(TONE_MARKS.filter(m=>m!==mark))}
function zhuyinWordQuestion(lv,used){const pool=ZY_WORDS.filter(w=>!used.has('zw-'+w[0]));const [word,zy,icon]=one(pool.length?pool:ZY_WORDS);const sy=zy.split(' ');const set=new Set([zy]);let g=0;
 while(set.size<4&&g++<200){const a=sy.slice(),i=rand(0,a.length-1);a[i]=mutateSyllable(a[i]);if(lv===3&&a.length>1&&rand(0,1)){const j=(i+1)%a.length;a[j]=mutateSyllable(a[j])}set.add(a.join(' '))}
 return {skill:'zy-word',prompt:'📝 這個語詞的注音，哪一個完全正確？',main:`${icon}  ${word}`,answer:zy,choices:shuffle([...set]),explain:`「${word}」的注音是 ${zy}。注意每個字的聲母、韻母和聲調。`,hint:'一個字一個字慢慢唸，注意聲調。輕聲的「˙」標在該音節前面。',signature:'zw-'+word,zhSound:word,noReadOptions:true}}

// --- 5 人打序（第 3 級） ---
const _lineupV24=lineupQuestion;
lineupQuestion=function(level){if(level<3)return _lineupV24(level);
 const n=5,names=shuffle(LINEUP_NAMES).slice(0,n),order=shuffle(names),pos=Object.fromEntries(order.map((x,i)=>[x,i])),all=permutations(names),cn=['一','二','三','四','五'];
 const mk=()=>{const t=rand(0,4);let a=one(names),b=one(names.filter(x=>x!==a));
  if(t===0){const k=rand(0,n-1);return pos[a]===k?null:{text:`${a}不是第${cn[k]}棒。`,ok:p=>p.indexOf(a)!==k,key:'n'+a+k}}
  if(t===1){if(pos[a]>pos[b])[a,b]=[b,a];return {text:`${a}比${b}先上場打擊。`,ok:p=>p.indexOf(a)<p.indexOf(b),key:'b'+a+b}}
  if(t===2){const i=pos[a];if(i===n-1)return null;const nx=order[i+1];return {text:`${nx}緊接在${a}後面打擊。`,ok:p=>p.indexOf(nx)===p.indexOf(a)+1,key:'x'+a}}
  if(t===3){const d=Math.abs(pos[a]-pos[b]);return d<2?null:{text:`${a}和${b}中間隔了 ${d-1} 個人。`,ok:p=>Math.abs(p.indexOf(a)-p.indexOf(b))===d,key:'g'+[a,b].sort().join('')}}
  const i=pos[a];return i===0||i===n-1?null:{text:`${a}不是第一棒，也不是最後一棒。`,ok:p=>{const j=p.indexOf(a);return j!==0&&j!==n-1},key:'m'+a}};
 let clues=[],g=0;const fits=c=>all.filter(p=>c.every(x=>x.ok(p)));
 while(fits(clues).length>1&&g++<400){const c=mk();if(!c||clues.some(x=>x.key===c.key))continue;if(fits([...clues,c]).length<fits(clues).length)clues.push(c)}
 if(fits(clues).length!==1||clues.length>7)return lineupQuestion(level);
 for(let i=clues.length-1;i>=0;i--){const t=clues.filter((_,j)=>j!==i);if(fits(t).length===1)clues=t}
 const k=rand(0,n-1),ans=order[k];
 return {skill:'logic-order',prompt:'📋 教練的打序線索（5 人版）：排一排，再回答',main:clues.map((c,i)=>`${i+1}. ${c.text}`).join('\n'),second:`${names.join('、')} 5 人輪流打擊。誰是第${cn[k]}棒？`,answer:ans,choices:shuffle([ans,...shuffle(names.filter(x=>x!==ans)).slice(0,3)]),explain:`正確打序：${order.map((x,i)=>`第${cn[i]}棒 ${x}`).join(' → ')}。`,hint:'畫 5 個格子，先放最確定的人。「中間隔了幾個人」可以想成兩人之間的空格數。',signature:'lu5-'+order.join('')+clues.map(c=>c.key).join(''),concept:'lineup-3',reason:true}};

function v26Round(sub,m,lv){if(sub==='math'&&m==='challenge')return roundFrom(u=>{const q=challengeQuestion(lv,u);u.add(q.concept);return q});if(sub==='logic'&&m==='sudoku')return roundFrom(()=>sudokuQuestion(lv));if(sub==='logic'&&m==='truth')return roundFrom(()=>truthQuestion(lv));if(sub==='english'&&m==='spell')return roundFrom(u=>spellQuestion(lv,u));if(sub==='english'&&m==='order')return roundFrom(u=>orderQuestion(lv,u));if(sub==='zhuyin'&&m==='word')return roundFrom(u=>zhuyinWordQuestion(lv,u));return null}
function freshV26Review(item){const r=v26Round(item.subject,item.mode,item.level);return r?r[0]:null}

// --- 避免重複：多出幾組題目，優先挑最近沒做過、類型不同的 ---
function cleanRecent(r){const o={};if(!r||typeof r!=='object')return o;for(const [k,v] of Object.entries(r).slice(0,80))if(/^[a-z]+:[a-z0-9]+$/.test(k)&&Array.isArray(v))o[k]=v.filter(x=>typeof x==='string').map(x=>x.slice(0,240)).slice(-150);return o}
function pickVaried(rounds,want,recent){const seen=new Set(),concepts=new Set(),out=[];const all=rounds.flat();const reviews=[];for(const q of all)if(q.reviewId&&!reviews.some(r=>r.reviewId===q.reviewId))reviews.push(q);for(const q of reviews.slice(0,2)){out.push(q);seen.add(q.signature)}
 const rest=shuffle(all.filter(q=>!q.reviewId));const passes=[q=>!recent.has(q.signature)&&!(q.concept&&concepts.has(q.concept)),q=>!recent.has(q.signature),()=>true];
 for(const ok of passes)for(const q of rest){if(out.length>=want)break;if(seen.has(q.signature)||!ok(q))continue;out.push(q);seen.add(q.signature);if(q.concept)concepts.add(q.concept)}
 return shuffle(out)}
function rememberRound(s){data.recent=data.recent||{};const k=s.subject+':'+s.mode;if(s.mode==='review')return;data.recent[k]=[...(data.recent[k]||[]),...s.items.map(q=>q.signature).filter(Boolean)].slice(-150)}

// --- 朗讀：自然語速、乾淨的句子、可選聲音 ---
const VOICE_PREF_KEY='homerun_zh_voice';
function zhVoices(){if(!('speechSynthesis' in window))return [];let vs=[];try{vs=speechSynthesis.getVoices()}catch(_){}return vs.filter(v=>/^zh[-_](TW|CN|Hant|Hans)|^zh$|^cmn/i.test(v.lang||'')&&!/HK|yue/i.test(v.lang||''))}
pickChineseVoice=function(){const vs=zhVoices();let pref='';try{pref=localStorage.getItem(VOICE_PREF_KEY)||''}catch(_){}const chosen=vs.find(v=>v.voiceURI===pref);if(chosen)return chosen;const rank=v=>(/TW|Hant/i.test(v.lang)?100:0)+(/premium|enhanced|加強|neural|natural|siri/i.test(v.name)?30:0)+(/mei-?jia|美佳|google/i.test(v.name)?10:0)+(v.localService?3:0);return vs.sort((a,b)=>rank(b)-rank(a))[0]||null};
zhText=function(t){return String(t||'').replace(/\p{Extended_Pictographic}|️|⃣|‍/gu,'').replace(/[①②③④]/g,m=>'第'+'一二三四'['①②③④'.indexOf(m)]+'，').replace(/＋|\+/g,'加').replace(/−|－(?=\s*\d)|-(?=\s*\d)/g,'減').replace(/×/g,'乘以').replace(/÷/g,'除以').replace(/＝|=/g,'等於').replace(/□/g,'空格').replace(/[「」『』]/g,'').replace(/\s*\n+\s*/g,'，').replace(/\s{2,}/g,' ').replace(/([：，。、？])\s*，/g,'$1').replace(/，\s+/g,'，').replace(/^[\s，。：:]+/,'').trim()};
speakChinese=function(parts,{queue=false,onend=null}={}){if(!('speechSynthesis' in window)){toast('這台裝置不支援語音朗讀');return}try{if(!queue)stopEnglish();const v=pickChineseVoice();if(!v)toast('找不到中文語音，請到家長區看「朗讀與音效」的設定說明');const list=[].concat(parts).map(zhText).filter(Boolean);list.forEach((p,i)=>{const u=new SpeechSynthesisUtterance(p);u.lang=v?.lang||'zh-TW';if(v)u.voice=v;u.rate=1;u.pitch=1;if(i===list.length-1&&onend)u.onend=onend;speechSynthesis.speak(u)});if(!list.length&&onend)onend()}catch(e){console.warn('Chinese speech failed',e)}};
questionReadParts=function(q){const parts=[];if(q.isEnglish){parts.push(q.prompt);if(hasCJK(q.main))parts.push(q.main);if(q.second&&hasCJK(q.second))parts.push(q.second)}else{parts.push(q.noReadMain||!hasCJK(q.main)?q.prompt:q.main);if(q.second)parts.push(q.second)}
 if(!q.noReadOptions&&q.choices.every(c=>hasCJK(c)||/^\d+(:\d+)?$/.test(c))){const c=q.choices;parts.push('選項有：'+c.slice(0,-1).join('、')+'，還是'+c[c.length-1]+'？')}return parts};

// --- 家長錄音室（存在這台裝置，不上傳） ---
const AudioStore={db:null,keys:new Set(),
 open(){return new Promise((res,rej)=>{if(this.db)return res(this.db);if(!('indexedDB' in window))return rej(new Error('no indexedDB'));const r=indexedDB.open('homerun_audio',1);r.onupgradeneeded=()=>r.result.createObjectStore('clips');r.onsuccess=()=>{this.db=r.result;res(this.db)};r.onerror=()=>rej(r.error)})},
 async tx(mode,fn){const db=await this.open();return new Promise((res,rej)=>{const t=db.transaction('clips',mode),s=t.objectStore('clips'),out=fn(s);t.oncomplete=()=>res(out&&out.result);t.onerror=()=>rej(t.error)})},
 async load(){try{const keys=await this.tx('readonly',s=>s.getAllKeys());this.keys=new Set(keys||[]);if(page==='parent'||page==='zhuyin')render()}catch(_){}},
 async put(k,blob){await this.tx('readwrite',s=>s.put(blob,k));this.keys.add(k)},
 async get(k){return this.tx('readonly',s=>s.get(k))},
 async del(k){await this.tx('readwrite',s=>s.delete(k));this.keys.delete(k)}};
let activeClip=null;
async function playClipOr(key,fallback){if(AudioStore.keys.has(key)){try{const blob=await AudioStore.get(key);if(blob){stopEnglish();const url=URL.createObjectURL(blob);activeClip=new Audio(url);activeClip.onended=()=>URL.revokeObjectURL(url);await activeClip.play();return}}catch(e){console.warn('clip play failed',e)}}fallback()}
function playZySymbol(sym){const z=ZHUYIN.find(x=>x.sym===sym);playClipOr('zy:'+sym,()=>speakChinese(z?z.sound:sym))}
let recSym='ㄅ',recBusy=false;
async function recordClip(sym){if(recBusy)return;if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('這個瀏覽器不支援錄音，請用 Safari 或 Chrome 最新版');return}recBusy=true;render();let recordingStream=null;
 try{const stream=recordingStream=await navigator.mediaDevices.getUserMedia({audio:true});const rec=new MediaRecorder(stream),chunks=[];rec.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  const done=new Promise(r=>rec.onstop=r);rec.start();toast(`🎙️ 請唸「${sym}」……`);setTimeout(()=>{try{rec.stop()}catch(_){}},1800);await done;stream.getTracks().forEach(t=>t.stop());
  const blob=new Blob(chunks,{type:rec.mimeType||'audio/mp4'});if(blob.size<500)throw new Error('錄到的聲音太短');await AudioStore.put('zy:'+sym,blob);toast(`✅ 已儲存「${sym}」的錄音`);const i=ZHUYIN.findIndex(z=>z.sym===sym);if(i>=0&&i<36)recSym=ZHUYIN[i+1].sym}
 catch(e){toast('錄音失敗：'+(e?.name==='NotAllowedError'?'請允許使用麥克風':(e?.message||'請再試一次')))}finally{recordingStream?.getTracks().forEach(t=>t.stop());recBusy=false;render()}}
function recordingStudio(){const done=ZHUYIN.filter(z=>AudioStore.keys.has('zy:'+z.sym)).length;const z=ZHUYIN.find(x=>x.sym===recSym)||ZHUYIN[0];
 return `<div class="section-title"><div><h2>🎙️ 注音錄音室</h2><p>網站已內建教育部 37 個注音標準發音（真人錄音）。如果想讓孩子聽到爸爸媽媽的聲音，可以在這裡自己錄，並勾選下方「優先播放家長錄音」。錄音只存在這台裝置。</p></div><span class="pill">已錄 ${done}／37</span></div><section class="card"><div class="rec-now"><span class="rec-sym">${z.sym}</span><div><strong>現在要錄：「${z.sym}」</strong><small>例：${z.word}（${z.zy}）。按下錄音後約 2 秒，清楚唸一次符號本身，例如 ㄅ 唸「ㄅㄛ」。</small></div></div><div class="rowactions"><button class="btn btn-dark" data-action="rec-start" ${recBusy?'disabled':''}>${recBusy?'🔴 錄音中…':'🎙️ 錄音（2 秒）'}</button><button class="btn btn-outline" data-action="rec-play" ${AudioStore.keys.has('zy:'+z.sym)?'':'disabled'}>▶ 聽錄音</button><button class="btn btn-outline" data-action="rec-del" ${AudioStore.keys.has('zy:'+z.sym)?'':'disabled'}>🗑 刪除</button></div><div class="rec-grid">${ZHUYIN.map(x=>`<button class="rec-item ${x.sym===z.sym?'selected':''} ${AudioStore.keys.has('zy:'+x.sym)?'done':''}" data-action="rec-select" data-sym="${x.sym}">${x.sym}${AudioStore.keys.has('zy:'+x.sym)?'<small>✓</small>':''}</button>`).join('')}</div><div class="settings-row"><label for="prefer-parent">優先播放家長錄音<small>勾選後，有錄音的符號播放你的聲音，其他符號播放內建音檔。</small></label><input type="checkbox" id="prefer-parent" data-action="prefer-parent" ${preferParentClip()?'checked':''} style="width:24px;height:24px;accent-color:#1b9277"/></div><p class="note">錄完一個會自動跳到下一個。沒錄的符號一律播放網站內建音檔。錄音不會包含在匯出的 JSON 備份裡。</p></section>`}
function voiceSettings(){const vs=zhVoices();let pref='';try{pref=localStorage.getItem(VOICE_PREF_KEY)||''}catch(_){}const cur=pickChineseVoice();
 return `<div class="settings-row"><label for="zh-voice">朗讀聲音<small>${vs.length?`這台裝置有 ${vs.length} 個中文聲音，建議選「中文（台灣）」，名稱有「加強／Enhanced／Premium」的最自然。`:'目前沒有偵測到中文語音（請看下方說明）。'}</small></label><select id="zh-voice" data-action="zh-voice"><option value="">自動選擇${cur?'（'+h(cur.name)+'）':''}</option>${vs.map(v=>`<option value="${h(v.voiceURI)}" ${v.voiceURI===pref?'selected':''}>${h(v.name)}（${h(v.lang)}）</option>`).join('')}</select></div><div class="rowactions" style="margin-top:6px"><button class="btn btn-outline" data-action="zh-voice-test">▶ 試聽：「小明從 1 樓走到 3 樓，要爬幾層樓梯？」</button></div><p class="note"><b>聲音很像機器人？</b>iPhone／iPad：到「設定 → 輔助使用 → 朗讀內容 → 聲音 → 中文（台灣）」，下載「美佳（加強版）」，回來在上面選它。Android：到「設定 → 文字轉語音」，安裝 Google 語音服務並下載「中文（台灣）」語音。</p>`}
// 單一符號的代用字（沒錄音時使用）：盡量選手機唸得準的字
for(const [sym,ch] of [['ㄘ','疵'],['ㄜ','婀'],['ㄥ','鞥'],['ㄦ','兒']]){const z=ZHUYIN.find(x=>x.sym===sym);if(z)z.sound=ch}
const _zyQ=zhuyinQuestion;zhuyinQuestion=function(lv,m,u){const q=_zyQ(lv,m,u);if(m==='listen')q.zySym=q.answer;return q};
playZySymbol=function(sym,withWord=false){const z=ZHUYIN.find(x=>x.sym===sym);playClipOr('zy:'+sym,()=>speakChinese(z?(withWord?z.sound+'，'+z.word:z.sound):sym))};
speakQuestion=function(){if(!session)return;const q=session.items[session.idx];if(!q)return;const parts=questionReadParts(q);if(q.zySym)speakChinese(parts,{onend:()=>setTimeout(()=>playZySymbol(q.zySym,!AudioStore.keys.has('zy:'+q.zySym)),250)});else if(q.zhSound)speakChinese([...parts,'請聽：'+q.zhSound]);else speakChinese(parts)};
speakZhSound=function(){if(!session)return;const q=session.items[session.idx];if(!q)return;if(q.zySym)playZySymbol(q.zySym,!AudioStore.keys.has('zy:'+q.zySym));else if(q.zhSound)speakChinese(q.zhSound)};
let AVOID=new Set();
roundFrom=function(fn,size=8){const list=[],used=new Set(AVOID),mine=new Set();for(let i=0;i<size;i++){let q,k=0;do{q=fn(used);k++}while((used.has(q.signature)||mine.has(q.signature))&&k<60);used.add(q.signature);mine.add(q.signature);list.push(q)}return list};
generateNewSubjectRound=function(sub,m,lv){const size=Math.min(8,bankPoolSize(sub,m,lv)),list=[],used=new Set(AVOID),mine=new Set();for(let i=0;i<size;i++){let q,k=0;do{q=sub==='logic'?logicQuestion(lv,m,used):scienceQuestion(lv,m,used);k++}while((used.has(q.signature)||mine.has(q.signature))&&k<60);used.add(q.signature);mine.add(q.signature);list.push(q)}return list};
function generateQuestions(sub,m,lv){if(sub==='science'&&m==='lesson')return scienceCourseRound();if(sub==='math'&&m==='times')return timesRound();if(sub==='chinese')return m==='review'?dueReviews('chinese').slice(0,data.settings.roundSize||8).map(freshReviewQuestion):generateChineseRound(m);if(m==='review')return generateQuestionsBase(sub,m,lv);const recent=new Set(data.recent?.[sub+':'+m]||[]);AVOID=recent;try{const make=()=>v26Round(sub,m,lv)||generateQuestionsBase(sub,m,lv);return pickVaried([make(),make(),make()],data.settings.roundSize||8,recent)}finally{AVOID=new Set()}}
try{AudioStore.load()}catch(_){}

pickBank=function(bank,lv,used,prefix){const tagged=bank.map((x,i)=>({x,i,sig:prefix+'-'+i}));const fresh=tagged.filter(t=>!used.has(t.sig)&&t.x.l<=lv);const same=fresh.filter(t=>t.x.l===lv);return one(same.length&&Math.random()<0.6?same:fresh.length?fresh:tagged.filter(t=>t.x.l<=lv))};
COUNT_ICONS.splice(0,COUNT_ICONS.length,'⚾','🍎','⭐','🍩','🎈','🍪','🍓','🥚');Object.assign(COUNT_NAMES,{'🍩':'甜甜圈','🎈':'氣球','🍪':'餅乾','🥚':'雞蛋'});

// ===== v27：支援放在網站 /audio/zhuyin/ 的注音音檔 =====
const ZY_FILE_ID={'ㄅ':'b','ㄆ':'p','ㄇ':'m','ㄈ':'f','ㄉ':'d','ㄊ':'t','ㄋ':'n','ㄌ':'l','ㄍ':'g','ㄎ':'k','ㄏ':'h','ㄐ':'j','ㄑ':'q','ㄒ':'x','ㄓ':'zh','ㄔ':'ch','ㄕ':'sh','ㄖ':'r','ㄗ':'z','ㄘ':'c','ㄙ':'s','ㄧ':'i','ㄨ':'u','ㄩ':'yu','ㄚ':'a','ㄛ':'o','ㄜ':'e','ㄝ':'eh','ㄞ':'ai','ㄟ':'ei','ㄠ':'ao','ㄡ':'ou','ㄢ':'an','ㄣ':'en','ㄤ':'ang','ㄥ':'eng','ㄦ':'er'};
const missingZyFiles=new Set();
function playSiteZyFile(sym,fallback){const id=ZY_FILE_ID[sym];if(!id||missingZyFiles.has(id))return fallback();let done=false;const fail=()=>{if(done)return;done=true;missingZyFiles.add(id);fallback()};
 try{stopEnglish();const a=new Audio('./audio/zhuyin/'+id+'.mp3');activeClip=a;a.onerror=fail;const p=a.play();if(p&&p.catch)p.then(()=>{done=true}).catch(e=>{if(e&&e.name==='NotAllowedError'){done=true;toast('請再按一次播放')}else fail()});setTimeout(()=>{if(!done&&a.readyState===0)fail()},2500)}catch(_){fail()}}
// 播放順序：家長錄音 → 網站音檔 → 手機語音
playZySymbol=function(sym,withWord=false){const z=ZHUYIN.find(x=>x.sym===sym);playClipOr('zy:'+sym,()=>playSiteZyFile(sym,()=>speakChinese(z?(withWord?z.sound+'，'+z.word:z.sound):sym)))};

// ===== v28：37 個注音 MP3 正式整合 =====
// 單一播放器：同一時間只會有一個聲音；換符號時立刻停止上一個。
const PREFER_PARENT_KEY='homerun_prefer_parent_clip';
const zyPlayer=(()=>{try{const a=new Audio();a.preload='auto';return a}catch(_){return null}})();
let zyToken=0,zyUnlocked=false,zyPrefetched=false;
function zyUrl(sym){const id=ZY_FILE_ID[sym];return id?'./audio/zhuyin/'+id+'.mp3':null}
function stopZyAudio(){zyToken++;try{if(zyPlayer){zyPlayer.pause();zyPlayer.currentTime=0}}catch(_){}try{if(activeClip){activeClip.pause();activeClip=null}}catch(_){}}
// iPhone Safari：第一次觸控時先「解鎖」播放器，之後題目朗讀結束自動播放符號才不會被擋
function unlockZyPlayer(){if(zyUnlocked||!zyPlayer)return;zyUnlocked=true;try{zyPlayer.muted=true;zyPlayer.src=zyUrl('ㄚ');const p=zyPlayer.play();const done=()=>{try{zyPlayer.pause();zyPlayer.currentTime=0}catch(_){}zyPlayer.muted=false};if(p&&p.then)p.then(done,done);else done()}catch(_){zyPlayer.muted=false}}
try{document.addEventListener('pointerdown',unlockZyPlayer,{once:true,capture:true});document.addEventListener('touchend',unlockZyPlayer,{once:true,capture:true})}catch(_){}
// 進入注音頁面時，背景預先下載 37 個小音檔（約 250KB），之後點擊幾乎立即播放
function prefetchZyAudio(){if(zyPrefetched||typeof fetch!=='function')return;zyPrefetched=true;Object.keys(ZY_FILE_ID).forEach((sym,i)=>setTimeout(()=>{try{fetch(zyUrl(sym),{cache:'force-cache'}).catch(()=>{})}catch(_){}},i*40))}
function preferParentClip(){try{return localStorage.getItem(PREFER_PARENT_KEY)==='1'}catch(_){return false}}
function zyLoadFailed(sym){toast(`「${sym}」的音檔暫時無法播放，請再按一次`)}
function playZyFile(sym){const url=zyUrl(sym);if(!zyPlayer||!url){zyLoadFailed(sym);return}
 const token=++zyToken;try{if('speechSynthesis' in window)speechSynthesis.cancel()}catch(_){}try{if(activeRecordedAudio){activeRecordedAudio.pause()}}catch(_){}try{if(activeClip){activeClip.pause();activeClip=null}}catch(_){}
 try{zyPlayer.pause();zyPlayer.muted=false;zyPlayer.defaultPlaybackRate=1;zyPlayer.playbackRate=1;if(!zyPlayer.src.endsWith(url))zyPlayer.src=url;zyPlayer.currentTime=0;
  zyPlayer.onerror=()=>{if(token!==zyToken)return;if(AudioStore.keys.has('zy:'+sym))playClipOr('zy:'+sym,()=>zyLoadFailed(sym));else zyLoadFailed(sym)};
  const p=zyPlayer.play();if(p&&p.catch)p.catch(e=>{if(token!==zyToken)return;if(e&&e.name==='AbortError')return;if(e&&e.name==='NotAllowedError'){toast('請再按一次 🔊 播放');return}zyPlayer.onerror&&zyPlayer.onerror()})}catch(_){zyLoadFailed(sym)}}
// 播放注音符號：一律使用 MP3（家長可在家長區改成優先播放自己的錄音）；不再用手機語音唸單一符號
playZySymbol=function(sym){if(preferParentClip()&&AudioStore.keys.has('zy:'+sym)){stopZyAudio();playClipOr('zy:'+sym,()=>playZyFile(sym));return}playZyFile(sym)};
speakQuestion=function(){if(!session)return;const q=session.items[session.idx];if(!q)return;const parts=questionReadParts(q);if(q.zySym){stopZyAudio();speakChinese(parts,{onend:()=>setTimeout(()=>{if(page==='quiz'&&session&&session.items[session.idx]===q)playZySymbol(q.zySym)},200)})}else if(q.zhSound)speakChinese([...parts,'請聽：'+q.zhSound]);else speakChinese(parts)};
speakZhSound=function(){if(!session)return;const q=session.items[session.idx];if(!q)return;if(q.zySym)playZySymbol(q.zySym);else if(q.zhSound)speakChinese(q.zhSound)};
// 停止所有英文、中文朗讀時，也一併停止注音音檔
const _stopEnglishV27=stopEnglish;stopEnglish=function(){_stopEnglishV27();stopZyAudio()};
// 看圖找注音：答完可以聽正確的第一個符號
const _zyQV27=zhuyinQuestion;zhuyinQuestion=function(lv,m,u){const q=_zyQV27(lv,m,u);if(m==='listen'||m==='picture')q.zyAnswerSym=q.answer;if(m==='listen'){q.noReadMain=true;q.prompt='👂 聽一聽，找出聽到的注音符號'}return q};

// ===== v29：家長區分頁、首頁面板改版 =====
let parentTab='report';
const PARENT_TABS=[['report','📊','學習報告'],['practice','⚙️','練習設定'],['players','👥','小朋友管理'],['voice','🔊','朗讀音效'],['data','🔒','資料密碼']];
function parentTabsNav(){return `<nav class="ptab-nav" aria-label="家長區分類">${PARENT_TABS.map(([k,i,n])=>`<button type="button" class="${parentTab===k?'active':''}" data-action="ptab" data-tab="${k}" aria-pressed="${parentTab===k}"><span aria-hidden="true">${i}</span>${n}</button>`).join('')}</nav>`}
const SUBJECT_COLOR={chinese:'#bd4f70',zhuyin:'#e8603c',english:'#4c7be8',math:'#e3a21a',logic:'#8b5cf6',science:'#1b9277'};
function currentStreak(){const days=new Set(data.sessions.map(s=>localDay(s.date)));let n=0;const d=new Date();if(!days.has(localDay(d)))d.setDate(d.getDate()-1);while(days.has(localDay(d))){n++;d.setDate(d.getDate()-1)}return n}
function suggestedSubject(){const subs=subjectsForGrade();const due=subs.find(sb=>dueReviews(sb).length);if(due)return {sb:due,review:true};const today=localDay(Date.now());const notToday=subs.find(sb=>!data.sessions.some(s=>s.subject===sb&&localDay(s.date)===today));return {sb:notToday||subs[0],review:false}}
function home(){const p=activeProfile(),ps=progressStats(),badges=earnedBadgeIds().length,streak=currentStreak(),sug=suggestedSubject(),sm=SUBJECT_META[sug.sb],rs=reviewSuggestion();
 const tile=sb=>{const st=getSubStats(sb),mt=SUBJECT_META[sb],due=dueReviews(sb).length;return `<button class="tile2" style="--accent:${SUBJECT_COLOR[sb]}" data-action="choose-sub" data-subject="${sb}"><span class="t2-icon" aria-hidden="true">${mt.icon}</span><span class="t2-body"><strong>${mt.name}</strong><small>${tileText(sb)}</small><span class="t2-bar" aria-hidden="true"><i style="width:${st.accuracy??0}%"></i></span><span class="t2-meta">${st.num?`${st.num} 回合 · 正確率 ${st.accuracy}%`:'還沒練習過'}${due?` · 🔁 ${due} 題待複習`:''}</span></span><span class="t2-go" aria-hidden="true">→</span></button>`};
 const todayDone=sb=>data.sessions.some(s=>s.subject===sb&&localDay(s.date)===localDay(Date.now()));
 return `<section class="player-banner">${themeCopy().deco?`<span class="pb-deco" aria-hidden="true">${themeCopy().deco}</span>`:''}<div class="pb-top"><span class="pb-avatar" aria-hidden="true">${p.avatar}</span><div class="pb-name"><div class="pb-eyebrow">${themeCopy().eyebrow}</div><h1>${h(p.name)}</h1><span class="pb-grade">${GRADES[p.grade]}</span></div><span class="pb-btns"><button class="pb-switch" data-action="nav-players" aria-label="換畫面風格">🎨</button><button class="pb-switch" data-action="nav-login">換人 ⇄</button></span></div>
 <div class="pb-stats"><div><b>${ps.todayRuns}</b><small>${currentWorld()==='baseball'?'今日得分':WORLD_SCORE[currentWorld()].today}</small></div><div><b>${ps.todayCorrect}</b><small>今日答對</small></div><div><b>${streak}</b><small>連續天數</small></div><div><b>${badges}</b><small>${themeCopy().badgeWord}</small></div></div>
 <button class="pb-go" data-action="${sug.review?'review-sub':'choose-sub'}" data-subject="${sug.sb}"><span>${sug.review?themeCopy().review:themeCopy().go}</span><strong>${sm.icon} ${sm.name}${sug.review?` · ${dueReviews(sug.sb).length} 題`:''}</strong></button>${rs.total>1&&!sug.review?'':''}</section>
 <div class="section-title"><div><h2>${themeCopy().pick}</h2><p>${themeCopy().pickSub||`每回合 ${data.settings.roundSize||8} 題，每題都能按 🔊 聽題目。`}</p></div></div>
 <div class="tiles2">${subjectsForGrade().map(tile).join('')}<button class="tile2" data-action="times-open"><span class="t2-icon" aria-hidden="true">✖️</span><span class="t2-body"><strong>九九乘法</strong><small>1～9 全部混合 · 獨立練習</small></span><span class="t2-go" aria-hidden="true">→</span></button></div>
 ${progressCard()}
 <div class="mini-row"><section class="card mini-tasks"><h3>🎯 今日小任務</h3>${subjectsForGrade().slice(0,2).map(sb=>`<div class="mt-row ${todayDone(sb)?'done':''}"><span>${todayDone(sb)?'✅':'⚪'}</span>一回合${SUBJECT_META[sb].name}</div>`).join('')}<div class="mt-row"><span>💬</span>告訴大人今天學到什麼</div><p class="note" style="margin:8px 0 0">累了可以休息，這不是強制目標。</p></section><button class="card mini-hw" data-action="nav-handwrite"><span aria-hidden="true">✍️</span><strong>手寫練習場</strong><small>描寫字母、單字，列式計算</small></button></div>`}


// ===== v30：球隊推理（多場景）＋台鋼雄鷹小名 =====
// 名字換成台鋼雄鷹球員的小名（家長指定＋公開報導）
LINEUP_NAMES.splice(0,LINEUP_NAMES.length,'小佑','小紀','雞柳條','大顏','妹妹','浣熊二哥','高腰褲大王','大王','二弟');
TRUTH_EVENTS.splice(0,TRUTH_EVENTS.length,'撿到了遺失的棒球','把球具收進倉庫','把休息區打掃乾淨','幫教練拿了水壺','把隊旗掛起來');
{const map={'小安':'小佑','阿哲':'大顏','小美':'小紀','阿宏':'浣熊二哥'};for(const b of RULES_BANK){for(const [a,z] of Object.entries(map)){b.q=b.q.split(a).join(z);b.a=b.a.split(a).join(z);b.e=b.e.split(a).join(z);b.o=b.o.map(o=>o.split(a).join(z))}}}
{const m=MODES.logic.find(x=>x.id==='lineup');if(m){m.name='球隊推理';m.label='條件推理';m.icon='🕵️‍♂️';m.desc='打序、賽跑名次、休息區座位、守備位置、背號……從線索推出唯一答案。'}}

// 排序場景：位置從 0 開始
const ORDER_SCENES=[
 {id:'bat',title:'教練的打序線索',unit:i=>`第${CN5[i]}棒`,ask:i=>`誰是第${CN5[i]}棒？`,at:(a,i)=>`${a}是第${CN5[i]}棒。`,not:(a,i)=>`${a}不是第${CN5[i]}棒。`,before:(a,b)=>`${a}比${b}先上場打擊。`,next:(a,b)=>`${b}緊接在${a}後面打擊。`,first:a=>`${a}是第一棒。`,last:a=>`${a}是最後一棒。`,mid:a=>`${a}不是第一棒，也不是最後一棒。`,gap:(a,b,k)=>`${a}和${b}的棒次中間隔了 ${k} 個人。`,intro:n=>`${n} 人輪流打擊。`},
 {id:'race',title:'跑壘比賽的名次',unit:i=>`第${CN5[i]}名`,ask:i=>`誰是第${CN5[i]}名？`,at:(a,i)=>`${a}跑第${CN5[i]}名。`,not:(a,i)=>`${a}不是第${CN5[i]}名。`,before:(a,b)=>`${a}比${b}先跑回本壘。`,next:(a,b)=>`${b}緊跟在${a}後面衝回本壘。`,first:a=>`${a}跑第一名。`,last:a=>`${a}跑最後一名。`,mid:a=>`${a}不是第一名，也不是最後一名。`,gap:(a,b,k)=>`${a}和${b}的名次中間隔了 ${k} 個人。`,intro:n=>`${n} 人比賽繞壘跑，沒有人同時到。`},
 {id:'arrive',title:'誰先到球場',unit:i=>`第${CN5[i]}個到`,ask:i=>`誰是第${CN5[i]}個到球場的？`,at:(a,i)=>`${a}是第${CN5[i]}個到的。`,not:(a,i)=>`${a}不是第${CN5[i]}個到的。`,before:(a,b)=>`${a}比${b}早到球場。`,next:(a,b)=>`${a}一到，${b}就緊接著到了。`,first:a=>`${a}最早到。`,last:a=>`${a}最晚到。`,mid:a=>`${a}不是最早到，也不是最晚到。`,gap:(a,b,k)=>`${a}和${b}之間還有 ${k} 個人到。`,intro:n=>`${n} 人一個一個到球場練球。`},
 {id:'seat',title:'休息區的座位',unit:i=>`左邊數來第${CN5[i]}個位子`,ask:i=>`誰坐在左邊數來第${CN5[i]}個位子？`,at:(a,i)=>`${a}坐在左邊數來第${CN5[i]}個位子。`,not:(a,i)=>`${a}沒有坐在左邊數來第${CN5[i]}個位子。`,before:(a,b)=>`${a}坐在${b}的左邊（不一定相鄰）。`,next:(a,b)=>`${b}就坐在${a}的右手邊（相鄰）。`,first:a=>`${a}坐最左邊。`,last:a=>`${a}坐最右邊。`,mid:a=>`${a}沒有坐在最左邊，也沒有坐在最右邊。`,gap:(a,b,k)=>`${a}和${b}中間隔了 ${k} 個人。`,intro:n=>`${n} 人在休息區坐成一排。`},
 {id:'height',title:'從矮到高排隊',unit:i=>`第${CN5[i]}個`,ask:i=>`從矮到高排，第${CN5[i]}個是誰？`,at:(a,i)=>`${a}排第${CN5[i]}個。`,not:(a,i)=>`${a}不是排第${CN5[i]}個。`,before:(a,b)=>`${a}比${b}矮。`,next:(a,b)=>`${b}剛好排在${a}的下一個。`,first:a=>`${a}最矮。`,last:a=>`${a}最高。`,mid:a=>`${a}不是最矮，也不是最高。`,gap:(a,b,k)=>`${a}和${b}中間隔了 ${k} 個人。`,intro:n=>`${n} 人從矮到高排成一排，沒有人一樣高。`}
];
const CN5=['一','二','三','四','五'];
// 配對場景
const ASSIGN_SCENES=[
 {id:'pos',title:'守備位置',items:['投手','捕手','一壘手','游擊手','中外野手'],is:(a,x)=>`${a}守${x}。`,not:(a,x)=>`${a}不是${x}。`,either:(a,b,x)=>`${x}是${a}或${b}其中一人。`,askWho:x=>`誰是${x}？`,askWhat:a=>`${a}守哪個位置？`,intro:n=>`${n} 人各守一個不同的位置。`},
 {id:'glove',title:'手套顏色',items:['紅色','藍色','黑色','白色','金色'],is:(a,x)=>`${a}的手套是${x}。`,not:(a,x)=>`${a}的手套不是${x}。`,either:(a,b,x)=>`${x}手套是${a}或${b}的。`,askWho:x=>`誰的手套是${x}？`,askWhat:a=>`${a}的手套是什麼顏色？`,intro:n=>`${n} 人的手套顏色都不一樣。`},
 {id:'snack',title:'賽後點心',items:['雞排','布丁','烤香腸','蛋餅','西瓜'],is:(a,x)=>`${a}吃${x}。`,not:(a,x)=>`${a}沒有吃${x}。`,either:(a,b,x)=>`吃${x}的是${a}或${b}。`,askWho:x=>`誰吃${x}？`,askWhat:a=>`${a}吃什麼？`,intro:n=>`比賽後 ${n} 人各吃一種不同的點心。`},
 {id:'num',title:'背號推理',items:['3號','7號','11號','24號','52號'],numeric:true,is:(a,x)=>`${a}穿${x}。`,not:(a,x)=>`${a}不是穿${x}。`,either:(a,b,x)=>`穿${x}的是${a}或${b}。`,gt:(a,b)=>`${a}的背號比${b}大。`,odd:(a,o)=>`${a}的背號是${o?'單數':'雙數'}。`,askWho:x=>`誰穿${x}？`,askWhat:a=>`${a}穿幾號？`,intro:n=>`${n} 人的背號都不一樣。`}
];
const numOf=x=>parseInt(x,10);
function orderPuzzle(level){const n=level===1?3:level===2?4:5,S=one(ORDER_SCENES),names=shuffle(LINEUP_NAMES).slice(0,n),order=shuffle(names),pos=Object.fromEntries(order.map((x,i)=>[x,i])),all=permutations(names);
 const mk=()=>{const t=rand(0,level===1?4:5);let a=one(names),b=one(names.filter(x=>x!==a));
  if(t===0){const k=rand(0,n-1);return pos[a]===k?null:{type:'not',a,k,text:S.not(a,k),ok:p=>p.indexOf(a)!==k,key:'n'+a+k}}
  if(t===1){if(pos[a]>pos[b])[a,b]=[b,a];return {type:'before',a,b,text:S.before(a,b),ok:p=>p.indexOf(a)<p.indexOf(b),key:'b'+a+b}}
  if(t===2){const i=pos[a];if(i===n-1)return null;const nx=order[i+1];return {type:'next',a,b:nx,text:S.next(a,nx),ok:p=>p.indexOf(nx)===p.indexOf(a)+1,key:'x'+a}}
  if(t===3){const i=pos[a];if(i===0)return {type:'first',a,text:S.first(a),ok:p=>p[0]===a,key:'F'};if(i===n-1)return {type:'last',a,text:S.last(a),ok:p=>p[n-1]===a,key:'L'};return null}
  if(t===4){const i=pos[a];return i===0||i===n-1?null:{type:'mid',a,text:S.mid(a),ok:p=>{const j=p.indexOf(a);return j!==0&&j!==n-1},key:'m'+a}}
  const d=Math.abs(pos[a]-pos[b]);return d<2?null:{type:'gap',a,b,k:d-1,text:S.gap(a,b,d-1),ok:p=>Math.abs(p.indexOf(a)-p.indexOf(b))===d,key:'g'+[a,b].sort().join('')}};
 let clues=[],g=0;const fits=c=>all.filter(p=>c.every(x=>x.ok(p)));
 while(fits(clues).length>1&&g++<400){const c=mk();if(!c||clues.some(x=>x.key===c.key))continue;if(fits([...clues,c]).length<fits(clues).length)clues.push(c)}
 if(fits(clues).length!==1||clues.length>(level===1?4:level===2?6:7))return null;
 for(let i=clues.length-1;i>=0;i--){const t=clues.filter((_,j)=>j!==i);if(fits(t).length===1)clues=t}
 const stated=new Set(clues.filter(c=>c.type==='first').map(()=>0).concat(clues.filter(c=>c.type==='last').map(()=>n-1)));const ks=[...Array(n).keys()].filter(k=>!stated.has(k));const k=ks.length?one(ks):rand(0,n-1),ans=order[k];
 const choices=n===3?shuffle([...names,'線索不夠，無法確定']):n===4?shuffle(names):shuffle([ans,...shuffle(names.filter(x=>x!==ans)).slice(0,3)]);
 return {skill:'logic-order',prompt:`🕵️‍♂️ ${S.title}：讀線索，排一排`,main:clues.map((c,i)=>`${i+1}. ${c.text}`).join('\n'),second:`${names.join('、')}，${S.intro(n)}${S.ask(k)}`,answer:ans,choices,explain:`正確的順序：${order.map((x,i)=>`${S.unit(i)} ${x}`).join(' → ')}。`,hint:'畫一排格子，先放最確定的人，再用「不是……」「比……」排除。',signature:'ord-'+S.id+order.join('')+clues.map(c=>c.key).join(''),concept:'ord-'+S.id,reason:true,__check:{kind:'order',n,names,clues:clues.map(({type,a,b,k})=>({type,a,b,k})),askPos:k}}}
function assignPuzzle(level){const n=level===1?3:level===2?4:5,S=one(ASSIGN_SCENES),names=shuffle(LINEUP_NAMES).slice(0,n),items=shuffle(S.items).slice(0,n),sol=Object.fromEntries(names.map((x,i)=>[x,items[i]])),all=permutations(items).map(p=>Object.fromEntries(names.map((x,i)=>[x,p[i]])));
 const mk=()=>{const t=rand(0,S.numeric?4:2);const a=one(names),b=one(names.filter(x=>x!==a));
  if(t===0){const x=one(items.filter(x=>x!==sol[a]));return {type:'not',a,x,text:S.not(a,x),ok:p=>p[a]!==x,key:'n'+a+x}}
  if(t===1){const x=sol[one([a,b])];return {type:'either',a,b,x,text:S.either(a,b,x),ok:p=>p[a]===x||p[b]===x,key:'e'+[a,b].sort().join('')+x}}
  if(t===2){return level===1||rand(0,2)===0?{type:'is',a,x:sol[a],text:S.is(a,sol[a]),ok:p=>p[a]===sol[a],key:'i'+a}:null}
  if(t===3){let [p1,p2]=numOf(sol[a])>numOf(sol[b])?[a,b]:[b,a];return {type:'gt',a:p1,b:p2,text:S.gt(p1,p2),ok:p=>numOf(p[p1])>numOf(p[p2]),key:'g'+p1+p2}}
  const o=numOf(sol[a])%2===1;return {type:'odd',a,o,text:S.odd(a,o),ok:p=>(numOf(p[a])%2===1)===o,key:'o'+a}};
 let clues=[],g=0;const fits=c=>all.filter(p=>c.every(x=>x.ok(p)));
 while(fits(clues).length>1&&g++<400){const c=mk();if(!c||clues.some(x=>x.key===c.key))continue;if(fits([...clues,c]).length<fits(clues).length)clues.push(c)}
 if(fits(clues).length!==1||clues.length>(level===1?4:level===2?6:7))return null;
 for(let i=clues.length-1;i>=0;i--){const t=clues.filter((_,j)=>j!==i);if(fits(t).length===1)clues=t}
 const known=new Set(clues.filter(c=>c.type==='is').map(c=>c.a));const pool=names.filter(x=>!known.has(x));const who=one(pool.length?pool:names);const askWho=rand(0,1)===0;
 let second,answer,choices;if(askWho){answer=who;second=S.askWho(sol[who]);choices=n===3?shuffle([...names,'線索不夠，無法確定']):n===4?shuffle(names):shuffle([who,...shuffle(names.filter(x=>x!==who)).slice(0,3)])}
 else{answer=sol[who];second=S.askWhat(who);choices=n===3?shuffle([...items,'線索不夠，無法確定']):n===4?shuffle(items):shuffle([answer,...shuffle(items.filter(x=>x!==answer)).slice(0,3)])}
 return {skill:'logic-order',prompt:`🕵️‍♂️ ${S.title}：讀線索，配一配`,main:clues.map((c,i)=>`${i+1}. ${c.text}`).join('\n'),second:`${names.join('、')}${S.intro(n).replace(/^\d+ 人/,`這 ${n} 人`)}（選項：${items.join('、')}）${second}`,answer,choices,explain:`配對結果：${names.map(x=>`${x}→${sol[x]}`).join('、')}。`,hint:'畫一個表格：橫的是人、直的是選項，確定的打 ○、不可能的打 ✕。',signature:'asg-'+S.id+names.map(x=>sol[x]).join('')+clues.map(c=>c.key).join('')+(askWho?'W':'H'),concept:'asg-'+S.id,reason:true,__check:{kind:'assign',numeric:!!S.numeric,names,items,clues:clues.map(({type,a,b,x,o})=>({type,a,b,x,o})),ask:askWho?{who:true,item:sol[who]}:{who:false,name:who}}}}
lineupQuestion=function(level){for(let i=0;i<50;i++){const q=rand(0,9)<5?orderPuzzle(level):assignPuzzle(level);if(q)return q}return _lineupV24(Math.min(level,2))};


// ===== v31：公主城堡／可愛動物風格、第 4 級菁英、數學應用題擴充 =====
Object.assign(THEMES,{princess:{name:'公主城堡',icon:'👑'},animals:{name:'可愛動物',icon:'🐰'}});
const THEME_COPY={
 space:{eyebrow:'今天的小小探險家',go:'▶ 啟動探索',review:'🔁 任務複習',pick:'選一個探索任務',pickSub:'每答對一題，就收集一顆探索能量 ⚡',runner:'🚀',deco:'🪐',badgeWord:'徽章',ballpark:'🚀 今日太空站'},
 princess:{eyebrow:'今天的小公主',go:'▶ 出發冒險',review:'🔁 魔法複習',pick:'選一堂魔法課',pickSub:'每完成一題，城堡就多一顆星星 ✨',runner:'👑',deco:'🏰',badgeWord:'寶石',ballpark:'👑 今日城堡'},
 animals:{eyebrow:'動物小隊長',go:'▶ 出發探險',review:'🔁 回森林複習',pick:'選一間森林教室',pickSub:'答對一題，小動物就往前跳一格 🐾',runner:'🐰',deco:'🐻',badgeWord:'貼紙',ballpark:'🐾 今日森林'},
 _default:{eyebrow:'今天上場的球員',go:'▶ 下一棒',review:'🔁 先複習',pick:'選一科開始',pickSub:'',runner:'🏃',deco:'',badgeWord:'徽章',ballpark:'⚾ 今日球場'}};
function themeCopy(){return THEME_COPY[activeProfile().theme]||THEME_COPY._default}
const LEVEL_NAMES=['基礎','進階','挑戰','菁英'];

// --- 數學應用題：多種情境，依難度調整數字 ---
const STORY_NAMES=()=>one(LINEUP_NAMES);const TWO=()=>shuffle(LINEUP_NAMES).slice(0,2);
function storyRange(lv){return lv===1?{a:[2,12],b:[1,8],k:[2,5],n:[2,5],money:[10,50]}:lv===2?{a:[12,60],b:[5,35],k:[2,9],n:[3,9],money:[30,100]}:lv===3?{a:[60,400],b:[20,250],k:[3,9],n:[4,12],money:[100,500]}:{a:[300,2000],b:[100,900],k:[6,19],n:[12,45],money:[500,2000]}}
const R=([a,b])=>rand(a,b);
const STORY_T=[
 {min:1,f:(lv,r)=>{const a=R(r.money),b=R(r.money);return {main:`棒球手套 ${a} 元、球帽 ${b} 元，兩樣一起買要多少元？`,ans:a+b,exp:`${a}＋${b}＝${a+b} 元。`}}},
 {min:1,f:(lv,r)=>{const a=R(r.money),P=(Math.floor(a/10)+rand(1,5))*10;return {main:`${STORY_NAMES()}帶了 ${P} 元，買了一個 ${a} 元的水壺，可以找回多少元？`,ans:P-a,exp:`${P}−${a}＝${P-a} 元。`}}},
 {min:1,f:(lv,r)=>{const a=R(r.a)+5,b=rand(1,Math.min(a-1,r.b[1])),c=R(r.b);return {main:`球隊巴士上有 ${a} 人，到第一站下車 ${b} 人、又上車 ${c} 人。現在車上有幾人？`,ans:a-b+c,exp:`先減下車：${a}−${b}＝${a-b}；再加上車：${a-b}＋${c}＝${a-b+c} 人。`}}},
 {min:1,f:(lv,r)=>{const a=R(r.a)+3,d=rand(1,a-1),[x,y]=TWO();return {main:`${x}有 ${a} 張球員卡，${y}比${x}少 ${d} 張。${y}有幾張？`,ans:a-d,exp:`「比……少」用減法：${a}−${d}＝${a-d} 張。`}}},
 {min:1,f:(lv,r)=>{const p=lv===1?8:lv===2?12:16,e=rand(1,p-1);return {main:`一個披薩切成 ${p} 片，大家吃掉了 ${e} 片，還剩幾片？`,ans:p-e,exp:`${p}−${e}＝${p-e} 片。`}}},
 {min:1,f:(lv,r)=>{const t1=rand(15,22),d=rand(2,lv===1?6:12);return {main:`早上氣溫 ${t1} 度，中午升到 ${t1+d} 度。氣溫升高了幾度？`,ans:d,exp:`${t1+d}−${t1}＝${d} 度。`}}},
 {min:1,f:(lv,r)=>{const rr=rand(0,3);return {main:`壘上有 ${rr} 位跑者時，打者擊出全壘打，這一棒一共得幾分？`,ans:rr+1,exp:`跑者 ${rr} 人全部回來，再加上打者自己 1 分，共 ${rr+1} 分。`}}},
 {min:2,f:(lv,r)=>{const a=R(r.a),d=R(r.b),[x,y]=TWO();return {main:`${x}有 ${a} 張貼紙，${y}比${x}多 ${d} 張。兩人一共有幾張？`,ans:a+a+d,exp:`${y}有 ${a}＋${d}＝${a+d} 張；兩人共 ${a}＋${a+d}＝${2*a+d} 張。`}}},
 {min:2,f:(lv,r)=>{const u=R(r.k)*(lv>=3?5:1),n=R(r.n);return {main:`一顆練習球 ${u} 元，買 ${n} 顆要多少元？`,ans:u*n,exp:`${u}×${n}＝${u*n} 元。`}}},
 {min:2,f:(lv,r)=>{const n=R(r.k),k=R(r.n);return {main:`${n} 個小朋友平分 ${n*k} 張球員卡，每人可以分到幾張？`,ans:k,exp:`${n*k}÷${n}＝${k} 張。`}}},
 {min:2,f:(lv,r)=>{const k=R(r.k),n=R(r.n);return {main:`每一隊要 ${k} 個人，現在有 ${k*n} 個人，可以分成幾隊？`,ans:n,exp:`${k*n}÷${k}＝${n} 隊。`}}},
 {min:2,f:(lv,r)=>{const d=R(r.k)*(lv>=3?3:1),k=rand(2,6),P=d*k+R(r.b);return {main:`一本漫畫有 ${P} 頁，每天看 ${d} 頁，看了 ${k} 天後還剩幾頁？`,ans:P-d*k,exp:`已看 ${d}×${k}＝${d*k} 頁；剩 ${P}−${d*k}＝${P-d*k} 頁。`}}},
 {min:2,f:(lv,r)=>{const L=one(lv>=3?[200,250,400]:[50,100]),n=R(r.k);return {main:`操場跑一圈是 ${L} 公尺，${STORY_NAMES()}跑了 ${n} 圈，一共跑了幾公尺？`,ans:L*n,exp:`${L}×${n}＝${L*n} 公尺。`}}},
 {min:2,f:(lv,r)=>{const b=R(r.n),k=rand(2,lv>=3?5:3);return {main:`紅隊的得分是藍隊的 ${k} 倍，藍隊得了 ${b} 分，紅隊得幾分？`,ans:b*k,exp:`${b}×${k}＝${b*k} 分。`}}},
 {min:2,f:(lv,r)=>{const k=R(r.k),rw=R(r.n),s=rand(1,k*rw-1);return {main:`觀眾席每排有 ${k} 個座位，一共 ${rw} 排。已經坐了 ${s} 人，還有幾個空位？`,ans:k*rw-s,exp:`總座位 ${k}×${rw}＝${k*rw}；空位 ${k*rw}−${s}＝${k*rw-s} 個。`}}},
 {min:2,f:(lv,r)=>{const s=R(r.k)*(lv>=3?10:5),w=rand(3,8);return {main:`${STORY_NAMES()}每星期存 ${s} 元，存了 ${w} 個星期，一共存了多少元？`,ans:s*w,exp:`${s}×${w}＝${s*w} 元。`}}},
 {min:3,f:(lv,r)=>{const s=R(r.k)*10,w=rand(3,8),X=s*w+rand(1,6)*10;return {main:`${STORY_NAMES()}想買 ${X} 元的新手套，每星期存 ${s} 元，存了 ${w} 個星期後，還差多少元？`,ans:X-s*w,exp:`已存 ${s}×${w}＝${s*w} 元；還差 ${X}−${s*w}＝${X-s*w} 元。`}}},
 {min:3,f:(lv,r)=>{const k=Math.max(4,R(r.k)),T=k*R(r.n)+rand(1,k-1);return {main:`有 ${T} 顆球，每個袋子裝 ${k} 顆，裝滿之後還剩下幾顆？`,ans:T%k,exp:`${T}÷${k}＝${Math.floor(T/k)} 餘 ${T%k}，剩下 ${T%k} 顆。`,max:k-1}}},
 {min:3,f:(lv,r)=>{const k=R(r.k),T=k*R(r.n)+rand(1,k-1);return {main:`有 ${T} 位球員要坐車，每輛車最多坐 ${k} 人，至少需要幾輛車？`,ans:Math.ceil(T/k),exp:`${T}÷${k}＝${Math.floor(T/k)} 餘 ${T%k}，剩下的人也要坐車，所以要 ${Math.floor(T/k)}＋1＝${Math.ceil(T/k)} 輛。`}}},
 {min:3,f:(lv,r)=>{const F=rand(32,45),s=rand(6,10),y=rand(3,9);return {main:`爸爸今年 ${F} 歲，${STORY_NAMES()}今年 ${s} 歲。${y} 年後，爸爸比他大幾歲？`,ans:F-s,exp:`兩人每年都長一歲，年齡差永遠不變：${F}−${s}＝${F-s} 歲。`}}},
 {min:3,f:(lv,r)=>{const x=rand(15,40),y=3*x-rand(1,4)*5;return {main:`A 店一顆棒球 ${x} 元；B 店 3 顆一組賣 ${y} 元。買 3 顆的話，B 店便宜多少元？`,ans:3*x-y,exp:`A 店 3 顆：${x}×3＝${3*x} 元；便宜 ${3*x}−${y}＝${3*x-y} 元。`}}},
 {min:3,f:(lv,r)=>{const n=rand(3,8),u=rand(3,9)*10,hh=rand(10,30)*10,P=Math.ceil((n*u+hh)/100)*100+100;return {main:`買 ${n} 顆球每顆 ${u} 元，再買一頂 ${hh} 元的帽子，付了 ${P} 元，找回多少元？`,ans:P-n*u-hh,exp:`球 ${n}×${u}＝${n*u}；共 ${n*u}＋${hh}＝${n*u+hh}；找回 ${P}−${n*u+hh}＝${P-n*u-hh} 元。`}}},
 {min:3,f:(lv,r)=>{const a=rand(20,90),b=rand(10,60),c=rand(Math.max(50,b),150);return {main:`${STORY_NAMES()}先用掉 ${a} 元，後來又拿到零用錢 ${b} 元，現在有 ${c} 元。他原本有多少元？`,ans:c-b+a,exp:`倒回去想：${c}−${b}＝${c-b}（拿到前），再加回用掉的 ${a}：${c-b+a} 元。`}}},
 {min:3,f:(lv,r)=>{const g=rand(130,150),n=rand(3,6);return {main:`一顆棒球大約 ${g} 公克，${n} 顆大約多重？`,ans:g*n,exp:`${g}×${n}＝${g*n} 公克。`}}},
 {min:3,f:(lv,r)=>{const k=one([2,3,4,5]),T=k*rand(3,9);return {main:`球隊 ${T} 人中，有 1/${k} 是左打。左打有幾人？`,ans:T/k,exp:`把 ${T} 人平分成 ${k} 份，一份是 ${T}÷${k}＝${T/k} 人。`}}},
 {min:4,f:(lv,r)=>{const k=one([3,4,5,6,8]),m=rand(2,k-1),T=k*rand(4,12);return {main:`球隊有 ${T} 人，其中 ${m}/${k} 參加過比賽。參加過比賽的有幾人？`,ans:T/k*m,exp:`一份是 ${T}÷${k}＝${T/k} 人，${m} 份是 ${T/k}×${m}＝${T/k*m} 人。`}}},
 {min:4,f:(lv,r)=>{const avg=rand(3,9),a=avg+rand(-2,2),b=avg+rand(-2,2),c=3*avg-a-b;return c<0?null:{main:`三場比賽分別得 ${a}、${b}、${c} 分，平均每場得幾分？`,ans:avg,exp:`總分 ${a}＋${b}＋${c}＝${3*avg}；平均 ${3*avg}÷3＝${avg} 分。`}}},
 {min:4,f:(lv,r)=>{const A=rand(15,30)*10,C=rand(5,14)*10,x=rand(1,3),y=rand(2,4);return {main:`棒球場門票大人 ${A} 元、小孩 ${C} 元。${x} 個大人、${y} 個小孩一共要多少元？`,ans:A*x+C*y,exp:`${A}×${x}＝${A*x}；${C}×${y}＝${C*y}；合計 ${A*x+C*y} 元。`}}},
 {min:4,f:(lv,r)=>{const k=one([4,6,8,10,12]),a=rand(1,k-2),b=rand(1,k-1-a),[x,y]=TWO();return {main:`一個披薩平分成 ${k} 片，${x}吃了 ${a}/${k}，${y}吃了 ${b}/${k}。兩人一共吃了幾片？`,ans:a+b,exp:`同樣是 ${k} 分之幾，直接把片數相加：${a}＋${b}＝${a+b} 片（也就是 ${a+b}/${k} 個披薩）。`}}},
 {min:4,f:(lv,r)=>{const per=one([3,4,5]),k=rand(6,20);return {main:`${STORY_NAMES()}大約每 ${per} 個打數打出 1 支安打。打了 ${per*k} 個打數，大約有幾支安打？`,ans:k,exp:`${per*k}÷${per}＝${k} 支。`}}}
];
const SCORE_T=[
 {min:1,f:(lv,r)=>{const a=R(r.n)+2,b=rand(0,a-1);return {main:`比賽結束，紅隊 ${a} 分、藍隊 ${b} 分。紅隊贏了幾分？`,ans:a-b,exp:`${a}−${b}＝${a-b} 分。`}}},
 {min:1,f:(lv,r)=>{const k=rand(1,8);return {main:`一場比賽有 9 局，已經打完 ${k} 局，還剩幾局？`,ans:9-k,exp:`9−${k}＝${9-k} 局。`}}},
 {min:1,f:(lv,r)=>{const a=rand(3,9),b=rand(0,a-1);return {main:`紅隊 ${a} 分、藍隊 ${b} 分。藍隊至少還要得幾分才能追平？`,ans:a-b,exp:`追平就是一樣多：${a}−${b}＝${a-b} 分。`}}},
 {min:2,f:(lv,r)=>{const a=rand(3,12),b=rand(0,a-1);return {main:`紅隊 ${a} 分、藍隊 ${b} 分。藍隊至少還要得幾分才能「超前」？`,ans:a-b+1,exp:`追平要 ${a-b} 分，再多 1 分才會超前：${a-b+1} 分。`}}},
 {min:2,f:(lv,r)=>{const s=[0,0,0,0].map(()=>rand(0,lv>=3?5:3));return {main:`紅隊前四局的得分是 ${s.join('、')}，前四局一共得幾分？`,ans:s.reduce((x,y)=>x+y,0),exp:`${s.join('＋')}＝${s.reduce((x,y)=>x+y,0)} 分。`}}},
 {min:2,f:(lv,r)=>{const a=rand(2,6),b=rand(2,6),c=rand(1,4),d=rand(1,4);return {main:`記分板：紅隊 上半場 ${a} 分、下半場 ${b} 分；藍隊 上半場 ${c} 分、下半場 ${d} 分。兩隊相差幾分？`,ans:Math.abs(a+b-c-d),exp:`紅隊 ${a+b}、藍隊 ${c+d}，相差 ${Math.abs(a+b-c-d)} 分。`}}},
 {min:3,f:(lv,r)=>{const g=rand(8,20),w=rand(1,g-1);return {main:`球隊這季打了 ${g} 場比賽，贏了 ${w} 場，其餘都輸（沒有平手）。輸了幾場？`,ans:g-w,exp:`${g}−${w}＝${g-w} 場。`}}},
 {min:3,f:(lv,r)=>{const h=rand(2,4),ab=10;return {main:`${STORY_NAMES()}每 10 個打數大約打出 ${h} 支安打。照這樣，30 個打數大約會有幾支安打？`,ans:h*3,exp:`30 是 10 的 3 倍，安打也乘 3：${h}×3＝${h*3} 支。`}}},
 {min:4,f:(lv,r)=>{const runs=[0,0,0,0,0,0,0,0,0].map(()=>rand(0,3)),k=rand(5,8),sofar=runs.slice(0,k).reduce((a,b)=>a+b,0);return {main:`紅隊前 ${k} 局一共得了 ${sofar} 分。如果之後每局都得 2 分，打完 9 局一共幾分？`,ans:sofar+(9-k)*2,exp:`還有 ${9-k} 局，每局 2 分：${(9-k)*2}；合計 ${sofar}＋${(9-k)*2}＝${sofar+(9-k)*2} 分。`}}}
];
const _storyV30=storyQuestion;
storyQuestion=function(level,scoreMode=false){const pool=(scoreMode?SCORE_T:STORY_T).filter(t=>t.min<=level);const r=storyRange(level);for(let i=0;i<30;i++){const ti=rand(0,pool.length-1),out=pool[ti].f(level,r);if(!out||!Number.isFinite(out.ans)||out.ans<0)continue;const ans=out.ans;
  return {skill:scoreMode?'math-score':'math-story',prompt:scoreMode?'🏟️ 看懂比賽數字':'⚾ 生活與棒球的數學',main:out.main,answer:String(ans),choices:choicesForAnswer(ans,Math.min(level,3),out.max??Infinity),explain:out.exp,hint:'先找出題目要問什麼，再想要用加、減、乘還是除。',signature:(scoreMode?'sc-':'st-')+out.main,concept:(scoreMode?'sc':'st')+'-'+(scoreMode?SCORE_T:STORY_T).indexOf(pool[ti]),reason:level>=3}}
 return _storyV30(Math.min(level,3),scoreMode)};
Object.assign(THEME_COPY.space,{right:'🚀 答對了！探索成功！'});Object.assign(THEME_COPY.princess,{right:'✨ 答對了！你好棒！'});Object.assign(THEME_COPY.animals,{right:'🐾 答對了！小動物都為你拍手！'});Object.assign(THEME_COPY._default,{right:'✅ 答對了！做得好！'});
// --- 第 4 級：計算 ---
const _calcV30=calcQuestion;
calcQuestion=function(level){if(level<4)return _calcV30(level);const kind=rand(0,7);let main,ans,exp,max=Infinity;
 if(kind===0){const a=rand(1200,8999),b=rand(300,a-100);ans=a-b;main=`${a} − ${b} ＝ ?`;exp=`四位數減法，注意借位：${ans}。`}
 else if(kind===1){const a=rand(1200,6000),b=rand(800,3999);ans=a+b;main=`${a} ＋ ${b} ＝ ?`;exp=`四位數加法，注意進位：${ans}。`}
 else if(kind===2){const a=rand(12,49),b=rand(11,29);ans=a*b;main=`${a} × ${b} ＝ ?`;exp=`拆開算：${a}×${Math.floor(b/10)*10}＝${a*Math.floor(b/10)*10}，${a}×${b%10}＝${a*(b%10)}，相加得 ${ans}。`}
 else if(kind===3){const d=rand(4,9),q=rand(12,99),r=rand(1,d-1);ans=r;max=d-1;main=`${d*q+r} ÷ ${d} 的餘數是多少？`;exp=`${d*q+r}÷${d}＝${q} 餘 ${r}。`}
 else if(kind===4){const a=rand(2,9),b=rand(2,9),c=rand(10,60);ans=c+a*b*2;main=`${c} ＋ ${a} × ${b} × 2 ＝ ?`;exp=`先乘：${a}×${b}×2＝${a*b*2}，再加 ${c}：${ans}。`}
 else if(kind===5){const a=rand(20,90),b=rand(2,9),c=rand(2,9);ans=(a-b*c)>0?(a-b*c):null;if(ans===null)return calcQuestion(level);main=`${a} − ${b} × ${c} ＝ ?`;exp=`先乘 ${b}×${c}＝${b*c}，再減：${a}−${b*c}＝${ans}。`}
 else if(kind===6){const k=one([5,6,8,10,12]),a=rand(1,k-2),b=rand(1,k-1-a);ans=a+b;main=`${a}/${k} ＋ ${b}/${k} ＝ ?/${k}`;exp=`分母一樣，分子相加：${a}＋${b}＝${ans}，答案 ${ans}/${k}。`;max=k}
 else{const d=rand(4,9),q=rand(25,150);ans=q;main=`${d*q} ÷ ${d} ＝ ?`;exp=`${d*q}÷${d}＝${q}。`}
 return {skill:'math-calc',prompt:'🧮 菁英計算：一步一步算清楚',main,answer:String(ans),choices:choicesForAnswer(ans,3,max),explain:exp,signature:'c4-'+main,reason:true}};
// --- 第 4 級：6 人排序推理、數獨更多空格、誰說謊 ---
CN5.push('六');
const _orderV30=orderPuzzle;
orderPuzzle=function(level){if(level<4)return _orderV30(level);
 const n=6,S=one(ORDER_SCENES),names=shuffle(LINEUP_NAMES).slice(0,n),order=shuffle(names),pos=Object.fromEntries(order.map((x,i)=>[x,i])),all=permutations(names);
 const mk=()=>{const t=rand(0,5);let a=one(names),b=one(names.filter(x=>x!==a));
  if(t===0){const k=rand(0,n-1);return pos[a]===k?null:{type:'not',a,k,text:S.not(a,k),ok:p=>p.indexOf(a)!==k,key:'n'+a+k}}
  if(t===1){if(pos[a]>pos[b])[a,b]=[b,a];return {type:'before',a,b,text:S.before(a,b),ok:p=>p.indexOf(a)<p.indexOf(b),key:'b'+a+b}}
  if(t===2){const i=pos[a];if(i===n-1)return null;const nx=order[i+1];return {type:'next',a,b:nx,text:S.next(a,nx),ok:p=>p.indexOf(nx)===p.indexOf(a)+1,key:'x'+a}}
  if(t===3){const i=pos[a];if(i===0)return {type:'first',a,text:S.first(a),ok:p=>p[0]===a,key:'F'};if(i===n-1)return {type:'last',a,text:S.last(a),ok:p=>p[n-1]===a,key:'L'};return null}
  if(t===4){const i=pos[a];return i===0||i===n-1?null:{type:'mid',a,text:S.mid(a),ok:p=>{const j=p.indexOf(a);return j!==0&&j!==n-1},key:'m'+a}}
  const d=Math.abs(pos[a]-pos[b]);return d<2?null:{type:'gap',a,b,k:d-1,text:S.gap(a,b,d-1),ok:p=>Math.abs(p.indexOf(a)-p.indexOf(b))===d,key:'g'+[a,b].sort().join('')}};
 let clues=[],g=0;const fits=c=>all.filter(p=>c.every(x=>x.ok(p)));
 while(fits(clues).length>1&&g++<500){const c=mk();if(!c||clues.some(x=>x.key===c.key))continue;if(fits([...clues,c]).length<fits(clues).length)clues.push(c)}
 if(fits(clues).length!==1||clues.length>9)return null;
 for(let i=clues.length-1;i>=0;i--){const t=clues.filter((_,j)=>j!==i);if(fits(t).length===1)clues=t}
 const k=rand(0,n-1),ans=order[k];
 return {skill:'logic-order',prompt:`🕵️‍♂️ ${S.title}（6 人菁英版）：讀線索，排一排`,main:clues.map((c,i)=>`${i+1}. ${c.text}`).join('\n'),second:`${names.join('、')}，${S.intro(n)}${S.ask(k)}`,answer:ans,choices:shuffle([ans,...shuffle(names.filter(x=>x!==ans)).slice(0,3)]),explain:`正確的順序：${order.map((x,i)=>`${S.unit(i)} ${x}`).join(' → ')}。`,hint:'畫 6 個格子，把確定的人先放進去，再用剩下的線索一個一個試。',signature:'ord6-'+S.id+order.join('')+clues.map(c=>c.key).join(''),concept:'ord-'+S.id,reason:true,__check:{kind:'order',n,names,clues:clues.map(({type,a,b,k})=>({type,a,b,k})),askPos:k}}};
const _sudokuV30=sudokuQuestion;sudokuQuestion=function(lv){const q=_sudokuV30(Math.min(lv,3));if(lv<4)return q;for(let i=0;i<6;i++){const q2=_sudokuV30(3);if((q2.main.match(/□/g)||[]).length>(q.main.match(/□/g)||[]).length)return {...q2,prompt:'🔢 菁英數獨：空格更多，1～4 在每排、每列、每個田字格都只出現一次。？ 要填多少？'}}return q};


// ===== v31：科學題庫擴充 =====
SCIENCE_BANK.body.push(
 {l:1,q:'我們用什麼器官聞到烤香腸的香味？',a:'鼻子',o:['鼻子','耳朵','手肘','膝蓋'],e:'鼻子裡有感覺氣味的細胞，能聞到香味。'},
 {l:1,q:'打球前要先上廁所、喝點水，再做什麼最好？',a:'暖身運動',o:['暖身運動','直接全力衝刺','吃一大碗麵','躺下睡覺'],e:'先暖身讓身體準備好，再開始練習比較不會受傷。'},
 {l:1,q:'手指被擦傷流了一點血，最先應該做什麼？',a:'用乾淨的水沖洗並告訴大人',o:['用乾淨的水沖洗並告訴大人','用嘴巴吹一吹就好','抹上泥土','假裝沒事繼續玩'],e:'先告訴大人，用乾淨的流動水清潔小擦傷，再由大人評估並以乾淨敷料覆蓋；若持續流血或傷口較深，應請大人協助就醫。'},
 {l:1,q:'打球回家後，為什麼要先洗手？',a:'把手上的細菌洗掉',o:['把手上的細菌洗掉','讓手變大','讓手變冷','讓球變乾淨'],e:'手會碰到很多東西，洗手可以減少細菌跑進嘴巴裡。'},
 {l:1,q:'一般短時間活動後，以下哪種飲料較適合補充水分？',a:'白開水',o:['白開水','汽水','咖啡','可樂'],e:'一般短時間活動後通常可喝白開水；長時間大量流汗時，則請大人依活動情況協助補充水分和電解質。'},
 {l:1,q:'8 歲小朋友每天通常需要多少睡眠？',a:'規律作息，每天睡約9～12小時',o:['規律作息，每天睡約9～12小時','半夜 12 點再睡','不用睡覺','白天睡、晚上玩'],e:'6～12歲兒童通常建議每天睡9～12小時，並維持規律的就寢和起床時間。'},
 {l:1,q:'看電視或平板太久，眼睛會怎樣？',a:'容易疲勞',o:['容易疲勞','變得更亮','長出睫毛','變大'],e:'眼睛一直看近的東西會疲勞，記得每 30 分鐘休息、看看遠方。'},
 {l:1,q:'哪個身體部位幫助我們站穩、跑步？',a:'腳和腿',o:['腳和腿','耳朵','頭髮','指甲'],e:'腳和腿的骨頭、肌肉撐起身體，讓我們能跑能跳。'},
 {l:2,q:'人的身體裡，哪個部位負責思考、指揮身體動作？',a:'大腦',o:['大腦','胃','肺','腳底'],e:'大腦接收眼睛、耳朵的訊息，再指揮肌肉做出動作。'},
 {l:2,q:'吃下去的食物，主要在哪裡被消化？',a:'胃和腸子',o:['胃和腸子','肺','心臟','骨頭'],e:'食物經過胃和腸子被分解，營養再被身體吸收。'},
 {l:2,q:'肺的主要工作是什麼？',a:'吸進氧氣、呼出二氧化碳',o:['吸進氧氣、呼出二氧化碳','消化食物','打敗細菌','讓骨頭變硬'],e:'我們呼吸時，肺把氧氣送進血液，再把二氧化碳排出去。'},
 {l:2,q:'輕摸手腕靠拇指的一側，感覺到一跳一跳的是什麼？',a:'脈搏',o:['脈搏','骨頭在動','肚子餓','肌肉抽筋'],e:'心臟收縮推動血液，會使動脈有規律地搏動，這就是脈搏。'},
 {l:2,q:'小腿突然抽筋時，比較好的處理方式是？',a:'停下來，慢慢伸展小腿',o:['停下來，慢慢伸展小腿','繼續用力跑','用力捶打','立刻跳進冷水'],e:'抽筋時先停下來，輕輕把腳尖往身體方向拉，慢慢伸展。'},
 {l:2,q:'為什麼打擊時要戴頭盔、捕手要戴護具？',a:'保護重要部位，減少受傷',o:['保護重要部位，減少受傷','讓自己變重','跑得比較快','讓球飛更遠'],e:'球速很快，護具能吸收撞擊力，保護頭部和身體。'},
 {l:2,q:'牙齒外面最硬的那層叫什麼？',a:'琺瑯質',o:['琺瑯質','肌肉','頭髮','指紋'],e:'琺瑯質是人體最硬的部分，但吃太多糖又不刷牙會被蛀壞。'},
 {l:2,q:'運動時體溫升高，身體用什麼方法降溫？',a:'流汗',o:['流汗','長高','打噴嚏','眨眼睛'],e:'汗水蒸發會帶走熱量，讓身體降溫。'},
 {l:3,q:'骨頭和骨頭連接、可以彎曲的地方叫什麼？',a:'關節',o:['關節','血管','神經','脂肪'],e:'手肘、膝蓋、肩膀都是關節，讓身體可以彎曲、轉動。'},
 {l:3,q:'投手的手肘和肩膀為什麼要好好保護？',a:'關節反覆用力容易受傷',o:['關節反覆用力容易受傷','因為會長高','因為怕冷','因為比較好看'],e:'投球時手肘和肩膀承受很大的力量，過度使用容易受傷。'},
 {l:3,q:'哪一種食物主要提供身體活動需要的「能量」？',a:'飯、麵、麵包這類澱粉',o:['飯、麵、麵包這類澱粉','白開水','鹽巴','維他命丸'],e:'澱粉（醣類）是身體最主要的能量來源。'},
 {l:3,q:'吃蔬菜水果主要可以補充什麼？',a:'維生素和纖維',o:['維生素和纖維','大量脂肪','咖啡因','塑膠'],e:'蔬果有維生素、礦物質和纖維，幫助身體正常運作、排便順暢。'},
 {l:3,q:'感冒時為什麼要多休息、多喝水？',a:'幫助身體對抗病毒、恢復體力',o:['幫助身體對抗病毒、恢復體力','讓病毒長得更快','讓肚子變大','因為不能說話'],e:'休息和補充水分能讓身體的免疫系統更好地對抗病毒。'},
 {l:3,q:'從暗的地方走到大太陽下，瞳孔會怎樣？',a:'變小',o:['變小','變大','不變','消失'],e:'光線很亮時瞳孔縮小，減少進入眼睛的光，保護眼睛。'},
 {l:3,q:'被球砸到腫起來，剛開始最常用的處理是？',a:'冰敷並休息，請大人看看',o:['冰敷並休息，請大人看看','用力按摩','用熱水燙','繼續比賽不管它'],e:'先停止活動並告訴大人。若需要冰敷，應由大人以毛巾包住冰袋、短時間使用，不能直接貼皮膚；疼痛劇烈或不能活動時要就醫。'},
 {l:3,q:'身高、體重會長大，主要和下面哪件事最有關係？',a:'營養、睡眠和運動',o:['營養、睡眠和運動','玩手機時間','頭髮長度','衣服顏色'],e:'均衡飲食、充足睡眠和規律運動，都是成長的重要條件。'},
 {l:4,q:'血液裡負責運送氧氣的是哪一種細胞？',a:'紅血球',o:['紅血球','白血球','神經細胞','皮膚細胞'],e:'紅血球含有血紅素，能帶著氧氣送到全身。'},
 {l:4,q:'白血球的主要工作是什麼？',a:'對抗細菌和病毒',o:['對抗細菌和病毒','運送氧氣','消化食物','長出頭髮'],e:'白血球是身體的「防衛隊」，會攻擊入侵的病菌。'},
 {l:4,q:'打擊時看到球就揮棒，訊息的傳遞順序是？',a:'眼睛 → 大腦 → 肌肉',o:['眼睛 → 大腦 → 肌肉','肌肉 → 眼睛 → 大腦','大腦 → 腳 → 眼睛','耳朵 → 胃 → 手'],e:'眼睛看到球，神經把訊息傳到大腦，大腦再指揮手臂肌肉揮棒。'},
 {l:4,q:'長時間激烈運動、又流很多汗，除了水之外身體也會流失什麼？',a:'鹽分（電解質）',o:['鹽分（電解質）','骨頭','頭髮','視力'],e:'汗水裡有鹽分，長時間大量流汗時要適當補充電解質。'},
 {l:4,q:'為什麼小朋友投球要遵守教練安排的球數與休息時間？',a:'手臂還在發育，過度使用容易受傷',o:['手臂還在發育，過度使用容易受傷','因為球會變小','因為會變矮','因為太容易三振別人'],e:'成長中的手臂仍在發育，過度投球可能傷害骨骼、肌肉與關節。應依年齡與專業指導安排球數和休息，有疼痛就停止並告訴大人。'},
 {l:4,q:'人體大約有多少比例是水？',a:'大約一半以上',o:['大約一半以上','不到一成','完全沒有','百分之百'],e:'人體大約 50～70% 是水，所以補充水分很重要。'}
);
SCIENCE_BANK.force.push(
 {l:1,q:'把球放在斜坡上，球會怎樣？',a:'往下滾',o:['往下滾','往上滾','停在原地不會動','飛到天上'],e:'地心引力把球往下拉，所以球會往低的地方滾。'},
 {l:1,q:'用力踢球和輕輕踢球，哪一個球滾比較遠？',a:'用力踢',o:['用力踢','輕輕踢','一樣遠','都不會動'],e:'給的力越大，球的速度越快，通常滾得越遠。'},
 {l:1,q:'磁鐵可以吸住下面哪一個？',a:'鐵製的迴紋針',o:['鐵製的迴紋針','木頭積木','塑膠球','紙張'],e:'磁鐵會吸鐵、鎳等金屬，不會吸木頭、塑膠和紙。'},
 {l:1,q:'在冰上跑步為什麼容易滑倒？',a:'冰很光滑，摩擦力很小',o:['冰很光滑，摩擦力很小','冰太熱','冰太黏','冰會動'],e:'光滑的表面摩擦力小，腳抓不住地面，就容易滑倒。'},
 {l:1,q:'盪鞦韆時，誰把鞦韆往下拉回來？',a:'地心引力',o:['地心引力','風','磁鐵','聲音'],e:'鞦韆盪高之後，地心引力會把它往下拉回來。'},
 {l:1,q:'球鞋底下為什麼有凹凸的花紋？',a:'增加摩擦力，比較不會滑倒',o:['增加摩擦力，比較不會滑倒','讓鞋子變輕','讓鞋子好看而已','讓鞋子變熱'],e:'凹凸的鞋底可以抓住地面，增加摩擦力。'},
 {l:1,q:'把氣球吹大後放開不綁，氣球會怎樣？',a:'一邊噴氣一邊亂飛',o:['一邊噴氣一邊亂飛','停在空中不動','變成石頭','直接掉到地上不動'],e:'空氣往一邊噴出，氣球就被推往相反的方向。'},
 {l:1,q:'推門的時候，推哪裡最省力？',a:'離門軸最遠的地方',o:['離門軸最遠的地方','最靠近門軸的地方','門的正中間上方','推哪裡都一樣'],e:'離轉軸越遠，轉動需要的力越小，所以門把裝在離門軸遠的那邊。'},
 {l:2,q:'兩塊磁鐵，同樣的極（N 對 N）靠近時會怎樣？',a:'互相排斥',o:['互相排斥','互相吸引','沒有反應','變成一塊'],e:'同極相斥、異極相吸。'},
 {l:2,q:'球棒以相同角速度轉動時，擊球處離轉軸較遠，線速度會怎樣？',a:'線速度較大',o:['線速度較大','球棒變輕了','球變小了','手變長了'],e:'在角速度相同時，離轉軸越遠，線速度越大。但改變握棒位置也會影響揮棒能力，不能直接推論每個人握尾端就一定打得更有力。'},
 {l:2,q:'籃球從同樣高度落到木頭地板和沙子上，哪裡彈得比較高？',a:'木頭地板',o:['木頭地板','沙子','一樣高','都不會彈'],e:'沙子會吸收球的能量，硬的地板讓球彈得比較高。'},
 {l:2,q:'同樣大小的鐵球和塑膠球，從同樣高度放手（不考慮空氣），哪個先落地？',a:'幾乎同時落地',o:['幾乎同時落地','鐵球一定先落地很多','塑膠球先落地','都不會落地'],e:'在同一地點、忽略空氣阻力，且從相同高度同時由靜止放手時，兩球的重力加速度相同，會同時落地；有空氣時則還要考慮阻力。'},
 {l:2,q:'溜滑梯時，穿褲子和墊著塑膠墊，哪個滑得比較快？',a:'墊著光滑的塑膠墊',o:['墊著光滑的塑膠墊','穿粗糙的褲子','一樣快','都滑不動'],e:'表面越光滑，摩擦力越小，滑得越快。'},
 {l:2,q:'拉長橡皮筋再放開，哪一種力會讓橡皮筋縮回？',a:'橡皮筋的彈力',o:['橡皮筋的彈力','磁力','電力','光'],e:'橡皮筋被拉長時儲存彈性位能；放開後，彈力使它縮回，位能可轉成動能。力不是被儲存的能量。'},
 {l:2,q:'用吸管喝飲料，飲料是被什麼推上來的？',a:'空氣的壓力',o:['空氣的壓力','磁力','地心引力往上拉','聲音'],e:'吸走吸管裡的空氣後，外面的空氣壓力把飲料推進吸管。'},
 {l:2,q:'使用輪圈煞車的腳踏車，煞車時輪子為什麼會慢下來？',a:'煞車皮和輪圈摩擦',o:['煞車皮和輪圈摩擦','輪子沒電了','地心引力變大','風太大'],e:'輪圈煞車的煞車皮壓住輪圈，摩擦會讓輪子減速；其他種類如碟煞，則是煞車片與碟盤接觸。'},
 {l:3,q:'投手投出的快速球，大約要多久才到本壘？',a:'不到 1 秒',o:['不到 1 秒','大約 5 秒','大約 10 秒','大約 1 分鐘'],e:'職業投手的快速球從投手丘到本壘大約只要 0.4～0.5 秒，打者要非常快地判斷。'},
 {l:3,q:'用槓桿（像蹺蹺板）抬重物，支點靠近重物會怎樣？',a:'比較省力',o:['比較省力','比較費力','完全抬不動','一樣'],e:'支點越靠近重物，施力的那一邊越長，越省力。'},
 {l:3,q:'為什麼跑壘時要繞著跑，而不是在壘包前急停再轉直角？',a:'速度轉彎時需要向內的力，弧線比較不會減速',o:['速度轉彎時需要向內的力，弧線比較不會減速','因為規則規定一定要畫圓','因為壘包會動','因為比較好看'],e:'要改變跑的方向需要力，用弧線轉彎比急停再轉更能保持速度。'},
 {l:3,q:'打出的高飛球，飛到最高點時速度會怎樣？',a:'往上的速度變成零，然後開始往下',o:['往上的速度變成零，然後開始往下','變得最快','突然停在空中很久','往上的速度越來越快'],e:'地心引力一直讓球往上的速度變慢，到最高點時往上速度是零，接著開始落下。'},
 {l:3,q:'聲音在下面哪一種物質中傳得最快？',a:'鐵',o:['鐵','空氣','真空','棉花'],e:'在這些選項中，聲音沿鐵傳播的速度通常比在空氣中快。不同材料仍有差異，不能只看固體或氣體就一概而論；真空中無法傳聲。'},
 {l:3,q:'把耳朵貼在桌上，聽朋友敲桌子的聲音會怎樣？',a:'聽得比較清楚',o:['聽得比較清楚','完全聽不到','聲音變成光','聲音變慢很多'],e:'聲音在木頭（固體）中傳得比空氣好，所以聽得更清楚。'},
 {l:3,q:'同樣力量揮棒，打到球棒的甜蜜點和打到手把附近，哪個手比較麻？',a:'打到手把附近',o:['打到手把附近','打到甜蜜點','一樣麻','都不會麻'],e:'打到甜蜜點時球棒振動最小；打偏時振動傳到手上，所以手會麻。'},
 {l:3,q:'為什麼盜壘時常常要滑壘？',a:'減少被觸殺的範圍，也能在壘包停住',o:['減少被觸殺的範圍，也能在壘包停住','因為滑壘比跑步快很多','因為鞋子太滑','因為規則一定要滑'],e:'滑壘讓身體貼地、靠摩擦力停在壘包上，不會衝過頭。'},
 {l:4,q:'球在太空中飛行，假設受到的合外力為零，它的運動會怎樣？',a:'一直以同樣速度往前飛，直到被其他力改變',o:['一直以同樣速度往前飛，直到被其他力改變','馬上停下來','慢慢變慢然後停','掉回地面'],e:'合外力為零時，物體保持等速直線運動，這是慣性。真空只表示沒有空氣，仍可能有重力；沒有空氣不等於沒有外力。'},
 {l:4,q:'坐車時突然煞車，身體會往前傾，這是因為？',a:'慣性：身體想保持原來的運動',o:['慣性：身體想保持原來的運動','磁力把人往前吸','車子變重','風把人吹向前'],e:'車子停了，但身體還想往前動，所以會往前傾，要繫好安全帶。'},
 {l:4,q:'有些中空鋁製球棒擊球時會有「彈床效應」，主要指什麼？',a:'管壁受撞擊變形再回彈，將部分能量還給球',o:['管壁受撞擊變形再回彈，將部分能量還給球','鋁棒比較重很多','球碰到鋁會變輕','鋁棒有磁力'],e:'有些中空球棒的管壁在撞擊時變形再回彈，稱為彈床效應。實際擊球距離還受設計、揮棒速度及擊中位置影響，不能說所有鋁棒一定比木棒打得遠。'},
 {l:4,q:'投手讓球往前旋轉（上旋），球會比較快落下還是比較慢落下？',a:'比較快落下',o:['比較快落下','比較慢落下','完全不受影響','會往上飛'],e:'旋轉讓周圍空氣產生不同的壓力；上旋會讓球受到往下的力，掉得比較快。'},
 {l:4,q:'能量會「消失」嗎？例如球滾著滾著停下來了。',a:'不會消失，變成熱和聲音等其他形式',o:['不會消失，變成熱和聲音等其他形式','會完全消失','會變成新的球','會跑到月亮上'],e:'能量守恆：球的動能透過摩擦轉成熱能和聲音，總量不變。'},
 {l:4,q:'想用最少的力氣把重箱子抬上卡車，用哪個方法比較好？',a:'用一塊長斜板慢慢推上去',o:['用一塊長斜板慢慢推上去','直接垂直抬上去','把箱子丟上去','在箱子上綁氣球'],e:'斜面讓距離變長、需要的力變小，所以比較省力。'}
);
SCIENCE_BANK.nature.push(
 {l:1,q:'下雨過後，天空有時會出現七種顏色的什麼？',a:'彩虹',o:['彩虹','流星','極光','月亮'],e:'太陽光照到空中的小水滴，分出不同顏色，就是彩虹。'},
 {l:1,q:'青蛙小時候叫什麼？',a:'蝌蚪',o:['蝌蚪','毛毛蟲','小雞','小魚乾'],e:'青蛙從蛋孵出蝌蚪，長出腳、尾巴消失後才變成青蛙。'},
 {l:1,q:'蝴蝶小時候是什麼樣子？',a:'毛毛蟲',o:['毛毛蟲','蝌蚪','小鳥','小蛇'],e:'蝴蝶的一生：卵 → 幼蟲（毛毛蟲）→ 蛹 → 成蟲。'},
 {l:1,q:'台灣哪個季節常有颱風？',a:'夏天和秋天',o:['夏天和秋天','只有冬天','只有春天','從來沒有'],e:'台灣的颱風大多出現在夏季到秋季。'},
 {l:1,q:'晚上天空中，月亮的形狀每天都一樣嗎？',a:'不一樣，會慢慢改變',o:['不一樣，會慢慢改變','每天都一樣圓','每天都是彎彎的','月亮只有白天才有'],e:'月亮大約一個月會從新月變成滿月再變回新月。'},
 {l:1,q:'植物的哪個部分會從土裡吸水？',a:'根',o:['根','花','果實','葉子尖端'],e:'一般陸生植物的根能吸收土壤中的水分與礦物質，也幫植物固定；葉片可透過光合作用製造糖類等養分。'},
 {l:1,q:'冬天把手放進冷水裡，手會覺得？',a:'冰冰冷冷的',o:['冰冰冷冷的','很燙','完全沒有感覺','很黏'],e:'皮膚能感覺溫度，冷水會讓手覺得冷。'},
 {l:1,q:'哪一種動物是用鰓在水裡呼吸？',a:'魚',o:['魚','狗','鳥','貓'],e:'魚用鰓從水中取得氧氣。'},
 {l:2,q:'把一杯熱水放在桌上，過一段時間會怎樣？',a:'慢慢變涼',o:['慢慢變涼','越來越燙','變成冰塊','完全不變'],e:'熱會從溫度高的地方傳到溫度低的地方，熱水會慢慢冷下來。'},
 {l:2,q:'為什麼樹葉大多是綠色的？',a:'葉子裡有葉綠素',o:['葉子裡有葉綠素','被畫上綠色','因為吸了綠色的水','因為很冷'],e:'葉綠素是綠色的，它能吸收陽光幫植物製造養分。'},
 {l:2,q:'晴天時，一天之中什麼時候影子最短？',a:'中午太陽最高的時候',o:['中午太陽最高的時候','清晨太陽剛出來','傍晚太陽快下山','每個時間都一樣長'],e:'太陽越高，影子越短；中午前後太陽最高。'},
 {l:2,q:'蜜蜂在花朵之間飛來飛去，對植物有什麼幫助？',a:'幫忙傳播花粉',o:['幫忙傳播花粉','把花吃掉','讓花變色','讓花長刺'],e:'蜜蜂採蜜時身上沾了花粉，帶到別的花上，幫助植物結果實。'},
 {l:2,q:'把冰塊放在太陽下，冰塊會變成什麼？',a:'水',o:['水','石頭','沙子','煙'],e:'冰受熱會融化成液態的水。'},
 {l:2,q:'晚上看到的星星，大部分其實是什麼？',a:'很遠的、像太陽一樣會發光的恆星',o:['很遠的、像太陽一樣會發光的恆星','天上的燈泡','月亮的碎片','飛機'],e:'夜空中多數星星是距離很遠的恆星，因為太遠才看起來很小。'},
 {l:2,q:'為什麼下過大雨後，河水常常變得混濁？',a:'雨水把泥沙沖進河裡',o:['雨水把泥沙沖進河裡','河水變成牛奶','魚把水弄髒','太陽把水染色'],e:'大雨沖刷地面，泥沙跟著流進河裡，水就變混濁了。'},
 {l:2,q:'台灣的冬天，北部和南部哪邊通常比較溫暖？',a:'南部',o:['南部','北部','一樣冷','台灣沒有冬天'],e:'南部比較接近赤道，冬天也受東北季風影響較小，通常比較溫暖。'},
 {l:3,q:'地球繞太陽一圈大約要多久？',a:'一年',o:['一年','一天','一個月','一小時'],e:'地球公轉一圈大約 365 天，就是一年。'},
 {l:3,q:'月亮繞地球一圈大約多久？',a:'大約一個月',o:['大約一個月','一天','一年','一小時'],e:'月球相對遠方恆星繞地球一圈約27.3天；從一次新月到下次新月的月相週期約29.5天。兩種週期的參考方向不同，不能混為一談。'},
 {l:3,q:'為什麼會有春夏秋冬四季？',a:'地球的自轉軸是傾斜的，繞太陽時陽光照射角度改變',o:['地球的自轉軸是傾斜的，繞太陽時陽光照射角度改變','地球離太陽時遠時近得很多','太陽會關掉一陣子','月亮擋住太陽'],e:'地軸傾斜，讓一年中不同時間陽光照射的角度和時間長短不同，產生季節。'},
 {l:3,q:'食物鏈「草 → 兔子 → 老鷹」中，兔子吃什麼？',a:'草',o:['草','老鷹','石頭','陽光直接'],e:'食物鏈表示誰吃誰：兔子吃草，老鷹吃兔子。'},
 {l:3,q:'海水中的鹽分，一個重要來源是什麼？',a:'河流把陸地上的礦物鹽帶進海裡，長久累積',o:['河流把陸地上的礦物鹽帶進海裡，長久累積','有人倒鹽巴進去','魚的眼淚','太陽把海曬鹹'],e:'河流會把岩石風化、溶解產生的離子帶進海洋，海底也有物質交換。水蒸發時大多不帶走鹽分；鹽分也有移出的途徑，不能認為海水會無限變鹹。'},
 {l:3,q:'地震時在室內，最好的做法是？',a:'趴下、掩護、穩住',o:['趴下、掩護、穩住','馬上搭電梯下樓','跑到窗戶旁邊','站在吊燈下面'],e:'地震時要「趴下、掩護、穩住」，遠離窗戶與會掉落的東西，不要搭電梯。'},
 {l:3,q:'植物利用陽光、水和二氧化碳製造養分，同時會放出什麼？',a:'氧氣',o:['氧氣','二氧化碳','煙','鹽'],e:'這叫光合作用，植物會釋放氧氣，讓動物可以呼吸。'},
 {l:3,q:'為什麼要做資源回收？',a:'減少垃圾、讓資源可以再利用',o:['減少垃圾、讓資源可以再利用','讓垃圾變多','讓垃圾車比較累','因為好玩而已'],e:'回收紙、塑膠、金屬等可以再製成新東西，節省資源也減少污染。'},
 {l:4,q:'太陽系中，離太陽最近的行星是哪一顆？',a:'水星',o:['水星','地球','火星','木星'],e:'行星由近到遠：水星、金星、地球、火星、木星、土星、天王星、海王星。'},
 {l:4,q:'太陽系中最大的行星是哪一顆？',a:'木星',o:['木星','地球','水星','火星'],e:'木星是太陽系最大的行星，體積大約是地球的一千多倍。'},
 {l:4,q:'月亮上為什麼有很多坑洞？',a:'被隕石撞擊，而且沒有空氣和風雨抹平',o:['被隕石撞擊，而且沒有空氣和風雨抹平','太空人挖的','月亮上有很多兔子','是月亮的影子'],e:'月球幾乎沒有大氣，隕石撞出的坑洞很難被侵蝕，所以保留下來。'},
 {l:4,q:'溫室效應增強，主要和大氣中哪種氣體增加有關？',a:'二氧化碳',o:['二氧化碳','氧氣','氮氣','氦氣'],e:'燃燒煤、石油等會增加二氧化碳，讓地球保留更多熱，造成暖化。'},
 {l:4,q:'化石通常是在哪一種岩石裡發現的？',a:'沉積岩',o:['沉積岩','火成岩','金屬','冰塊'],e:'生物遺骸被泥沙一層層埋起來，經過很長時間變成沉積岩裡的化石。'},
 {l:4,q:'水循環中，水從海洋回到陸地主要靠什麼？',a:'蒸發成水蒸氣，形成雲，再降雨',o:['蒸發成水蒸氣，形成雲，再降雨','船把水運回去','魚把水帶上岸','地心引力把海水往上拉'],e:'海水蒸發 → 凝結成雲 → 降雨或降雪 → 流回河川與海洋，這就是水循環。'}
);
SCIENCE_BANK.lab.push(
 {l:1,q:'想知道哪一種球最輕，可以用什麼工具？',a:'秤（磅秤）',o:['秤（磅秤）','碼錶','溫度計','放大鏡'],e:'秤可以量重量；碼錶量時間、溫度計量溫度、放大鏡看細節。'},
 {l:1,q:'想仔細看樹葉上的紋路，用什麼工具最好？',a:'放大鏡',o:['放大鏡','尺','秤','碼錶'],e:'放大鏡能把小東西看得更大、更清楚。'},
 {l:1,q:'做實驗時，下面哪個行為最安全？',a:'聽大人說明，戴好需要的保護',o:['聽大人說明，戴好需要的保護','亂聞、亂嚐不知道的東西','自己偷偷點火','邊跑邊做'],e:'做實驗要先了解步驟、注意安全，不認識的東西不能亂摸亂嚐。'},
 {l:1,q:'想知道今天的氣溫，要用什麼工具？',a:'溫度計',o:['溫度計','尺','秤','指南針'],e:'溫度計用來量冷熱。'},
 {l:1,q:'想量球棒有多長，要用什麼？',a:'捲尺或尺',o:['捲尺或尺','溫度計','秤','時鐘'],e:'尺或捲尺用來量長度。'},
 {l:1,q:'記錄實驗結果時，下面哪個方法最清楚？',a:'用表格寫下每一次的數字',o:['用表格寫下每一次的數字','只用腦袋記','隨便寫在手上','不用記錄'],e:'表格能清楚整理資料，方便之後比較。'},
 {l:2,q:'小紀種兩盆豆子，一盆每天澆水，一盆不澆水，其他都一樣。他想知道什麼？',a:'水對植物生長的影響',o:['水對植物生長的影響','陽光對植物的影響','土的顏色','花盆的價錢'],e:'只有「澆不澆水」不同，所以他在研究水的影響。'},
 {l:2,q:'想比較三種球誰彈得最高，每種球都要從哪裡放下？',a:'同一個高度',o:['同一個高度','不同高度','用力往下丟','隨便丟'],e:'放下的高度要一樣，比較才公平。'},
 {l:2,q:'測量跑 50 公尺的時間，為什麼最好量 3 次再取平均？',a:'減少隨機誤差對平均結果的影響',o:['減少隨機誤差對平均結果的影響','讓數字變大','因為量一次會壞掉','比較浪費時間'],e:'相同條件下多次測量取平均，有助減少隨機誤差的影響；工具偏差或操作方式一直有錯，不能靠平均消除。'},
 {l:2,q:'實驗中「故意改變的條件」叫做什麼？',a:'操縱變因',o:['操縱變因','控制變因','結果','結論'],e:'故意改變的是操縱變因；保持不變的是控制變因；觀察到的是結果。'},
 {l:2,q:'想知道「溫度會不會影響糖溶解的速度」，要改變什麼？',a:'水的溫度',o:['水的溫度','糖的種類和水的溫度一起換','杯子的顏色','攪拌的人'],e:'只改變水溫，其他（糖量、水量、攪拌方式）都一樣。'},
 {l:2,q:'觀察天氣一個星期，最好的記錄方式是？',a:'每天同一個時間記錄天氣和氣溫',o:['每天同一個時間記錄天氣和氣溫','想到才記','只記星期日','只記下雨的日子'],e:'固定時間記錄，資料才能互相比較。'},
 {l:3,q:'畫圖表時，想看出「一週的氣溫怎麼變化」，用什麼圖最好？',a:'折線圖',o:['折線圖','圓餅圖','地圖','照片'],e:'折線圖能清楚看出數字隨時間上升或下降。'},
 {l:3,q:'想比較「全班最喜歡的運動各占多少」，用什麼圖最好？',a:'圓餅圖或長條圖',o:['圓餅圖或長條圖','折線圖','地圖','流程圖'],e:'圓餅圖看比例、長條圖比大小，都適合比較各項目的多寡。'},
 {l:3,q:'大顏說：「有戴手環的那天我都打得比較好。」想進一步檢查這個說法，應該怎麼做？',a:'很多場比賽中比較戴和不戴的結果',o:['很多場比賽中比較戴和不戴的結果','只看一場比賽','問朋友覺得怎樣','直接相信'],e:'需要多次且盡量公平的比較，並考慮對手、練習和身體狀態等因素；只看戴手環那幾場，不能證明手環有效。'},
 {l:3,q:'實驗結果和預測不同時，最正確的態度是？',a:'接受結果，找出可能的原因再驗證',o:['接受結果，找出可能的原因再驗證','把結果改成預測的樣子','說實驗壞掉了不算','再也不做實驗'],e:'科學是根據證據修正想法，意外的結果常常帶來新發現。'},
 {l:3,q:'「猜想：用力越大，球飛越遠。」這在科學方法中叫做什麼？',a:'假設',o:['假設','結論','工具','記錄表'],e:'實驗前提出、等著被驗證的猜想叫做假設。'},
 {l:3,q:'下面哪一個是「觀察」，不是「推論」？',a:'球從桌上掉到地上',o:['球從桌上掉到地上','球掉下來是因為它想回家','球一定是故意的','球很傷心'],e:'觀察是用感官看到、聽到的事實；推論是根據觀察猜原因。'},
 {l:4,q:'想研究「球棒重量是否影響揮棒速度」，下列哪個應該保持不變？',a:'同一位打者、同樣的揮棒方式',o:['同一位打者、同樣的揮棒方式','球棒的重量','換不同打者每次揮','有時用力有時不用力'],e:'球棒重量是要改變的條件，其他像打者、揮棒方式都要控制不變。'},
 {l:4,q:'5 次測量結果是 12、13、12、30、13 秒，30 秒最可能是什麼？',a:'可能出錯的異常值，要檢查原因',o:['可能出錯的異常值，要檢查原因','最正確的數字','平均值','一定要刪掉其他數字'],e:'和其他數據差很多的值叫異常值，要檢查是否測量失誤，而不是隨便刪改。'},
 {l:4,q:'為什麼科學家要把實驗方法寫得很詳細？',a:'讓別人可以重做，驗證結果',o:['讓別人可以重做，驗證結果','讓文章比較長','怕自己忘記吃飯','讓別人看不懂'],e:'能被別人重複做出相同結果，科學發現才可信。'},
 {l:4,q:'溫度計讀數是25.4°C，下面哪個描述符合讀數？',a:'大約 25 度多一點',o:['大約 25 度多一點','剛好 30 度','大約 2 度','25 公尺'],e:'25.4 度介於 25 和 26 之間，比較接近 25。'},
 {l:4,q:'「每天喝牛奶的同學比較高」，這能證明牛奶讓人長高嗎？',a:'不能直接證明，可能還有其他原因',o:['不能直接證明，可能還有其他原因','可以，一定是牛奶','可以，喝越多越高','牛奶會讓人變矮'],e:'兩件事一起出現不代表一個造成另一個，可能還有飲食、睡眠、遺傳等因素。'},
 {l:4,q:'設計實驗時，「對照組」的作用是什麼？',a:'作為比較的標準',o:['作為比較的標準','讓實驗更好玩','可以不用記錄','增加花費'],e:'對照組作為比較基準，與實驗組的重要差別應是研究的處理條件；其他條件盡量相同，才能評估該處理的影響。'}
);

const ALPHABET=[{"upper":"A","lower":"a","word":"apple","meaning":"蘋果","icon":"🍎","nameIpa":"/eɪ/","soundIpa":"/æ/"},{"upper":"B","lower":"b","word":"ball","meaning":"球","icon":"⚾","nameIpa":"/biː/","soundIpa":"/b/"},{"upper":"C","lower":"c","word":"cat","meaning":"貓","icon":"🐈","nameIpa":"/siː/","soundIpa":"/k/"},{"upper":"D","lower":"d","word":"dog","meaning":"狗","icon":"🐕","nameIpa":"/diː/","soundIpa":"/d/"},{"upper":"E","lower":"e","word":"egg","meaning":"蛋","icon":"🥚","nameIpa":"/iː/","soundIpa":"/ɛ/"},{"upper":"F","lower":"f","word":"fish","meaning":"魚","icon":"🐟","nameIpa":"/ɛf/","soundIpa":"/f/"},{"upper":"G","lower":"g","word":"goat","meaning":"山羊","icon":"🐐","nameIpa":"/dʒiː/","soundIpa":"/ɡ/"},{"upper":"H","lower":"h","word":"hat","meaning":"帽子","icon":"🧢","nameIpa":"/eɪtʃ/","soundIpa":"/h/"},{"upper":"I","lower":"i","word":"igloo","meaning":"冰屋","icon":"🧊","nameIpa":"/aɪ/","soundIpa":"/ɪ/"},{"upper":"J","lower":"j","word":"jump","meaning":"跳躍","icon":"🤸","nameIpa":"/dʒeɪ/","soundIpa":"/dʒ/"},{"upper":"K","lower":"k","word":"kite","meaning":"風箏","icon":"🪁","nameIpa":"/keɪ/","soundIpa":"/k/"},{"upper":"L","lower":"l","word":"lion","meaning":"獅子","icon":"🦁","nameIpa":"/ɛl/","soundIpa":"/l/"},{"upper":"M","lower":"m","word":"moon","meaning":"月亮","icon":"🌙","nameIpa":"/ɛm/","soundIpa":"/m/"},{"upper":"N","lower":"n","word":"nose","meaning":"鼻子","icon":"👃","nameIpa":"/ɛn/","soundIpa":"/n/"},{"upper":"O","lower":"o","word":"octopus","meaning":"章魚","icon":"🐙","nameIpa":"/oʊ/","soundIpa":"/ɑ/"},{"upper":"P","lower":"p","word":"pig","meaning":"豬","icon":"🐷","nameIpa":"/piː/","soundIpa":"/p/"},{"upper":"Q","lower":"q","word":"queen","meaning":"女王","icon":"👑","nameIpa":"/kjuː/","soundIpa":"/kw/"},{"upper":"R","lower":"r","word":"rabbit","meaning":"兔子","icon":"🐇","nameIpa":"/ɑɹ/","soundIpa":"/ɹ/"},{"upper":"S","lower":"s","word":"sun","meaning":"太陽","icon":"☀️","nameIpa":"/ɛs/","soundIpa":"/s/"},{"upper":"T","lower":"t","word":"tiger","meaning":"老虎","icon":"🐅","nameIpa":"/tiː/","soundIpa":"/t/"},{"upper":"U","lower":"u","word":"umbrella","meaning":"雨傘","icon":"☂️","nameIpa":"/juː/","soundIpa":"/ʌ/"},{"upper":"V","lower":"v","word":"van","meaning":"廂型車","icon":"🚐","nameIpa":"/viː/","soundIpa":"/v/"},{"upper":"W","lower":"w","word":"water","meaning":"水","icon":"💧","nameIpa":"/ˈdʌbəl.juː/","soundIpa":"/w/"},{"upper":"X","lower":"x","word":"fox","meaning":"狐狸","icon":"🦊","nameIpa":"/ɛks/","soundIpa":"/ks/"},{"upper":"Y","lower":"y","word":"yellow","meaning":"黃色","icon":"💛","nameIpa":"/waɪ/","soundIpa":"/j/"},{"upper":"Z","lower":"z","word":"zebra","meaning":"斑馬","icon":"🦓","nameIpa":"/ziː/","soundIpa":"/z/"}];
let alphaIndex=0;

const VOICE_SETTINGS_KEY='baseball_dualtrack_voice_v15';
const SPEEDS={slow:0.92,normal:1.0,clear:1.06};
// iOS speech often sounds clipped or robotic below ~0.85: speak whole natural sentences.
// 0.93 is clear but preserves connected speech; never break a sentence into words.
const SENTENCE_RATE=0.93; // relaxed English phrase rhythm, slight slowdown
const SENTENCE_SLOW_RATE=0.86; // slower replay while keeping normal phrase prosody
function isEnglishSentence(text){return /[A-Za-z]/.test(text)&&/\s/.test(text);}
let voicePrefs={speed:'normal',voiceURI:'',engine:'device'};
let speechActive=null,speechAttempt=0,voiceHealthTimer=null,wordReplayTimer=null;
// 音檔位置只在這裡設定一次。若把 audio 資料夾放進正式網站專案，改成 '' 即可。
// Recordings ship with this site and also work when hosted in a subdirectory.
const AUDIO_BASE='.';
const LETTER_RECORDINGS={"A":AUDIO_BASE+"/audio/letters/A.mp3?v=13","B":AUDIO_BASE+"/audio/letters/B.mp3?v=13","C":AUDIO_BASE+"/audio/letters/C.mp3?v=13","D":AUDIO_BASE+"/audio/letters/D.mp3?v=13","E":AUDIO_BASE+"/audio/letters/E.mp3?v=13","F":AUDIO_BASE+"/audio/letters/F.mp3?v=13","G":AUDIO_BASE+"/audio/letters/G.mp3?v=13","H":AUDIO_BASE+"/audio/letters/H.mp3?v=13","I":AUDIO_BASE+"/audio/letters/I.mp3?v=13","J":AUDIO_BASE+"/audio/letters/J.mp3?v=13","K":AUDIO_BASE+"/audio/letters/K.mp3?v=13","L":AUDIO_BASE+"/audio/letters/L.mp3?v=13","M":AUDIO_BASE+"/audio/letters/M.mp3?v=13","N":AUDIO_BASE+"/audio/letters/N.mp3?v=13","O":AUDIO_BASE+"/audio/letters/O.mp3?v=13","P":AUDIO_BASE+"/audio/letters/P.mp3?v=13","Q":AUDIO_BASE+"/audio/letters/Q.mp3?v=13","R":AUDIO_BASE+"/audio/letters/R.mp3?v=13","S":AUDIO_BASE+"/audio/letters/S.mp3?v=13","T":AUDIO_BASE+"/audio/letters/T.mp3?v=13","U":AUDIO_BASE+"/audio/letters/U.mp3?v=13","V":AUDIO_BASE+"/audio/letters/V.mp3?v=13","W":AUDIO_BASE+"/audio/letters/W.mp3?v=13","X":AUDIO_BASE+"/audio/letters/X.mp3?v=13","Y":AUDIO_BASE+"/audio/letters/Y.mp3?v=13","Z":AUDIO_BASE+"/audio/letters/Z.mp3?v=13"};
const WORD_RECORDINGS={"apple":AUDIO_BASE+"/audio/words/apple.mp3?v=13","ball":AUDIO_BASE+"/audio/words/ball.mp3?v=13","cat":AUDIO_BASE+"/audio/words/cat.mp3?v=13","dog":AUDIO_BASE+"/audio/words/dog.mp3?v=13","egg":AUDIO_BASE+"/audio/words/egg.mp3?v=13","fish":AUDIO_BASE+"/audio/words/fish.mp3?v=13","goat":AUDIO_BASE+"/audio/words/goat.mp3?v=13","hat":AUDIO_BASE+"/audio/words/hat.mp3?v=13","igloo":AUDIO_BASE+"/audio/words/igloo.mp3?v=13","jump":AUDIO_BASE+"/audio/words/jump.mp3?v=13","kite":AUDIO_BASE+"/audio/words/kite.mp3?v=13","lion":AUDIO_BASE+"/audio/words/lion.mp3?v=13","moon":AUDIO_BASE+"/audio/words/moon.mp3?v=13","nose":AUDIO_BASE+"/audio/words/nose.mp3?v=13","octopus":AUDIO_BASE+"/audio/words/octopus.mp3?v=13","pig":AUDIO_BASE+"/audio/words/pig.mp3?v=13","queen":AUDIO_BASE+"/audio/words/queen.mp3?v=13","rabbit":AUDIO_BASE+"/audio/words/rabbit.mp3?v=13","sun":AUDIO_BASE+"/audio/words/sun.mp3?v=13","tiger":AUDIO_BASE+"/audio/words/tiger.mp3?v=13","umbrella":AUDIO_BASE+"/audio/words/umbrella.mp3?v=13","van":AUDIO_BASE+"/audio/words/van.mp3?v=13","water":AUDIO_BASE+"/audio/words/water.mp3?v=13","fox":AUDIO_BASE+"/audio/words/fox.mp3?v=13","yellow":AUDIO_BASE+"/audio/words/yellow.mp3?v=13","zebra":AUDIO_BASE+"/audio/words/zebra.mp3?v=13","bat":AUDIO_BASE+"/audio/words/bat.mp3?v=13","glove":AUDIO_BASE+"/audio/words/glove.mp3?v=13","run":AUDIO_BASE+"/audio/words/run.mp3?v=13","hit":AUDIO_BASE+"/audio/words/hit.mp3?v=13","catch":AUDIO_BASE+"/audio/words/catch.mp3?v=13","team":AUDIO_BASE+"/audio/words/team.mp3?v=13","coach":AUDIO_BASE+"/audio/words/coach.mp3?v=13","home":AUDIO_BASE+"/audio/words/home.mp3?v=13","school":AUDIO_BASE+"/audio/words/school.mp3?v=13","book":AUDIO_BASE+"/audio/words/book.mp3?v=13","happy":AUDIO_BASE+"/audio/words/happy.mp3?v=13","fast":AUDIO_BASE+"/audio/words/fast.mp3?v=13","friend":AUDIO_BASE+"/audio/words/friend.mp3?v=13","red":AUDIO_BASE+"/audio/words/red.mp3?v=13","blue":AUDIO_BASE+"/audio/words/blue.mp3?v=13","field":AUDIO_BASE+"/audio/words/field.mp3?v=13","player":AUDIO_BASE+"/audio/words/player.mp3?v=13","score":AUDIO_BASE+"/audio/words/score.mp3?v=13","practice":AUDIO_BASE+"/audio/words/practice.mp3?v=13","helmet":AUDIO_BASE+"/audio/words/helmet.mp3?v=13","throw":AUDIO_BASE+"/audio/words/throw.mp3?v=13","first":AUDIO_BASE+"/audio/words/first.mp3?v=13","second":AUDIO_BASE+"/audio/words/second.mp3?v=13","ready":AUDIO_BASE+"/audio/words/ready.mp3?v=13","tired":AUDIO_BASE+"/audio/words/tired.mp3?v=13","before":AUDIO_BASE+"/audio/words/before.mp3?v=13","after":AUDIO_BASE+"/audio/words/after.mp3?v=13","together":AUDIO_BASE+"/audio/words/together.mp3?v=13","early":AUDIO_BASE+"/audio/words/early.mp3?v=13","strong":AUDIO_BASE+"/audio/words/strong.mp3?v=13","clean":AUDIO_BASE+"/audio/words/clean.mp3?v=13","quiet":AUDIO_BASE+"/audio/words/quiet.mp3?v=13","learn":AUDIO_BASE+"/audio/words/learn.mp3?v=13","inning":AUDIO_BASE+"/audio/words/inning.mp3?v=13","batter":AUDIO_BASE+"/audio/words/batter.mp3?v=13","pitcher":AUDIO_BASE+"/audio/words/pitcher.mp3?v=13","exercise":AUDIO_BASE+"/audio/words/exercise.mp3?v=13","improve":AUDIO_BASE+"/audio/words/improve.mp3?v=13","compare":AUDIO_BASE+"/audio/words/compare.mp3?v=13","prepare":AUDIO_BASE+"/audio/words/prepare.mp3?v=13","favorite":AUDIO_BASE+"/audio/words/favorite.mp3?v=13","usually":AUDIO_BASE+"/audio/words/usually.mp3?v=13","careful":AUDIO_BASE+"/audio/words/careful.mp3?v=13","although":AUDIO_BASE+"/audio/words/although.mp3?v=13","because":AUDIO_BASE+"/audio/words/because.mp3?v=13","important":AUDIO_BASE+"/audio/words/important.mp3?v=13","different":AUDIO_BASE+"/audio/words/different.mp3?v=13","question":AUDIO_BASE+"/audio/words/question.mp3?v=13","answer":AUDIO_BASE+"/audio/words/answer.mp3?v=13"};
const SENTENCE_RECORDINGS={"I have a ball.":AUDIO_BASE+"/audio/sentences/s01.mp3","The bat is red.":AUDIO_BASE+"/audio/sentences/s02.mp3","Tom can run.":AUDIO_BASE+"/audio/sentences/s03.mp3","She has a book.":AUDIO_BASE+"/audio/sentences/s04.mp3","We are a team.":AUDIO_BASE+"/audio/sentences/s05.mp3","The dog is happy.":AUDIO_BASE+"/audio/sentences/s06.mp3","Dad drinks water.":AUDIO_BASE+"/audio/sentences/s07.mp3","The glove is blue.":AUDIO_BASE+"/audio/sentences/s08.mp3","My friend can jump.":AUDIO_BASE+"/audio/sentences/s09.mp3","The coach is here.":AUDIO_BASE+"/audio/sentences/s10.mp3","Mia wears a helmet to practice.":AUDIO_BASE+"/audio/sentences/s11.mp3","Ben is tired after the game.":AUDIO_BASE+"/audio/sentences/s12.mp3","The players practice together.":AUDIO_BASE+"/audio/sentences/s13.mp3","We clean the field before practice.":AUDIO_BASE+"/audio/sentences/s14.mp3","Lily throws the ball to Sam.":AUDIO_BASE+"/audio/sentences/s15.mp3","The team is ready for the game.":AUDIO_BASE+"/audio/sentences/s16.mp3","The second player has a red bat.":AUDIO_BASE+"/audio/sentences/s17.mp3","The coach asks us to learn a new skill.":AUDIO_BASE+"/audio/sentences/s18.mp3","I get up early to read a book.":AUDIO_BASE+"/audio/sentences/s19.mp3","Please be quiet in the library.":AUDIO_BASE+"/audio/sentences/s20.mp3","Although it rains, we practice inside.":AUDIO_BASE+"/audio/sentences/s21.mp3","The pitcher prepares before every game.":AUDIO_BASE+"/audio/sentences/s22.mp3","Baseball is my favorite sport because I love teamwork.":AUDIO_BASE+"/audio/sentences/s23.mp3","We compare two scores to find the difference.":AUDIO_BASE+"/audio/sentences/s24.mp3","It is important to drink water after exercise.":AUDIO_BASE+"/audio/sentences/s25.mp3","She usually reads before going to sleep.":AUDIO_BASE+"/audio/sentences/s26.mp3","The batter asks a question, and the coach gives an answer.":AUDIO_BASE+"/audio/sentences/s27.mp3","Each player chooses a different way to improve.":AUDIO_BASE+"/audio/sentences/s28.mp3","Please be careful when you carry heavy equipment.":AUDIO_BASE+"/audio/sentences/s29.mp3","Our class prepares a small sports event together.":AUDIO_BASE+"/audio/sentences/s30.mp3"};
let activeRecordedAudio=null;

function saveVoicePrefs(){} // device voice is the fixed, free source; no choice or persisted engine.
function speechControls(){return `<div class="speech-controls" aria-label="美式英文朗讀">
 <span class="speech-tool" style="font-size:13px;font-weight:750">🔊 裝置內建美式英文 · 免費</span>
 <button class="speech-test" type="button" data-action="voice-test">▶ 試聽 Ball</button>
 <button class="speech-test" type="button" data-action="voice-test-apple">▶ 試聽 Apple</button>
 </div><div class="speech-status" id="speech-status" role="status" aria-live="polite">句型採自然清楚語速（0.93 倍），保留英文連音與正常抑揚；聽不清楚可用 0.86 倍重聽。不拆開單字。字母使用真人錄音，單字維持原速，不需付費。</div>`}
function getEnglishVoices(){if(!('speechSynthesis' in window))return [];try{return speechSynthesis.getVoices().filter(v=>/^(en-US|en_US|en)$/i.test(v.lang||''))}catch(_){return []}}
function pickEnglishVoice(){
  const voices=getEnglishVoices();
  if(voicePrefs.voiceURI){const chosen=voices.find(v=>v.voiceURI===voicePrefs.voiceURI);if(chosen)return chosen}
  // Some iPhones have downloaded premium/enhanced voices. Prefer them automatically;
  // if the device has none, its standard US-English voice remains the fallback.
  const quality=v=>{
    const name=String(v.name||'').toLowerCase();let score=0;
    if(/premium|enhanced/.test(name))score+=60;
    if(/siri|neural|natural/.test(name))score+=38;
    if(/ava|samantha|allison/.test(name))score+=8;
    if(v.localService)score+=5;
    if(v.default)score+=9;
    return score;
  };
  return voices.slice().sort((a,b)=>quality(b)-quality(a))[0]||null;
}
function populateSpeechVoices(){} // no voice picker
function showSpeechStatus(text){const el=document.getElementById('speech-status');if(el)el.textContent=text}
function stopEnglish(){clearTimeout(autoReadTimer);speechAttempt++;clearTimeout(voiceHealthTimer);clearTimeout(wordReplayTimer);wordReplayTimer=null;if(activeRecordedAudio){try{activeRecordedAudio.pause();activeRecordedAudio.removeAttribute('src');activeRecordedAudio.load()}catch(_){}activeRecordedAudio=null}try{if('speechSynthesis'in window){speechSynthesis.cancel()}}catch(_){}speechActive=null}

const VOCAB={
1:[["ball","球","⚾"],["bat","球棒",""],["glove","手套","🧤"],["run","跑","🏃"],["hit","擊打","💥"],["catch","接住","🙌"],["team","隊伍","👥"],["coach","教練","🧑‍🏫"],["home","家","🏠"],["school","學校","🏫"],["water","水","💧"],["book","書","📘"],["happy","開心的","😊"],["fast","快速的","💨"],["friend","朋友","🤝"],["red","紅色","🔴"],["blue","藍色","🔵"],["jump","跳","🦘"],["hat","帽子","🧢"],["pen","原子筆","🖊️"],["pencil","鉛筆","✏️"],["bag","袋子；包包","🎒"],["desk","書桌",""],["chair","椅子","🪑"],["table","桌子",""],["door","門","🚪"],["window","窗戶","🪟"],["clock","時鐘","🕒"],["light","燈光","💡"],["breakfast","早餐","🥣"],["lunch","午餐","🍱"],["dinner","晚餐","🍽️"],["rice","米飯","🍚"],["milk","牛奶","🥛"],["bread","麵包","🍞"],["banana","香蕉","🍌"],["orange","橘子","🍊"],["hand","手","✋"],["head","頭","🙂"],["foot","腳","🦶"],["eye","眼睛","👁️"],["ear","耳朵","👂"],["leg","腿","🦵"],["shirt","襯衫","👕"],["shoes","鞋子","👟"],["play","玩耍","🎮"],["read","閱讀","📚"],["write","寫字","✍️"],["sing","唱歌","🎤"],["walk","走路","🚶"],["swim","游泳","🏊"],["big","大的","🐘"],["small","小的","🐁"],["long","長的","📏"],["short","短的","📐"],["hot","熱的","🔥"],["cold","冷的","🧊"],["green","綠色","🟢"],["white","白色","⚪"],["black","黑色","⚫"],["park","公園","🌳"],["family","家人","👨‍👩‍👧‍👦"],["mother","媽媽","👩"],["father","爸爸","👨"],["sister","姊妹","👧"],["brother","兄弟","👦"],["teacher","老師","🧑‍🏫"],["student","學生","🧑‍🎓"],["bike","腳踏車","🚲"],["rain","雨","🌧️"],["tree","樹","🌲"],["flower","花","🌸"],["bird","鳥","🐦"]],
2:[["field","球場","🏟️"],["player","球員","⚾"],["score","得分","🏆"],["practice","練習","🏃"],["helmet","安全帽",""],["throw","投擲",""],["first","第一","1️⃣"],["second","第二","2️⃣"],["ready","準備好的","✅"],["tired","疲倦的","😴"],["before","在……之前","⏪"],["after","在……之後","⏩"],["together","一起","🤝"],["early","早的","🌅"],["strong","強壯的","💪"],["clean","乾淨的","✨"],["quiet","安靜的","🤫"],["learn","學習","🧠"],["arrive","抵達","📍"],["leave","離開","🚶"],["borrow","借入","📗"],["return","歸還","↩️"],["carry","搬運","📦"],["share","分享","🤝"],["invite","邀請","💌"],["remember","記得","🧠"],["forget","忘記","❓"],["decide","決定","✅"],["choose","選擇","🔍"],["enjoy","享受","😊"],["finish","完成","🏁"],["start","開始","🚀"],["problem","問題；難題","❗"],["example","例子","💡"],["story","故事","📖"],["plan","計畫","🗓️"],["healthy","健康的","🥗"],["hungry","飢餓的","🍽️"],["thirsty","口渴的","💧"],["busy","忙碌的","📅"],["safe","安全的","🦺"],["simple","簡單的","🟩"],["difficult","困難的","🧗"],["corner","角落","📐"],["circle","圓形","⭕"],["square","正方形","⬜"],["triangle","三角形","🔺"],["straight","筆直的","➡️"],["opposite","相反的","↔️"],["behind","在後方","🔙"],["between","在兩者之間","↕️"],["across","穿越到對面","🚦"],["around","在周圍","🔄"],["sometimes","有時候","🕓"],["always","總是","♾️"],["never","從不","🚫"],["weekend","週末","🎉"],["month","月份","🗓️"],["season","季節","🍂"],["weather","天氣","⛅"],["cloudy","多雲的","☁️"],["sunny","晴朗的","🌞"],["library","圖書館","📚"],["hospital","醫院","🏥"],["market","市場","🛒"],["train","火車","🚆"],["ticket","票券","🎫"],["baseball","棒球運動","⚾"],["uniform","制服",""],["captain","隊長","🧢"],["catcher","捕手",""],["museum","博物館","🏛️"]],
3:[["inning","一局","📋"],["batter","打者","🏏"],["pitcher","投手","⚾"],["exercise","運動","🏃"],["improve","進步","📈"],["compare","比較","⚖️"],["prepare","準備","🎒"],["favorite","最喜愛的","❤️"],["usually","通常","🔄"],["careful","小心的","🔎"],["although","雖然","💭"],["because","因為","💡"],["important","重要的","⭐"],["different","不同的","🔀"],["question","問題","❔"],["answer","答案","✅"],["strategy","策略","♟️"],["teamwork","團隊合作","🤝"],["responsibility","責任","📝"],["respect","尊重","🙏"],["patience","耐心","⌛"],["effort","努力","💪"],["confident","有自信的","🌟"],["curious","好奇的","🔎"],["discover","發現","🔬"],["explore","探索","🗺️"],["observe","觀察","👀"],["predict","預測","🔮"],["explain","解釋","💬"],["evidence","證據","📑"],["solution","解決方法","🧩"],["mistake","錯誤","❌"],["result","結果","📊"],["progress","進展","📈"],["challenge","挑戰","🏆"],["opportunity","機會","🚪"],["goal","目標","🎯"],["schedule","時間表","🗓️"],["flexible","有彈性的","🤸"],["routine","例行習慣","🔁"],["encourage","鼓勵","🎉"],["communicate","溝通","🗣️"],["cooperate","合作","👥"],["community","社區","🏘️"],["environment","環境","🌱"],["recycle","回收","♻️"],["reduce","減少","📉"],["balance","平衡","⚖️"],["energy","能量","⚡"],["nutrition","營養","🥦"],["concentrate","專心","🧠"],["focus","聚焦","🎯"],["efficient","有效率的","⏱️"],["distance","距離","📏"],["measure","測量","📐"],["estimate","估計","📊"],["fraction","分數（數學）","¼"],["average","平均值","➗"],["multiply","乘","✖️"],["divide","除","➗"],["experiment","實驗","🧪"],["research","研究","📋"],["decision","決策","📌"],["consequence","後果","🔮"],["persistence","毅力","🏃"],["achievement","成就","🏅"],["identify","辨認","🔍"],["participate","參與","🙋"],["positive","正向的","➕"],["negative","負向的","➖"],["independent","獨立的","🧍"]]
};
// 容易混淆或在句子裡都說得通的字，不會同時出現在選項中。
const CONFUSE=[['desk','table','chair'],['decide','choose'],['sometimes','always','never','usually'],['confident','curious','careful'],['observe','predict','explore','discover','research','experiment','identify'],['improve','progress','achievement'],['effort','persistence','patience'],['teamwork','cooperate','participate','community'],['focus','concentrate'],['goal','plan','schedule','strategy'],['solution','answer','result'],['question','problem'],['exercise','practice'],['early','fast'],['tired','thirsty','hungry','busy'],['happy','enjoy'],['big','long','strong'],['small','short'],['read','learn','study'],['player','captain','catcher','batter','pitcher','coach','team'],['field','park'],['bag','shoes','shirt']];
function confusable(a,b){return a===b||CONFUSE.some(g=>g.includes(a)&&g.includes(b))}
const READ={
1:[
['I have a ball.','我有什麼？',['球','球棒','手套','帽子'],'球','I have a ball. 意思是「我有一顆球」。'],
['The bat is red.','球棒是什麼顏色？',['紅色','藍色','綠色','黃色'],'紅色','red 是紅色。'],
['Tom can run.','Tom 會做什麼？',['跑步','游泳','唱歌','睡覺'],'跑步','can run 表示「會跑」。'],
['She has a book.','她有什麼？',['書','水','球','鉛筆'],'書','has a book 表示「有一本書」。'],
['We are a team.','我們是什麼？',['隊伍','學校','家','公園'],'隊伍','team 表示「隊伍」。'],
['The dog is happy.','小狗的心情如何？',['開心','難過','生氣','緊張'],'開心','happy 是「開心的」。'],
['Dad drinks water.','爸爸喝什麼？',['水','牛奶','果汁','茶'],'水','drinks water 表示「喝水」。'],
['The glove is blue.','手套是什麼顏色？',['藍色','紅色','白色','黑色'],'藍色','blue 是藍色。'],
['My friend can jump.','我的朋友會做什麼？',['跳','跑','讀書','游泳'],'跳','jump 是「跳」。'],
['The coach is here.','誰在這裡？',['教練','老師','醫生','球迷'],'教練','coach 是「教練」。']
],
2:[
['Mia wears a helmet to practice.','Mia 練習時戴了什麼？',['安全帽','手套','圍巾','眼鏡'],'安全帽','helmet 是安全帽；wears 表示「穿戴」。'],
['Ben is tired after the game.','Ben 在比賽後感覺如何？',['疲倦','開心','生氣','興奮'],'疲倦','tired 是疲倦；after 是「在……之後」。'],
['The players practice together.','球員們如何練習？',['一起','各自在家','只在早上','沒有練習'],'一起','together 是「一起」。'],
['We clean the field before practice.','他們何時整理球場？',['練習前','練習後','午餐後','睡覺前'],'練習前','before practice 是「練習之前」。'],
['Lily throws the ball to Sam.','Lily 把球丟給誰？',['Sam','教練','爸爸','沒有人'],'Sam','to Sam 表示動作的對象是 Sam。'],
['The team is ready for the game.','隊伍的狀態是？',['準備好了','很累','在睡覺','找不到球'],'準備好了','ready 表示「準備好」。'],
['The second player has a red bat.','哪一位球員有紅球棒？',['第二位','第一位','第三位','教練'],'第二位','second 表示「第二」。'],
['The coach asks us to learn a new skill.','教練要大家做什麼？',['學新技巧','回家','買球棒','喝水'],'學新技巧','learn a new skill 表示「學習新技巧」。'],
['I get up early to read a book.','我為什麼早起？',['讀書','看電視','打電動','購物'],'讀書','to read a book 在這裡表示目的。'],
['Please be quiet in the library.','在圖書館應該怎麼做？',['保持安靜','大聲唱歌','跑步','打球'],'保持安靜','be quiet 表示「保持安靜」。']
],
3:[
['Although it rains, we practice inside.','下雨時他們在哪裡練習？',['室內','操場','海邊','公園'],'室內','although 是「雖然」；inside 是「在裡面」。'],
['The pitcher prepares before every game.','誰在每場比賽前準備？',['投手','捕手','裁判','觀眾'],'投手','pitcher 是投手；before every game 是每場比賽前。'],
['Baseball is my favorite sport because I love teamwork.','說話者喜歡棒球的原因是？',['喜歡團隊合作','喜歡下雨','喜歡睡覺','喜歡游泳'],'喜歡團隊合作','because 後面說明原因。'],
['We compare two scores to find the difference.','為什麼要比較兩個分數？',['找出差距','找出顏色','找出球棒','找出座位'],'找出差距','compare 比較；difference 是差異。'],
['It is important to drink water after exercise.','運動後重要的是什麼？',['喝水','不睡覺','一直看手機','不吃飯'],'喝水','important 是重要的；after exercise 是運動後。'],
['She usually reads before going to sleep.','她通常在什麼時候閱讀？',['睡前','早餐後','比賽中','上學途中'],'睡前','usually 是通常；before going to sleep 是睡前。'],
['The batter asks a question, and the coach gives an answer.','誰回答問題？',['教練','打者','投手','觀眾'],'教練','gives an answer 表示「給出答案」。'],
['Each player chooses a different way to improve.','每個球員選擇什麼？',['不同的進步方法','同一種制服','同一支球棒','同一個位置'],'不同的進步方法','different 是不同的；improve 是進步。'],
['Please be careful when you carry heavy equipment.','搬運重裝備時要怎樣？',['小心','快跑','閉眼','大笑'],'小心','careful 是小心的。'],
['Our class prepares a small sports event together.','班級一起準備什麼？',['小型運動活動','電影','午餐','考試'],'小型運動活動','a small sports event 是小型運動活動。']
]};
// Strictly validate older backups before any value reaches HTML or learning statistics.
// Malformed/legacy items are skipped; the original localStorage key is never erased.
function cleanHistorySession(s){
 if(!s||typeof s!=='object'||!SUBJECT_KEYS.includes(s.subject)||!MODES[s.subject].some(m=>m.id===s.mode))return null;
 const total=Number(s.total),correct=Number(s.correct),when=String(s.date||'');
 if(!Number.isInteger(total)||total<1||total>12||!Number.isInteger(correct)||correct<0||correct>total||when.length>40||!Number.isFinite(Date.parse(when)))return null;
 const attempts=Array.isArray(s.attempts)?s.attempts.slice(0,12).filter(a=>a&&typeof a==='object'&&typeof a.skill==='string'&&Object.prototype.hasOwnProperty.call(SKILLS,a.skill)&&typeof a.correct==='boolean').map(a=>({skill:a.skill,correct:a.correct,hintUsed:!!a.hintUsed,review:!!a.review,concept:typeof a.concept==='string'?a.concept.slice(0,80):'',level:[1,2,3,4].includes(Number(a.level))?Number(a.level):1})):[];
 return {date:when,subject:s.subject,mode:s.mode,level:[1,2,3,4].includes(Number(s.level))?Number(s.level):1,total,correct,attempts};
}
function cleanHistoryReflection(r){if(!r||typeof r.text!=='string'||r.text.length>10000)return null;const d=String(r.date||'');if(d.length>40||!Number.isFinite(Date.parse(d)))return null;return {date:d,text:r.text.slice(0,160)}}
let storageIssue='',storageUnreadable=false;
function safeLoad(){storageIssue='';storageUnreadable=false;try{const text=localStorage.getItem(dataKey());if(text===null)return structuredClone(DEFAULT);const raw=JSON.parse(text);if(!raw||typeof raw!=='object'||Array.isArray(raw)||!raw.settings||!Array.isArray(raw.sessions)||!Array.isArray(raw.reflections))throw new Error('Invalid history');const sessions=raw.sessions.slice(-300).map(cleanHistorySession).filter(Boolean);const reflections=raw.reflections.slice(-100).map(cleanHistoryReflection).filter(Boolean);return {settings:normalizeSettings(raw.settings),sessions,reflections,reviewQueue:sanitizeReviewQueue(raw.reviewQueue),recent:cleanRecent(raw.recent),practiceDraft:raw.practiceDraft||null,writingDraft:raw.writingDraft||null}}catch(e){storageUnreadable=true;storageIssue='原有紀錄暫時無法讀取，已暫停寫入以保留原始資料。請由家長匯出原始資料後檢查。';console.warn('Learning history was not readable; using a temporary empty view without deleting anything.',e?.name);return structuredClone(DEFAULT)}}
let data=safeLoad(),page='home',subject=null,mode=null,session=null,feedback=null,finished=null;
// 手寫內容暫存在本頁記憶體；不送出、不上傳，也不變更既有的答題紀錄。
let handTab='english',handMode='letter',handLetter=0,handWord=0,handMath=null,handInk=[],handResult='',handSolution=false,handQuizOpen=false;
let handActivePointer=null,handResizeObserver=null,handAnswerInk=[],handRecognitionBusy=false,handOcrResult='',handOcrCandidates=[];
let handScoreHtml='',handInkRevision=0,handExpanded=false,handAnswerExpanded=false;
const app=document.getElementById('app');
// Parent PIN is a local-device privacy barrier, NOT server-side account authentication.
const PARENT_KEY='homerun_parent_pin_v1';
let parentUnlocked=false,parentFailures=0,parentCooldownUntil=0,advanceTimer=null;
function clearAdvance(){clearTimeout(autoReadTimer);if(advanceTimer!==null){clearTimeout(advanceTimer);advanceTimer=null}}
function parentPinRecord(){try{const o=JSON.parse(localStorage.getItem(PARENT_KEY)||'null');return o&&typeof o.salt==='string'&&/^[0-9a-f]{32}$/.test(o.salt)&&typeof o.hash==='string'&&/^[0-9a-f]{64}$/.test(o.hash)?o:null}catch(_){return null}}
const hex=b=>Array.from(b,x=>x.toString(16).padStart(2,'0')).join('');
function hexBytes(s){return new Uint8Array(s.match(/.{2}/g).map(x=>parseInt(x,16)))}
async function hashPin(pin,salt){
 if(!crypto?.subtle)throw new Error('目前瀏覽器無法安全設定密碼，請使用 Safari 或 Chrome 開啟 HTTPS 網站。');
 const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(pin),'PBKDF2',false,['deriveBits']);
 return hex(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',salt:hexBytes(salt),iterations:180000,hash:'SHA-256'},k,256)));
}
function constantMatch(a,b){if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a.charCodeAt(i)^b.charCodeAt(i);return diff===0}

let parentResetOpen=false,recoveryPlain='',guideOpen=true;
const GUIDE_KEY='explorer_guide_v1';
try{guideOpen=localStorage.getItem(GUIDE_KEY)!=='seen'}catch(_){}
function closeGuide(){guideOpen=false;try{localStorage.setItem(GUIDE_KEY,'seen')}catch(_){}render()}
function guideMarkup(){if(!guideOpen)return '';return '<div class="guide-overlay"><section class="guide-dialog" role="dialog" aria-modal="true" aria-labelledby="guide-title"><div class="eyebrow">小小探索學院</div><h1 id="guide-title">歡迎一起探索！</h1><ol><li><strong>選擇小朋友</strong><p>每位孩子有自己的年級、風格和學習紀錄。</p></li><li><strong>每天學一點</strong><p>選國語、注音、英文、數學、邏輯或科學；九九乘法獨立練習 1～9。</p></li><li><strong>手機播音，紙上聽寫</strong><p>國語先選課次，再進入「生字圈詞・播音聽寫」。寫完可開答案卷。</p></li><li><strong>家長區陪孩子學</strong><p>調整難度、查看紀錄，設定密碼；忘記時可用數學驗證重設。</p></li></ol><p class="note">紀錄保存在目前手機與瀏覽器，換裝置不會自動同步。家長可匯出備份；請勿隨意清除網站資料。</p><button id="guide-close" class="btn btn-dark" data-action="guide-close">我知道了，開始探索</button></section></div>'}

let parentChallenge=null;
function newParentChallenge(){
 const n=crypto.getRandomValues(new Uint8Array(2)),a=10+n[0]%40,b=1+n[1]%9;
 parentChallenge={a,b,answer:String(a+b),id:hex(crypto.getRandomValues(new Uint8Array(8)))};return parentChallenge;
}
function recoveryPanel(){return ''}
function recoveryGate(){
 if(!parentPinRecord())return '<button class="back" data-action="recovery-back">← 返回密碼設定</button><section class="card"><h1>尚未設定家長密碼</h1><p>請返回設定一組家長密碼。</p></section>';
 const q=parentChallenge||newParentChallenge();
 return '<button class="back" data-action="recovery-back">← 返回密碼登入</button><section class="card parent-auth-card"><h1>🔢 數學驗證重設密碼</h1><p>算對下方的加法，就能設定新密碼。孩子的學習紀錄會保留。</p><form data-pin-form="recover" class="pin-form"><input type="hidden" name="challenge" value="'+q.id+'"><label for="verify-answer">'+q.a+' ＋ '+q.b+' ＝ ？</label><input id="verify-answer" name="verification" inputmode="numeric" pattern="[0-9]+" required autocomplete="off" placeholder="輸入計算答案"><button type="button" class="btn btn-outline" data-action="recovery-question">換一道算式</button><label for="reset-pin">新的 6～12 位數字密碼</label><input id="reset-pin" name="pin" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="new-password"><label for="reset-confirm">再次輸入新密碼</label><input id="reset-confirm" name="confirm" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="new-password"><button class="btn btn-dark" type="submit">驗證並重設密碼</button></form><p id="pin-error" class="pin-error" role="alert" aria-live="polite"></p></section>';
}
async function resetParentPin(answer,pin,confirmPin,challengeId){
 if(!parentPinRecord())throw Error('尚未設定家長密碼。');
 const q=parentChallenge;if(!q||q.id!==challengeId)throw Error('這道驗證已失效，請重新取得算式。');
 if(String(answer).trim()!==q.answer)throw Error('數學答案不正確，請再算一次。');
 if(!/^[0-9]{6,12}$/.test(pin)||pin!==confirmPin)throw Error('新密碼須為 6～12 位數字，且兩次輸入一致。');
 const salt=hex(crypto.getRandomValues(new Uint8Array(16))),hash=await hashPin(pin,salt);
 if(parentChallenge!==q)throw Error('驗證算式已變更，請重新驗證。');
 localStorage.setItem(PARENT_KEY,JSON.stringify({v:3,salt,hash}));parentChallenge=null;
 parentUnlocked=true;parentResetOpen=false;parentFailures=0;parentCooldownUntil=0;
}

function parentGate(){if(parentResetOpen)return recoveryGate();const setup=!parentPinRecord();return `<button class="back" data-action="nav-home">← 回到學習區</button><section class="card parent-auth-card"><div class="auth-emoji" aria-hidden="true">🔐</div><div class="eyebrow">PARENT ACCESS</div><h1>${setup?'首次使用：設定家長密碼':'家長專用｜輸入密碼'}</h1><p>${setup?'請設定 6～12 位數字密碼，之後每次進入家長區都要輸入。':'家長區包含學習紀錄、難度和資料管理，請先解鎖。'}</p><form data-pin-form="${setup?'create':'unlock'}" class="pin-form"><label for="parent-pin">${setup?'設定 6～12 位數字密碼':'家長密碼'}</label><input id="parent-pin" name="pin" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="off" placeholder="${setup?'至少 6 位數字':'輸入密碼'}" />${setup?`<label for="parent-confirm">再次輸入密碼</label><input id="parent-confirm" name="confirm" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="off" placeholder="再次確認"/>`:''}<button class="btn btn-dark" type="submit" style="width:100%">${setup?'設定密碼並開啟家長區':'🔓 解鎖家長區'}</button></form><p class="note">${setup?'密碼只保存在本機（經加鹽雜湊），不會上傳；請自己妥善記住。':'忘記密碼時，完成一道數學驗證即可重設，不會清除孩子的學習紀錄。'}</p><p class="note">⚠️ 這是共用裝置的家長防誤入機制，不是高安全性的網站登入；能存取裝置儲存資料的人仍可能繞過。</p><button class="btn btn-outline" type="button" data-action="recovery-open" style="margin:12px 0">忘記密碼？驗證重設</button><p id="pin-error" class="pin-error" role="alert" aria-live="polite"></p></section>`}
function pinMessage(m){const el=document.getElementById('pin-error');if(el)el.textContent=m;else toast(m)}
async function handleParentForm(e){const form=e.target;if(!(form instanceof HTMLFormElement)||!form.dataset.pinForm)return;
 e.preventDefault();const mode=form.dataset.pinForm,pin=String(form.elements.namedItem('pin')?.value||''),confirmPin=String(form.elements.namedItem('confirm')?.value||'');
 if(!/^[0-9]{6,12}$/.test(pin)){pinMessage('密碼須為 6～12 位數字。');return}
 const submit=form.querySelector('button[type="submit"]');if(submit)submit.disabled=true;
 try{
  if(mode==='create'){
   if(parentPinRecord()){pinMessage('此裝置已有密碼設定，請重新整理後解鎖。');return}
   if(pin!==confirmPin){pinMessage('兩次輸入的密碼不一致。');return}
   const salt=hex(crypto.getRandomValues(new Uint8Array(16)));
   const hash=await hashPin(pin,salt);
   localStorage.setItem(PARENT_KEY,JSON.stringify({v:3,salt,hash}));parentUnlocked=true;parentFailures=0;navigate('parent');toast('家長區密碼設定完成。');
  }else if(mode==='unlock'){
   if(Date.now()<parentCooldownUntil){pinMessage('錯誤次數過多，請稍後再試。');return}
   const auth=parentPinRecord();if(!auth){render();return}
   const hash=await hashPin(pin,auth.salt);
   if(constantMatch(hash,auth.hash)){parentUnlocked=true;parentFailures=0;parentCooldownUntil=0;navigate('parent')}else{
    parentFailures++;if(parentFailures>=5){parentCooldownUntil=Date.now()+30000;parentFailures=0;pinMessage('連續輸入錯誤，暫停 30 秒。')}else pinMessage('密碼不正確，請再試一次。');
    form.elements.namedItem('pin').value='';
   }
  }else if(mode==='recover'){
   await resetParentPin(String(form.elements.namedItem('verification')?.value||''),pin,confirmPin,String(form.elements.namedItem('challenge')?.value||''));navigate('parent');toast('密碼已重設，學習紀錄保留。');
  }else if(mode==='change'){
   if(!parentUnlocked||!parentPinRecord()){pinMessage('請先解鎖家長區。');return}
   const current=String(form.elements.namedItem('current')?.value||'');
   const auth=parentPinRecord();const currentHash=await hashPin(current,auth.salt);
   if(!constantMatch(currentHash,auth.hash)){toast('原密碼不正確。');return}
   if(pin!==confirmPin){toast('兩次新密碼不一致。');return}
   const salt=hex(crypto.getRandomValues(new Uint8Array(16)));
   localStorage.setItem(PARENT_KEY,JSON.stringify({...auth,v:2,salt,hash:await hashPin(pin,salt)}));form.reset();toast('已更新家長密碼。');
  }
 }catch(err){pinMessage('密碼操作失敗：'+(err?.message||'請確認瀏覽器支援安全儲存。'))}finally{if(submit&&submit.isConnected)submit.disabled=false}
}
app.addEventListener('submit',handleParentForm);
app.addEventListener('submit',e=>{const f=e.target;if(!(f instanceof HTMLFormElement)||!f.dataset.playerForm)return;e.preventDefault();if(!parentUnlocked&&f.dataset.playerForm!=='new-login'){toast('請先解鎖家長區。');return}handlePlayerForm(f)});

function save(candidate=data,{repair=false}={}){
 if(storageUnreadable&&!repair){showStorageIssue();return false}
 try{
  const key=dataKey(),previous=localStorage.getItem(key),next=JSON.stringify(candidate);
  // Keep one previous snapshot before replacing data, including explicit imports/resets.
  if(previous&&previous!==next)localStorage.setItem(key+'__previous',previous);
  localStorage.setItem(key,next);data=candidate;storageIssue='';storageUnreadable=false;showStorageIssue();return true;
 }catch(_){storageIssue='這次進度尚未成功儲存。請先匯出紀錄備份，再檢查瀏覽器儲存空間；目前畫面的資料仍保留。';showStorageIssue();return false}
}
function showStorageIssue(){const box=document.getElementById('storage-warning');if(box){box.hidden=!storageIssue;box.textContent=storageIssue}}
function storageNotice(){return '<div id="storage-warning" class="storage-warning" role="alert" '+(storageIssue?'':'hidden')+'>'+h(storageIssue)+'</div>'}
function exportRawHistory(previous=false){if(!parentUnlocked)return;try{const text=localStorage.getItem(dataKey()+(previous?'__previous':''));if(text===null){toast(previous?'尚無上一份自動備份。':'尚無已儲存的紀錄。');return}downloadJson(text,previous?'上一份自動備份':'原始紀錄')}catch(_){toast('無法讀取原始紀錄，請保留目前瀏覽器資料。')}}
function downloadJson(text,label){const url=URL.createObjectURL(new Blob([text],{type:'application/json;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=activeProfile().name+'_'+label+'_'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)}
function focusLesson(){const el=document.querySelector(page==='quiz'?'.question-prompt':'#content h1');if(el){el.setAttribute('tabindex','-1');el.focus({preventScroll:true})}}

function h(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
const rand=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
const one=a=>a[rand(0,a.length-1)];
function shuffle(a){const x=a.slice();for(let i=x.length-1;i>0;i--){const j=rand(0,i);[x[i],x[j]]=[x[j],x[i]]}return x}
const fmtDate=(d)=>new Date(d).toLocaleDateString('zh-TW',{month:'numeric',day:'numeric'});
function toast(str){const t=document.getElementById('toast');if(!t){console.info(String(str));return}t.textContent=str;t.classList.remove('hidden');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.add('hidden'),3000)}
function navigate(target){handInk=[];handAnswerInk=[];handOcrResult='';handResult='';handQuizOpen=false;handSolution=false;handActivePointer=null;if(handResizeObserver)handResizeObserver.disconnect();clearAdvance();stopEnglish();if(target!=='parent'){parentUnlocked=false;recoveryPlain='';parentResetOpen=false;}page=target;feedback=null;session=null;finished=null;window.scrollTo(0,0);render()}
function header(){return `<header class="topbar"><a href="#home" class="brand" data-action="nav-home" aria-label="回學院首頁"><span class="brand-ball" aria-hidden="true">${worldInfo().icon}</span><span><span class="brand-name">${worldInfo().name}</span><span class="brand-sub">${worldInfo().sub}</span></span></a><button type="button" class="player-chip" data-action="nav-login" aria-label="換小朋友">${activeProfile().avatar} ${h(activeProfile().name)}</button><nav class="nav" aria-label="主要導覽"><button type="button" data-action="nav-home" class="${['home','select','quiz','result','science-learn','dictation','times','alphabet','zhuyin','players'].includes(page)?'active':''}">👦 學習區</button><button type="button" data-action="nav-handwrite" class="${page==='handwrite'?'active':''}">✍️ 手寫場</button><button type="button" data-action="nav-parent" class="${page==='parent'?'active':''}">📋 家長區</button><button type="button" data-action="guide-open">❔ 說明</button></nav></header>`}
function footer(){return `<footer class="footer"><span>${worldInfo().footer}：國語 × 注音 × 英文 × 數學 × 邏輯 × 科學｜不排名、不倒數計時</span><span>學習紀錄僅儲存於本裝置 · 手寫辨識僅供練習參考 · 注音發音：<a href="https://language.moe.gov.tw/001/Upload/files/site_content/M0001/juyin/html_ch/index.html" target="_blank" rel="noopener noreferrer">教育部《國語注音符號手冊》</a>音檔，CC BY 4.0，本站調整為 0.8 倍速並放大音量 · v36</span></footer>`}
function getTodayStats(){const today=new Date().toDateString();const ss=data.sessions.filter(s=>new Date(s.date).toDateString()===today);return {sessions:ss.length,questions:ss.reduce((a,s)=>a+s.total,0)}}
function getSubStats(s){const ss=data.sessions.filter(x=>x.subject===s);const total=ss.reduce((a,x)=>a+x.total,0);const good=ss.reduce((a,x)=>a+x.correct,0);return {num:ss.length,accuracy:total?Math.round(good/total*100):null}}
function homeV28(){const today=getTodayStats(),en=getSubStats('english'),ma=getSubStats('math');const suggest=reviewSuggestion();return `<section class="learning-guide"><div><strong>🎯 今天怎麼學？</strong><p>${suggest.total?`有 ${suggest.total} 題可複習。錯題不用一次刷完，理解後分次再試。`:suggest.worst?`最近可以多留意「${h(SKILLS[suggest.worst.skill])}」；先練一回合，再看自己怎麼想。`:'建議每天 10～15 分鐘：先練基礎，再挑一題說明自己的思路。'}</p></div><div class="guide-actions">${suggest.en?`<button class="btn btn-outline" data-action="review-english">🔤 英文複習 ${suggest.en}</button>`:''}${suggest.ma?`<button class="btn btn-outline" data-action="review-math">🔢 數學複習 ${suggest.ma}</button>`:''}${suggest.lo?`<button class="btn btn-outline" data-action="review-sub" data-subject="logic">🧠 邏輯複習 ${suggest.lo}</button>`:''}${suggest.sc?`<button class="btn btn-outline" data-action="review-sub" data-subject="science">🔬 科學複習 ${suggest.sc}</button>`:''}${suggest.zy?`<button class="btn btn-outline" data-action="review-sub" data-subject="zhuyin">ㄅ 注音複習 ${suggest.zy}</button>`:''}</div></section><section class="hero"><div><div class="eyebrow">TWO TRACKS, ONE FUTURE</div><h1>每天探索，<br><em>發現學習的樂趣！</em></h1><p>注音、英文、數學、邏輯、科學，每回合最多 ${grade()==='k'?5:8} 題、沒有倒數壓力；每答對一題，就在球場上推進一個壘包！</p><div class="hero-actions">${subjectsForGrade().slice(0,2).map((sb,i)=>`<button class="btn ${i?'btn-light':'btn-primary'}" data-action="choose-sub" data-subject="${sb}">${SUBJECT_META[sb].icon} 開始${SUBJECT_META[sb].name}</button>`).join('')}</div></div><div class="hero-visual" aria-hidden="true"><div class="spark one">✨</div><div class="baseball-illustration"><div class="eyes"><span></span><span></span></div><div class="smile"></div></div><div class="spark two">⭐</div></div></section>
<div class="section-title"><div><div class="eyebrow">YOUR TRAINING GROUND</div><h2>今天想挑戰哪一科？</h2><p>每一科都能從基礎開始；每題都能按 🔊 聽題目。</p></div><span class="pill">🌱 持續練習最重要</span></div>
<div class="tiles">${subjectsForGrade().map(sb=>{const st=getSubStats(sb),mt=SUBJECT_META[sb];return `<button class="tile ${sb}" data-action="choose-sub" data-subject="${sb}"><span class="tile-icon" aria-hidden="true">${mt.icon}</span><h3>${mt.name}練習</h3><p>${tileText(sb)}</p><div class="tile-foot"><span>${st.num?`已完成 ${st.num} 回合 · 正確率 ${st.accuracy}%`:'準備好打第一球了嗎？'}</span><span class="arrow">→</span></div></button>`}).join('')}</div>
${progressCard()}<section class="hw-entry"><div><strong>✍️ 新增｜手寫練習場</strong><p>手指或 Apple Pencil 描寫 A～Z、英文單字；數學列式計算後，可輸入答案即時驗證。</p></div><button class="btn btn-dark" data-action="nav-handwrite">開始手寫 →</button></section><div class="section-title"><div><h2>練習之外，也要會生活</h2><p>雙軌培養：學科能力 × 自主管理</p></div></div>
<div class="two-col"><section class="card"><h3>🎯 今日小任務</h3>${subjectsForGrade().slice(0,2).map(sb=>`<div class="checkrow"><div class="checkicon">${SUBJECT_META[sb].icon}</div><div><strong>一回合${SUBJECT_META[sb].name}練習</strong><small>${tileText(sb)}</small></div><span aria-hidden="true">${data.sessions.some(s=>s.subject===sb&&new Date(s.date).toDateString()===new Date().toDateString())?'✅':'○'}</span></div>`).join('')}<div class="checkrow"><div class="checkicon">🧠</div><div><strong>一回合邏輯或科學（選做）</strong><small>挑一個有興趣的主題，看完解析再說給大人聽</small></div><span aria-hidden="true">${data.sessions.some(s=>(s.subject==='logic'||s.subject==='science')&&new Date(s.date).toDateString()===new Date().toDateString())?'✅':'○'}</span></div><div class="checkrow"><div class="checkicon">💬</div><div><strong>告訴大人今天學到什麼</strong><small>用自己的話說 1 件事</small></div></div><div class="tipline">💚 這是「建議菜單」，不是每日強制目標。累了可以休息。</div></section><section class="card"><h3>📈 練習紀錄</h3><div class="statrow"><div class="stat"><strong>${today.sessions}</strong><small>今天完成回合</small></div><div class="stat"><strong>${today.questions}</strong><small>今天完成題數</small></div></div><p class="note" style="margin-bottom:0">練習紀錄不是智力測驗或年級評量；我們只看孩子自己的練習狀況，不與其他孩子排名。</p><div class="rowactions"><button data-action="nav-parent" class="btn btn-outline" style="width:100%">給家長看學習報告 →</button></div></section></div>`}

function alphabetPage(){const x=ALPHABET[alphaIndex];return `<button class="back" data-action="alpha-back">← 回到英文練習場</button><div class="pageheading"><div class="eyebrow">ABC · ALPHABET SCHOOL</div><h1>🔡 A～Z 字母發音學習</h1><p>先認大小寫，聽一聽字母，再跟著唸它的例字。點一下就只唸一次。</p></div><div class="alpha-layout"><section class="alpha-main"><div class="alpha-topline"><span>📘 第 ${alphaIndex+1} / 26 個字母 · 真人字母錄音</span><span>${x.upper} ${x.lower}</span></div><div class="alpha-hero"><div class="alpha-symbol" lang="en">${x.upper}<small>${x.lower}</small></div><div><span class="alpha-example-emoji" aria-hidden="true">${x.icon}</span><div class="alpha-word" lang="en">${x.word}<small>${x.meaning}</small></div></div></div><div class="alpha-audio"><button class="btn btn-dark" data-action="alpha-name" aria-label="聽字母 ${x.upper}">🔊 聽字母 ${x.upper}</button><button class="btn btn-outline" data-action="alpha-word" aria-label="聽單字 ${x.word}">🔈 聽單字 ${x.word}</button><button class="btn btn-outline" data-action="alpha-repeat" aria-label="慢速播放單字 ${x.word} 兩次（中間會停頓）">🔁 單字慢速跟讀 ×2（停一秒）</button></div>${speechControls()}<div class="rowactions"><button class="btn btn-outline" data-action="alpha-handwrite">✍️ 手寫練習 ${x.upper}／${x.word}</button></div><div class="alpha-note"><strong>👂 小老師提醒：</strong>先按「聽字母」，再按「聽單字」。聽完後，讓孩子自己跟著念一次就好。</div><div class="alpha-controls"><button class="btn btn-outline" data-action="alpha-prev" ${alphaIndex===0?'disabled':''}>← 上一個</button><button class="btn btn-dark" data-action="alpha-next">${alphaIndex===25?'✅ 完成 A～Z':'下一個字母 →'}</button></div></section><aside class="alpha-side"><section class="card"><h3>🎯 選一個字母</h3><div class="alpha-grid" aria-label="26個英文字母">${ALPHABET.map((a,i)=>`<button class="alpha-item ${i===alphaIndex?'selected':''}" data-action="alpha-select" data-index="${i}" aria-label="選擇字母 ${a.upper}" aria-pressed="${i===alphaIndex}" lang="en">${a.upper}<span>${a.lower}</span></button>`).join('')}</div><p class="note">🎙️ 字母使用真人錄音；單字每次唸一個完整英文單字，音檔已補前後留白；慢速跟讀會在兩次播放之間留停頓。<a href="${AUDIO_BASE}/audio/ATTRIBUTION.txt?v=13" target="_blank" rel="noopener noreferrer">語音來源與授權</a>。</p><div class="rowactions"><button class="btn btn-primary" data-action="alpha-quiz" style="width:100%">${worldInfo().icon} 做 ${data.settings.roundSize||8} 題字母挑戰</button></div></section></aside></div>`}
function choicesForAnswer(answer,level,max=Infinity){const set=new Set([answer]);let iter=0;while(set.size<4&&iter++<140){const span=Math.max(4,Math.ceil(Math.max(8,answer)*(.18+(level-1)*.09)));let n=answer+rand(-span,span);if(n===answer||n<0||n>max)continue;set.add(n)}for(let n=answer+1;set.size<4&&n<=max;n++)set.add(n);for(let n=answer-1;set.size<4&&n>=0;n--)set.add(n);return shuffle([...set]).map(String)}

function patternQuestion(level,forcedKind=null){
 const kind=Number.isInteger(forcedKind)&&forcedKind>=0&&forcedKind<=7?forcedKind:rand(0,7);let main,ans,exp,hint;
 if(level===1){
  if(kind===0){const start=rand(2,15),step=one([2,3,4,5]);ans=start+3*step;main=`找規律：${start}、${start+step}、${start+step*2}、□。下一個數字？`;exp=`每次增加 ${step}，所以是 ${start+step*2}＋${step}＝${ans}。`;hint='先看相鄰兩個數差多少。'}
  else if(kind===1){const step=one([2,3,5]),start=rand(3*step+3,30);ans=start-3*step;main=`找規律：${start}、${start-step}、${start-step*2}、□。下一個數字？`;exp=`每次減少 ${step}，得到 ${ans}。`;hint='看看數字是變大還是變小。'}
  else if(kind===2){const tens=rand(2,8),ones=rand(0,9);ans=tens*10+ones;main=`${tens} 個十和 ${ones} 個一，合起來是多少？`;exp=`${tens}×10＋${ones}＝${ans}。`;hint='一個十等於10。'}
  else if(kind===3){const n=rand(11,89),k=one([1,2,5,10]);ans=n+k;main=`在每格相差 1 的數線上，從 ${n} 往數字較大的方向跳 ${k} 格，會到哪個數？`;exp=`${n}＋${k}＝${ans}。`;hint='往數字較大的方向移動，用加法。'}
  else if(kind===4){const x=rand(2,8),y=x+rand(2,9);ans=y-x;main=`${x}、${y} 中間相差幾？`;exp=`${y}−${x}＝${ans}。`;hint='大的減小的。'}
  else if(kind===5){const a=rand(2,8),b=rand(2,8),c=rand(2,8);ans=a+b+c;main=`三個袋子分別有 ${a}、${b}、${c} 顆球，合計多少顆？`;exp=`${a}＋${b}＋${c}＝${ans}。`;hint='可以先合併兩袋，再加第三袋。'}
  else if(kind===6){const n=rand(3,9),m=one([2,5]);ans=n*m;main=`跳數練習：每次跳 ${m}，跳了 ${n} 次到多少？（從0開始）`;exp=`${n}×${m}＝${ans}。`;hint='數數看重複加了幾次。'}
  else{const n=rand(3,8),t=rand(2,5);ans=n*t;main=`□＋□＋… 共 ${n} 個 ${t}，可以用乘法得到多少？`;exp=`${n}×${t}＝${ans}。`;hint='重複加法也可以改寫成乘法。'}
 }else if(level===2){
  if(kind===0){const a=rand(5,29),d=rand(4,12);ans=a+3*d;main=`找規律：${a}、${a+d}、${a+2*d}、□。`;exp=`公差是 ${d}，所以答案是 ${ans}。`;hint='看每一項固定增加多少。'}
  else if(kind===1){const d=rand(4,11),a=rand(3*d+8,99);ans=a-3*d;main=`找規律：${a}、${a-d}、${a-2*d}、□。`;exp=`每次減 ${d}，下一項是 ${ans}。`;hint='看相鄰兩項相差多少。'}
  else if(kind===2){const h=rand(2,8),t=rand(1,9),u=rand(0,9);ans=h*100+t*10+u;main=`${h} 個百、${t} 個十、${u} 個一，共是多少？`;exp=`${h}×100＋${t}×10＋${u}＝${ans}。`;hint='百位代表100，十位代表10。'}
  else if(kind===3){const n=rand(3,9),d=rand(3,8);ans=n*d;main=`第1排 ${d} 個座位、第2排 ${d} 個……共 ${n} 排，總座位數？`;exp=`${n}×${d}＝${ans}。`;hint='每排一樣多，使用乘法。'}
  else if(kind===4){const a=rand(4,14),b=rand(3,8),c=rand(2,6);ans=a+b*c;main=`先算乘法：${a}＋${b}×${c}＝？`;exp=`${b}×${c}＝${b*c}，再加 ${a}＝${ans}。`;hint='先乘除、後加減。'}
  else if(kind===5){const m=rand(3,8),n=rand(2,7),v=m*n;ans=m;main=`□×${n}＝${v}，□應填多少？`;exp=`${v}÷${n}＝${ans}。`;hint='用除法還原未知數。'}
  else if(kind===6){const a=rand(1,9),b=rand(1,9);ans=a*10+b;main=`${ans} 是幾個一？（不是幾個十）`;exp=`${ans} 就是 ${ans} 個一。`;hint='每個數都可以用「一」作單位。'}
  else{const a=rand(3,8),d=rand(2,8);ans=a*d;main=`${a} 個小朋友，每人跳 ${d} 下，總共跳幾下？`;exp=`${a}×${d}＝${ans}。`;hint='相同組數，用乘法。'}
 }else{
  if(kind===0){const a=rand(13,44),d=rand(7,16);ans=a+4*d;main=`找規律：${a}、${a+d}、${a+2*d}、${a+3*d}、□。`;exp=`每次加 ${d}，下一項 ${ans}。`;hint='先找相鄰的固定差。'}
  else if(kind===1){const a=one([2,3,4]);ans=a*16;main=`倍數規律：${a}、${a*2}、${a*4}、${a*8}、下一個？`;exp=`每次乘2，下一項是 ${a*16}。`;hint='看看是每次加固定數，還是乘固定數。';ans=a*16;}
  else if(kind===2){const h=rand(2,8),t=rand(1,8),u=rand(0,9);ans=h*100+t*10+u;main=`哪個數由 ${h} 個百、${t} 個十、${u} 個一組成？`;exp=`${h*100}＋${t*10}＋${u}＝${ans}。`;hint='按百、十、個位組合。'}
  else if(kind===3){const n=rand(3,9),k=rand(4,9),plus=rand(2,7);ans=n*k+plus;main=`規則是「先乘 ${k}，再加 ${plus}」。輸入 ${n}，輸出多少？`;exp=`${n}×${k}＋${plus}＝${ans}。`;hint='操作順序不能反過來。'}
  else if(kind===4){const b=rand(3,9),c=rand(3,9),a=rand(b*c,b*c+40);ans=a-b*c;main=`運算規律：${a}−${b}×${c}＝？`;exp=`先乘 ${b}×${c}＝${b*c}，再算 ${a}−${b*c}＝${ans}。`;hint='先乘再減。'}
  else if(kind===5){const a=rand(3,9),b=rand(3,7),c=rand(2,6);ans=(a+b)*c;main=`（${a}＋${b}）×${c}＝？`;exp=`括號先算 ${a}＋${b}＝${a+b}，再乘 ${c} 得 ${ans}。`;hint='括號內先算。'}
  else if(kind===6){const a=rand(3,8),b=rand(3,9);ans=a+b;main=`如果 x＋${a}＝${2*a+b}，x 是多少？`;exp=`${2*a+b}−${a}＝${ans}。`;hint='用減法求出未知數。'}
  else{const a=rand(5,12),b=rand(4,10),c=rand(4,7);ans=(a*b)%c;var maxChoice=c-1;main=`${a}×${b} 個球，平均每 ${c} 顆放一袋，最後剩幾顆不滿一袋？`;exp=`${a*b}÷${c} 的餘數是 ${ans}。`;hint='把球按每袋數量分完，剩下的就是餘數。'}
 }
 if(!Number.isFinite(ans)||ans<0) throw Error('invalid pattern generator');
 return {skill:'math-pattern',prompt:'🔍 看懂規律與位值，再選出答案',main,answer:String(ans),choices:choicesForAnswer(ans,level,typeof maxChoice==='number'?maxChoice:Infinity),explain:exp,hint,signature:'pattern-'+level+'-'+kind+'-'+main,concept:'pattern-'+kind,reason:true};
}
function measureQuestion(level,forcedKind=null){
 const kind=Number.isInteger(forcedKind)&&forcedKind>=0&&forcedKind<=7?forcedKind:rand(0,7);let main,ans,exp,hint;
 if(level===1){
  if(kind===0){const a=rand(6,20),b=rand(2,14);ans=a+b;main=`紅色緞帶長 ${a} 公分，藍色緞帶長 ${b} 公分，接起來長幾公分？`;exp=`${a}＋${b}＝${ans} 公分。`;hint='長度接起來要相加。'}
  else if(kind===1){const a=rand(11,30),b=rand(3,a-2);ans=a-b;main=`原有 ${a} 公分的紙帶，剪掉 ${b} 公分，剩幾公分？`;exp=`${a}−${b}＝${ans} 公分。`;hint='剪掉的部分要減掉。'}
  else if(kind===2){const h=rand(7,15),dur=one([1,2,3]);ans=h+dur;main=`使用24小時制：活動 ${h}:00 開始，${dur} 小時後是幾點？`;exp=`${h}＋${dur}＝${ans} 點。`;hint='時數直接往後加。'}
  else if(kind===3){const n=rand(2,5);ans=n*10;main=`${n} 枚 10 元硬幣，一共多少元？`;exp=`${n}×10＝${ans} 元。`;hint='每枚都是10元。'}
  else if(kind===4){const w=rand(2,9);ans=4*w;main=`正方形每邊 ${w} 公分，四條邊共幾公分？`;exp=`周長是 ${w}×4＝${ans} 公分。`;hint='周長是繞著外圍一圈的長度。'}
  else if(kind===5){const a=rand(2,8),b=rand(2,8);ans=a+b;main=`一條繩子長 ${a} 公尺，另一條 ${b} 公尺，合計幾公尺？`;exp=`${a}＋${b}＝${ans} 公尺。`;hint='相同單位才能直接加。'}
  else if(kind===6){const n=rand(2,4);ans=n*60;main=`${n} 小時等於多少分鐘？`;exp=`1 小時是60分鐘；${n}×60＝${ans} 分鐘。`;hint='1 小時＝60 分鐘。'}
  else{const n=rand(3,9),unit=rand(2,6);ans=n*unit;main=`長方形地板有 ${n} 排，每排 ${unit} 塊正方形磁磚，一共幾塊？`;exp=`${n}×${unit}＝${ans} 塊。`;hint='每排一樣多，使用乘法。'}
 }else if(level===2){
  if(kind===0){const a=rand(3,13),b=rand(2,11);ans=2*(a+b);main=`長方形長 ${a} 公分、寬 ${b} 公分，周長是多少？`;exp=`周長＝(${a}＋${b})×2＝${ans} 公分。`;hint='周長是四邊合計。'}
  else if(kind===1){const a=rand(3,12),b=rand(2,9);ans=a*b;main=`長方形長 ${a} 公分、寬 ${b} 公分，面積是多少平方公分？`;exp=`面積＝長×寬＝${a}×${b}＝${ans}。`;hint='數格子可用乘法。'}
  else if(kind===2){const n=rand(2,8);ans=n*100;main=`${n} 公尺等於幾公分？`;exp=`1 公尺＝100 公分，${n} 公尺＝${ans} 公分。`;hint='1公尺等於100公分。'}
  else if(kind===3){const h=rand(8,15),start=one([0,15,30]),dur=one([15,30,45]),m=h*60+start+dur;ans=m%60;main=`活動 ${String(h).padStart(2,'0')}:${String(start).padStart(2,'0')} 開始，${dur} 分鐘後結束。結束時間的「分鐘」是幾？`;exp=`結束於 ${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}，分鐘是 ${ans}。`;hint='先加分鐘，滿60要進一小時。';var fixedChoices=shuffle(['0','15','30','45'])}
  else if(kind===4){const n=rand(2,8),p=one([20,30,40]),paid=n*p+rand(1,5)*10;ans=paid-n*p;main=`買 ${n} 張票，每張 ${p} 元，付 ${paid} 元，找回多少？`;exp=`總價 ${n}×${p}＝${n*p}；找回 ${ans} 元。`;hint='總價用乘法，再從付款中扣除。'}
  else if(kind===5){const n=rand(2,7);ans=n*1000;main=`${n} 公斤等於幾公克？`;exp=`1公斤＝1000公克，所以是 ${ans} 公克。`;hint='1公斤＝1000公克。'}
  else if(kind===6){const total=one([12,16,20,24,28]),n=4;ans=total/4;main=`${total} 顆球的四分之一是多少顆？`;exp=`${total}÷4＝${ans}。`;hint='四分之一是平分四份、拿一份。'}
  else{const h=rand(1,4),m=one([10,20,30,45]);ans=h*60+m;main=`${h} 小時 ${m} 分鐘，總共幾分鐘？`;exp=`${h}×60＋${m}＝${ans} 分鐘。`;hint='先把小時換成分鐘。'}
 }else{
  if(kind===0){const a=rand(7,18),b=rand(4,13);ans=a*b;main=`一塊長方形球場模型長 ${a} 公分、寬 ${b} 公分，面積多少平方公分？`;exp=`${a}×${b}＝${ans} 平方公分。`;hint='面積＝長×寬。'}
  else if(kind===1){const a=rand(8,19),b=rand(5,14);ans=2*(a+b);main=`長方形練習區長 ${a} 公尺、寬 ${b} 公尺，周長幾公尺？`;exp=`(${a}＋${b})×2＝${ans} 公尺。`;hint='周長是四邊總長。'}
  else if(kind===2){const n=one([3,4,5,6,8]),per=rand(3,9),total=n*per;ans=per;main=`一共有 ${total} 顆球，其中 ${1}/${n} 是紅球，紅球有幾顆？`;exp=`把 ${total} 平分 ${n} 份，其中一份 ${total}÷${n}＝${ans}。`;hint='分母代表平均分幾份。'}
  else if(kind===3){const h=rand(8,14),st=one([0,15,30,45]),dur=rand(3,8)*15;ans=dur;const finish=h*60+st+dur;main=`練習從 ${String(h).padStart(2,'0')}:${String(st).padStart(2,'0')} 到 ${String(Math.floor(finish/60)).padStart(2,'0')}:${String(finish%60).padStart(2,'0')}，持續幾分鐘？`;exp=`把結束與開始時間相減，得到 ${dur} 分鐘。`;hint='換算為分鐘再相減。'}
  else if(kind===4){const n=rand(3,12),m=rand(2,8);ans=n*m;main=`棒球館地板長 ${n} 公尺、寬 ${m} 公尺，面積是多少平方公尺？`;exp=`${n}×${m}＝${ans} 平方公尺。`;hint='兩個長度相乘後，面積單位是平方公尺。'}
  else if(kind===5){const each=rand(2,5),n=rand(4,9);ans=each*n*100;main=`買了 ${n} 條繩子，每條 ${each} 公尺，共多少公分？`;exp=`${n}×${each}＝${n*each} 公尺＝${ans} 公分。`;hint='先算總公尺，再乘100。'}
  else if(kind===6){const per=one([2,3,4,5,6]),each=rand(3,9),n=per*each;ans=each;main=`${n} 人平均分成 ${per} 組，每組有多少人？`;exp=`${n}÷${per}＝${ans} 人。`;hint='平均分配使用除法。'}
  else{const x=rand(5,9),y=rand(5,9),z=rand(Math.abs(x-y)+1,Math.min(9,x+y-1));ans=(x+y+z)*2;main=`一個三角形三邊長 ${x}、${y}、${z} 公分，另有一個完全相同的三角形。兩個三角形各自周長相加，一共多少公分？`;exp=`一個三角形周長 ${x}＋${y}＋${z}＝${x+y+z}；兩個合計 ${ans} 公分。`;hint='兩個三角形各自的周長要相加。'}
 }
 if(!Number.isFinite(ans)||ans<0)throw Error('invalid measure generator');
 return {skill:'math-measure',prompt:'📐 把圖形與生活單位轉成數學題',main,answer:String(ans),choices:typeof fixedChoices!=='undefined'?fixedChoices:choicesForAnswer(ans,level),explain:exp,hint,signature:'measure-'+level+'-'+kind+'-'+main,concept:'measure-'+kind,reason:true};
}

function calcQuestion(level){
 if(rand(0,1)===0){let a,b,ans,eq,exp;
  const kind=rand(0,level===1?3:level===2?5:7);
  if(level===1){
    if(kind===0){a=rand(3,18);b=rand(2,8);ans=a+b;eq=`□ ＋ ${a} ＝ ${ans}`;exp=`空格＝${ans}−${a}＝${b}。`;ans=b;}
    else if(kind===1){a=rand(7,19);b=rand(2,a);ans=a-b;eq=`${a} − □ ＝ ${ans}`;exp=`空格＝${a}−${ans}＝${b}。`;ans=b;}
    else if(kind===2){a=rand(2,9);b=rand(2,5);ans=a*b;eq=`${a} 組，每組 ${b} 個，共幾個？`;exp=`${a}×${b}＝${ans}。`}
    else{a=rand(11,30);b=rand(3,8);ans=a-b;eq=`${a} − ${b} ＝ ?`;exp=`${a} 減去 ${b}＝${ans}。`}
  }else if(level===2){
    if(kind===0){a=rand(12,68);b=rand(12,26);ans=a+b;eq=`${a} ＋ ${b} ＝ ?`;exp=`先把個位相加；滿10時才向十位進位。答案 ${ans}。`}
    else if(kind===1){a=rand(50,99);b=rand(18,a-4);ans=a-b;eq=`${a} − ${b} ＝ ?`;exp=`先算個位，再算十位；答案 ${ans}。`}
    else if(kind===2){a=rand(2,9);b=rand(2,9);ans=a*b;eq=`${a} × ${b} ＝ ?`;exp=`${a} 乘以 ${b}＝${ans}。`}
    else if(kind===3){a=rand(2,9);b=rand(2,8);ans=b;eq=`${a*b} ÷ ${a} ＝ ?`;exp=`${a*b} 平均分 ${a} 份，每份 ${b}。`}
    else if(kind===4){a=rand(5,20);b=rand(5,20);ans=a+b;eq=`□ − ${a} ＝ ${b}`;exp=`空格要加回 ${a}，所以 ${a}+${b}＝${ans}。`}
    else{a=rand(5,22);b=rand(2,9);ans=a+2*b;eq=`${a} ＋ ${b} ＋ ${b} ＝ ?`;exp=`${a}+${b}+${b}＝${ans}。`}
  }else{
    if(kind===0){a=rand(120,680);b=rand(80,420);ans=a+b;eq=`${a} ＋ ${b} ＝ ?`;exp=`按個位、十位、百位相加；某一位滿10時向左進位，得到 ${ans}。`}
    else if(kind===1){a=rand(400,900);b=rand(80,a-90);ans=a-b;eq=`${a} − ${b} ＝ ?`;exp=`三位數減法，答案 ${ans}。`}
    else if(kind===2){a=rand(12,35);b=rand(2,9);ans=a*b;eq=`${a} × ${b} ＝ ?`;exp=`把 ${a} 拆成十位與個位，再乘 ${b}，共 ${ans}。`}
    else if(kind===3){a=rand(4,12);b=rand(4,15);ans=b;eq=`${a*b} ÷ ${a} ＝ ?`;exp=`${a*b} 平均分成 ${a} 組，每組 ${ans}。`}
    else if(kind===4){a=rand(30,120);b=rand(3,9);ans=a+2*b;eq=`${a} ＋ 2 × ${b} ＝ ?`;exp=`先乘：2×${b}＝${2*b}，再加 ${a} 得 ${ans}。`}
    else if(kind===5){a=rand(5,19);b=rand(5,18);ans=(a+b)*2;eq=`(${a} ＋ ${b}) × 2 ＝ ?`;exp=`先算括號：${a+b}×2＝${ans}。`}
    else if(kind===6){a=rand(3,9);b=rand(4,13);ans=a*b;eq=`□ ÷ ${a} ＝ ${b}`;exp=`被除數＝${a}×${b}＝${ans}。`}
    else{a=rand(3,9);b=rand(4,9);ans=a*b;eq=`${a*b} ÷ ${b} × ${b} ＝ ?`;exp=`先除後乘，答案是 ${ans}。`}
  }
  return {skill:'math-calc',prompt:'數與運算：一步步找出答案',main:eq,answer:String(ans),choices:choicesForAnswer(ans,level),explain:exp,signature:'calc-extra-'+level+'-'+eq};
 }
let a,b,answer,eq,explain;
if(level===1){if(rand(0,1)){a=rand(2,14);b=rand(1,20-a);answer=a+b;eq=`${a} ＋ ${b} ＝ ?`;explain=`${a} 加上 ${b}，一共有 ${answer}。`}else{a=rand(4,20);b=rand(1,a);answer=a-b;eq=`${a} − ${b} ＝ ?`;explain=`從 ${a} 拿掉 ${b}，還剩 ${answer}。`}}
else if(level===2){const type=rand(0,2);if(type===0){a=rand(18,69);b=rand(8,100-a);answer=a+b;eq=`${a} ＋ ${b} ＝ ?`;explain=`先算十位再算個位，答案是 ${answer}。`}else if(type===1){a=rand(32,99);b=rand(11,a);answer=a-b;eq=`${a} − ${b} ＝ ?`;explain=`把 ${a} 減去 ${b}，得到 ${answer}。`}else{a=one([2,5,10]);b=rand(2,10);answer=a*b;eq=`${a} × ${b} ＝ ?`;explain=`${a} 個 ${b}，就是 ${a} × ${b}＝${answer}。`}}
else{const type=rand(0,3);if(type===0){a=rand(75,399);b=rand(45,250);answer=a+b;eq=`${a} ＋ ${b} ＝ ?`;explain=`把百、十、個位分開計算，可得 ${answer}。`}else if(type===1){a=rand(90,500);b=rand(35,a);answer=a-b;eq=`${a} − ${b} ＝ ?`;explain=`${a} − ${b}＝${answer}。`}else if(type===2){a=rand(3,9);b=rand(3,9);answer=a*b;eq=`${a} × ${b} ＝ ?`;explain=`${a} 組、每組 ${b} 個，所以是 ${answer}。`}else{a=rand(3,9);b=rand(2,9);answer=b;eq=`${a*b} ÷ ${a} ＝ ?`;explain=`${a*b} 個分成 ${a} 等份，每份 ${b} 個。`}}
return {skill:'math-calc',prompt:'算一算，選出正確答案',main:eq,answer:String(answer),choices:choicesForAnswer(answer,level),explain,signature:eq};}
function storyQuestion(level,scoreMode=false){let a,b,ans,main,explain;
const type=rand(0,scoreMode?2:3);
if(level===1){if(scoreMode){if(type===0){a=rand(1,6);b=rand(1,6);ans=a+b;main=`紅隊第一局拿到 ${a} 分，第二局拿到 ${b} 分。紅隊共拿到幾分？`;explain=`${a}＋${b}＝${ans} 分。`}else{a=rand(3,10);b=rand(1,a);ans=a-b;main=`比賽結束，藍隊 ${a} 分，紅隊 ${b} 分。兩隊差幾分？`;explain=`${a}−${b}＝${ans} 分。`}}else{if(type<2){a=rand(2,9);b=rand(2,10);ans=a+b;main=`教練有 ${a} 顆棒球，又拿來 ${b} 顆。現在共有幾顆球？`;explain=`${a}＋${b}＝${ans} 顆。`}else{a=rand(5,18);b=rand(1,a);ans=a-b;main=`球袋裡有 ${a} 顆球，拿出 ${b} 顆練習。球袋裡還有幾顆？`;explain=`${a}−${b}＝${ans} 顆。`}}}
else if(level===2){if(scoreMode){if(type===0){a=rand(3,9);b=rand(2,8);ans=a+b;main=`紅隊第一場得 ${a} 分，第二場得 ${b} 分。兩場共得幾分？`;explain=`${a}＋${b}＝${ans} 分。`}else if(type===1){a=rand(7,15);b=rand(2,a-1);ans=a-b;main=`紅隊得 ${a} 分，藍隊得 ${b} 分。紅隊領先幾分？`;explain=`${a}−${b}＝${ans} 分。`}else{a=one([2,5,10]);b=rand(2,6);ans=a*b;main=`每場比賽都準備 ${a} 張紀錄紙，${b} 場要準備幾張？`;explain=`${a}×${b}＝${ans} 張。`}}else{if(type===0){a=rand(13,45);b=rand(12,35);ans=a+b;main=`球隊有 ${a} 瓶水，家長再送來 ${b} 瓶。共有多少瓶水？`;explain=`${a}＋${b}＝${ans} 瓶。`}else if(type===1){a=rand(26,80);b=rand(6,a-1);ans=a-b;main=`共有 ${a} 張球賽門票，送出 ${b} 張。還剩幾張？`;explain=`${a}−${b}＝${ans} 張。`}else{a=one([2,5,10]);b=rand(3,8);ans=a*b;main=`每盒裝 ${a} 顆練習球，${b} 盒共有幾顆？`;explain=`${a}×${b}＝${ans} 顆。`}}}
else {if(scoreMode){if(type===0){a=rand(3,9);b=rand(3,6);ans=a*b;main=`某球隊參加 ${b} 場比賽，每場都發出 ${a} 瓶水。總共發出幾瓶？`;explain=`${a}×${b}＝${ans} 瓶。`}else if(type===1){a=rand(7,15);b=rand(3,a-1);ans=a-b;main=`兩隊得分分別是 ${a} 和 ${b}。分差是多少？`;explain=`${a}−${b}＝${ans} 分。`}else{a=rand(5,13);b=rand(4,12);ans=a+b;main=`紅隊第一場得 ${a} 分，第二場得 ${b} 分。兩場總共拿到幾分？`;explain=`${a}＋${b}＝${ans} 分。`}}else{if(type===0){a=rand(3,9);b=rand(3,9);ans=a*b;main=`${a} 袋棒球，每袋 ${b} 顆。共有幾顆？`;explain=`${a}×${b}＝${ans} 顆。`}else if(type===1){a=rand(3,9);b=rand(2,9);ans=b;main=`${a*b} 顆棒球平均分給 ${a} 個小組，每組幾顆？`;explain=`${a*b}÷${a}＝${b} 顆。`}else{a=rand(60,130);b=rand(20,50);ans=a+b;main=`球隊已走 ${a} 公尺，再走 ${b} 公尺到球場。總共走了幾公尺？`;explain=`${a}＋${b}＝${ans} 公尺。`}}}
return {skill:scoreMode?'math-score':'math-story',prompt:scoreMode?'🏟️ 分析比賽數字':'⚾ 棒球與生活的數學',main,answer:String(ans),choices:choicesForAnswer(ans,level),explain,signature:main};}

function letterQuestion(used){const pool=ALPHABET.filter(a=>!used.has(a.upper));const x=one(pool.length?pool:ALPHABET);const wrong=shuffle(ALPHABET.filter(a=>a.upper!==x.upper)).slice(0,3);const type=rand(0,2);const data4=shuffle([x,...wrong]);if(type===0)return {skill:'en-letters',prompt:'這個大寫字母對應哪個小寫？',main:x.upper,answer:x.lower,choices:data4.map(a=>a.lower),explain:`${x.upper} 的小寫是 ${x.lower}。例字 ${x.word}（${x.meaning}）。`,signature:x.upper,isEnglish:true,speech:x.upper,showAudio:true};if(type===1)return {skill:'en-letters',prompt:'先聽聲音，再選正確字母',main:'🎧 按下播放，聽聽看',answer:x.upper+' '+x.lower,choices:data4.map(a=>a.upper+' '+a.lower),explain:`你聽到的是字母 ${x.upper}。例字：${x.word}（${x.meaning}）。`,signature:x.upper,isEnglish:true,speech:x.upper,isListening:true};return {skill:'en-letters',prompt:'這個小寫字母對應哪個大寫？',main:x.lower,answer:x.upper,choices:data4.map(a=>a.upper),explain:`${x.lower} 的大寫是 ${x.upper}。例字 ${x.word}（${x.meaning}）。`,signature:x.upper,isEnglish:true,speech:x.upper,showAudio:true}}
const WORD_USE={"1":[["I write with a ___ and fix mistakes with an eraser.","pencil","我用鉛筆寫字，寫錯用橡皮擦修改。"],["I carry books to school in my ___.","bag","我把書放在書包裡帶去學校。"],["We sit on a ___ at school.","chair","我們在學校坐在椅子上。"],["Please open the ___ to enter the room.","door","請打開門才能進入房間。"],["I look through the ___.","window","我透過窗戶往外看。"],["The first meal of the day is ___.","breakfast","一天的第一餐是早餐。"],["The white drink from a cow is ___.","milk","牛奶是從牛身上取得的白色飲料。"],["A ___ is a yellow fruit.","banana","香蕉是一種黃色水果。"],["I wear ___ on my feet.","shoes","我把鞋子穿在腳上。"],["I open my book and ___ a story at bedtime.","read","我睡前打開書閱讀故事。"],["Apples grow on a ___.","tree","蘋果長在樹上。"],["The person whose job is to teach a class is a ___.","teacher","以教書為工作的人是老師。"],["A public green space with trees is a ___.","park","有樹木的公共綠地是公園。"],["The snow feels ___.","cold","雪摸起來很冷。"],["I can ride my ___ to the park.","bike","我能騎腳踏車去公園。"],["The ___ sings in the tree.","bird","鳥兒在樹上唱歌。"],["I call my female parent my ___.","mother","我稱呼我的女性家長為媽媽。"],["On a clear sunny day, the sky looks ___.","blue","晴天時天空看起來是藍色的。"],["I put a ___ on my head.","hat","我把帽子戴在頭上。"],["I raise my ___ to ask a question.","hand","我舉手發問。"]],"2":[["We ___ at the stadium after the bus gets there.","arrive","巴士到站後我們抵達球場。"],["Can I ___ your book for one day?","borrow","我可以借你的書一天嗎？"],["Please ___ the book tomorrow.","return","請明天歸還這本書。"],["Good teammates ___ their ideas and equipment.","share","好隊友會分享想法與裝備。"],["I need to ___ which team to join.","decide","我需要決定加入哪支球隊。"],["Please ___ your homework before dinner.","finish","請在晚餐前完成作業。"],["A good ___ helps us get ready.","plan","好的計畫能幫助我們準備。"],["I feel ___ after a long run.","thirsty","長跑後我覺得口渴。"],["Wear a helmet to stay ___.","safe","戴好安全帽以確保安全。"],["Draw a ___ with three sides.","triangle","畫一個有三條邊的三角形。"],["The library is ___ the school and the park.","between","圖書館在學校與公園之間。"],["We ___ visit Grandma on Sundays.","sometimes","我們有時在星期天看奶奶。"],["He ___ forgets to bring his glove.","never","他從不忘記帶手套。"],["We have no class on the ___.","weekend","我們週末沒有課。"],["It is ___, so we bring sunglasses.","sunny","天氣晴朗，因此我們帶太陽眼鏡。"],["We go to the ___ to read books.","library","我們去圖書館看書。"],["We buy fruit at the ___.","market","我們在市場買水果。"],["Show your ___ before entering.","ticket","入場前請出示票券。"],["Our team wears a blue ___.","uniform","我們的隊伍穿藍色制服。"],["The ___ leads the team.","captain","隊長帶領球隊。"]],"3":[["We need a good ___ to solve the problem.","strategy","我們需要好策略來解題。"],["A team succeeds through ___.","teamwork","團隊藉由合作取得成功。"],["Keeping a promise shows ___.","responsibility","遵守承諾展現責任感。"],["We show ___ when we listen to others.","respect","聽別人說話展現尊重。"],["Learning a new skill takes ___.","patience","學習新技巧需要耐心。"],["She is ___ enough to ask questions.","confident","她有自信提出問題。"],["Scientists ___ changes and write notes.","observe","科學家觀察變化並做筆記。"],["We can ___ tomorrow’s weather.","predict","我們可以預測明天的天氣。"],["Please give ___ for your answer.","evidence","請提供答案的證據。"],["There may be more than one ___.","solution","可能不只一個解決方法。"],["Everyone makes a ___ sometimes. It helps us learn.","mistake","每個人有時都會犯錯，錯誤能幫助我們學習。"],["We track our ___ every week.","progress","我們每週追蹤進度。"],["Set one small ___ before practice.","goal","練習前設定一個小目標。"],["Check the ___ before the game.","schedule","比賽前查看時間表。"],["Parents ___ children to try again.","encourage","家長鼓勵孩子再試一次。"],["We ___ clearly during the game.","communicate","我們在比賽中清楚溝通。"],["Planting trees helps the ___.","environment","種樹有助於環境。"],["We should ___ plastic waste.","reduce","我們應該減少塑膠垃圾。"],["Food gives our bodies ___.","energy","食物提供身體能量。"],["Please ___ the length of the table.","measure","請測量桌子的長度。"]]};
function wordUseQuestion(level,used){
  const pool=WORD_USE[level].map((entry,i)=>({entry,i})).filter(x=>!used.has('use-'+level+'-'+x.i));
  const x=one(pool.length?pool:WORD_USE[level].map((entry,i)=>({entry,i})));
  const [sentence,answer,meaning]=x.entry;
  const words=VOCAB[level].map(v=>v[0]).filter(w=>!confusable(w,answer));
  const opts=shuffle([answer,...shuffle(words).slice(0,3)]);
  return {skill:'en-use',prompt:'🗣️ 依中文意思，選出符合語意的英文單字',main:sentence,second:'中文意思：'+meaning,answer,choices:opts,explain:sentence.replace('___',answer)+' — '+meaning,hint:'先把整句想成生活畫面。中文線索：'+meaning,signature:'use-'+level+'-'+x.i,concept:'use-'+level+'-'+x.i,isEnglish:true,reason:true};
}

function englishQuestion(level,modeName,used){if(modeName==='use')return wordUseQuestion(level,used);if(modeName==='letters')return letterQuestion(used);if(modeName==='sentence'){const fresh=READ[level].filter(t=>!used.has(t[0]));const t=one(fresh.length?fresh:READ[level]);return {skill:'en-sentence',prompt:'讀這一句英文，再回答問題',main:t[0],second:t[1],answer:t[3],choices:shuffle(t[2]),explain:t[4],signature:t[0],isEnglish:true,speech:t[0]}}
const pool=VOCAB[level],fresh=pool.filter(v=>!used.has(v[0]));const entry=one(fresh.length?fresh:pool);
const reverse=modeName==='vocab'&&rand(0,2)===0;
const distractor=shuffle(pool.filter(x=>x[1]!==entry[1]&&!confusable(x[0],entry[0]))).slice(0,3);
const opts=shuffle(reverse?[entry[0],...distractor.map(x=>x[0])]:[entry[1],...distractor.map(x=>x[1])]);
return {skill:modeName==='vocab'?'en-vocab':'en-listening',prompt:modeName==='listening'?'先按播放，聽聽英文，再選意思':reverse?'讀中文，選出正確的英文單字':'這個英文單字是什麼意思？',main:modeName==='listening'?'🎧 聽力接球':reverse?entry[1]:`${entry[2]}  ${entry[0]}`,answer:reverse?entry[0]:entry[1],choices:opts,explain:`「${entry[0]}」是「${entry[1]}」。`,signature:entry[0],isEnglish:true,speech:entry[0],isListening:modeName==='listening'}}

// 透過新的情境、推論及解題步驟提升思考深度；每道題的干擾選項均明確不同於正解。
const DEEP_READ={
1:[
['Amy takes a blue glove to the park. Ben takes a red ball. They want to play catch.','他們最可能要做什麼？','一起丟接球',['一起丟接球','一起煮飯','一起看書','一起游泳'],'play catch 是互相丟接球；手套與球是線索。','從兩個人的用品推測活動。','en-inference'],
['Dad puts the helmet by the door. Sam puts his shoes in his bag. They leave for the game.','他們現在最可能要去哪裡？','去比賽',['去比賽','去睡覺','去圖書館','去吃早餐'],'helmet、shoes 和 leave for the game 都指向比賽。','找出最後一句的目的地。','en-inference'],
['It is hot today. Mia drinks water after practice. She feels better.','Mia 為什麼喝水？','練習後需要補充水分',['練習後需要補充水分','想換新球棒','球場正在下雪','她要畫圖'],'hot、after practice 是線索；喝水讓她比較舒服。','找出前一句的環境線索。','en-inference'],
['Tom has two books. He gives one to his sister. Now they can read together.','誰拿到 Tom 送出的書？','他的姊妹',['他的姊妹','他的教練','他的朋友','他的老師'],'his sister 是他的姊姊或妹妹（英文不分長幼）；give one to 表示送給。','注意 give ... to ... 後面的人。','en-context'],
['The game starts at nine. Lily gets to the field at eight. She has time to warm up.','Lily 先做哪件事？','抵達球場',['抵達球場','開始比賽','吃晚餐','回家睡覺'],'先在八點到球場，九點才開始比賽；warm up 是暖身。','比較 eight 和 nine。','en-order'],
['The red team wins today. The blue team looks sad. The coach says, “We can try again.”','教練希望藍隊怎麼做？','下次繼續努力',['下次繼續努力','永遠不打球','責怪隊友','放棄練習'],'We can try again 是「我們可以再試一次」。','對照教練說的話。','en-inference'],
['Anna is hungry. She eats a banana and drinks milk. Then she goes to school.','Anna 在上學之前做了什麼？','吃了東西並喝牛奶',['吃了東西並喝牛奶','先打棒球','先看電影','先去游泳'],'Then she goes to school，表示前面兩件事先發生。','留意 then 代表接著。','en-order'],
['The dog is under the table. A ball is on the table. The cat is next to the door.','球在哪裡？','桌子上',['桌子上','桌子下','門旁邊','椅子後面'],'on the table 是桌子上，不要和狗的位置混淆。','把 dog、ball、cat 的位置分開。','en-context'],
['Ben finds his friend in the rain. They share one umbrella and walk home.','為什麼他們共用雨傘？','因為正在下雨',['因為正在下雨','因為天空很晴朗','因為棒球不見了','因為他們在游泳'],'in the rain 是正在下雨，share 是分享。','從天氣描述找原因。','en-inference'],
['First, Kai cleans his desk. Next, he reads a book. Last, he goes outside.','Kai 看書後做什麼？','到外面去',['到外面去','再清桌子','再起床','再寫一張卡片'],'Last 指最後；讀書後才去外面。','找出 next 與 last 的先後。','en-order']],
2:[
['The team has a game on Saturday. Rain is expected, so the coach asks everyone to bring an extra shirt. The game is not canceled yet.','哪件事可以從文章確定？','比賽尚未取消',['比賽尚未取消','比賽確定取消','星期日才比賽','每個人都不需要帶衣服'],'not canceled yet 表示「目前還沒有取消」；預報下雨不等於一定停賽。','注意 yet 和 not 的意思。','en-context'],
['Nora wanted a new bat, but her old bat still worked well. She chose to save her money for a school trip.','Nora 為什麼不買新球棒？','想先存錢參加校外旅行',['想先存錢參加校外旅行','因為她沒有球棒','因為比賽已結束','因為她不想上學'],'第二句說她選擇為 school trip 存錢；舊球棒仍能使用。','找出 but 表示的轉折。','en-inference'],
['Ben practices after school on Mondays and Fridays. Today is Wednesday, so he goes home early to finish his project.','今天 Ben 最可能做什麼？','回家完成作業專題',['回家完成作業專題','參加星期五練習','參加星期一練習','直接去比賽'],'Wednesday 不是 Monday 或 Friday，今天要 finish his project。','先確認練習是星期幾。','en-inference'],
['The blue team scored twice in the first inning. The red team scored once. In the second inning, neither team scored.','第二局發生什麼事？','兩隊都沒有得分',['兩隊都沒有得分','藍隊得兩分','紅隊得一分','紅隊獲勝'],'neither team scored 表示兩隊都沒得分；不要把第一局搞混。','留意 first inning / second inning。','en-context'],
['Leo is afraid to ask questions. His coach tells him that asking for help is part of learning. Leo raises his hand during practice.','Leo 最可能學到什麼？','遇到不懂可以主動提問',['遇到不懂可以主動提問','所有問題都很簡單','只能自己猜答案','練習不能說話'],'教練鼓勵他 asking for help，Leo 也舉手了。','由前後行為推測改變。','en-inference'],
['Mia packs her bag before dinner. She puts in her glove, water bottle, and a towel. The next morning, she only needs to take the bag.','Mia 提前整理球袋的好處？','隔天比較從容',['隔天比較從容','可以不去練習','不必喝水','可以少一個隊友'],'前一晚整理，隔天就不用重新找東西。','注意 before dinner 與 next morning。','en-inference'],
['Amy bought a ball for her brother. He already had a glove but no ball. He smiled when he opened the gift.','Amy 的兄弟為什麼開心？','他收到自己缺少的球',['他收到自己缺少的球','他收到第二個手套','他不喜歡禮物','他找不到 Amy'],'already had a glove but no ball 表示缺的是球。','but 後面的資訊是關鍵。','en-context'],
['The class wants to help the school. They can plant a tree or clean the playground. They vote, and most students choose to clean.','最後班級決定做什麼？','清理遊戲場',['清理遊戲場','種樹','準備棒球比賽','去游泳'],'most students choose to clean 表示多數決選擇清理。','留意投票後的決定。','en-order'],
['At practice, the coach explains a new rule. The players listen first, ask questions next, and try it together at the end.','哪個順序符合文章？','先聽說明，再提問，最後嘗試',['先聽說明，再提問，最後嘗試','先嘗試，再睡覺','先提問，再離開','先去買東西，再練習'],'first → next → at the end 是明確的時間順序。','觀察表示順序的三個詞。','en-order'],
['The team lost 3–4, but the players worked together and congratulated the other team. Their coach was proud of their attitude.','教練最看重什麼？','良好的團隊態度',['良好的團隊態度','比分一定要贏','對手必須認輸','自己一個人打完比賽'],'雖然輸球（lost），教練仍為他們的態度（attitude）感到驕傲，重點是態度。','答案不是只看比分。','en-inference']],
3:[
['Judy practiced catching every day, but she still missed many balls. Her coach suggested shorter sessions with more rest. After two weeks, she felt stronger and made fewer mistakes.','哪個結論最符合文章？','適當休息也可能改善練習效果',['適當休息也可能改善練習效果','練得越久一定越好','每天不練才能進步','只要贏球就不會犯錯'],'短練習加休息後失誤變少，但故事並不能證明對每個人都必然有效。','分辨故事觀察和絕對化的說法。','en-inference'],
['The library is closed on Sundays. Leo planned to borrow a book on Sunday, but he checked the schedule on Saturday. He went to the library that afternoon instead.','Leo 在星期六去了圖書館的原因？','發現星期日不開放',['發現星期日不開放','星期六要參加比賽','星期日他已經借到書','星期六有棒球課'],'closed on Sundays 是他改變計畫的原因。','找出使計畫改變的資訊。','en-inference'],
['On Tuesday, the team practiced throwing. On Thursday, they watched a game video and discussed mistakes. On Saturday, they tried those ideas in a friendly game.','團隊在星期四做什麼？','看影片並討論錯誤',['看影片並討論錯誤','進行友誼賽','練習投球','休息並旅行'],'Thursday 的行動是 watched a game video and discussed mistakes。','建立 Tuesday→Thursday→Saturday 的時間線。','en-order'],
['Mina has one hour before dinner. She needs 20 minutes for homework, 15 minutes for reading, and 10 minutes to pack her bag. She decides to do the important tasks first.','哪一項最符合 Mina 的計畫？','先完成必須做的事，仍有剩餘時間',['先完成必須做的事，仍有剩餘時間','三件事要超過一小時','她只能做一件事','她沒有任何空閒時間'],'20＋15＋10＝45 分鐘，距離60分鐘還剩15分鐘。','跨科思考：把英文資訊變成數學算式。','en-inference'],
['The red team had fewer hits, but it scored more runs. The coach explained that a hit does not always lead to a run.','哪一個推論合理？','安打數多不代表得分一定多',['安打數多不代表得分一定多','得分多一定安打多','安打數跟棒球無關','兩隊得分一定相同'],'fewer hits but more runs 說明兩種數字不一定同步。','比較 hits 與 runs，避免因果誤判。','en-inference'],
['After school, Alan wanted to play games. He noticed that he had a test the next day, so he reviewed his notes for twenty minutes first. Then he enjoyed his free time.','Alan 展現了哪一種能力？','安排優先順序與自我管理',['安排優先順序與自我管理','完全不休息','跳過考試','把作業交給同學'],'他先讀書再休閒，展現管理時間而非完全禁止娛樂。','注意 first 與 then。','en-inference'],
['A poster says: "Bring a water bottle. Meet at the field at 8:30. Practice starts at 9:00." Ken arrives at the field at 8:45 with water.','Ken 哪一項沒有遵照海報？','集合時間',['集合時間','有帶水','練習地點','練習開始時間'],'8:45 比規定集合8:30晚15分鐘，但練習9:00還沒開始。','分別比較 meet 與 starts。','en-context'],
['The girls designed two practice plans. Plan A repeats the same easy task. Plan B mixes easy and difficult tasks and includes rest. They want to compare their progress after a month.','哪個做法比較能公平比較兩個計畫？','用一致標準記錄兩組進步',['用一致標準記錄兩組進步','只記錄計畫 B 的好成績','每次偷偷更改計分方式','只問最厲害的人'],'不同計畫比較時，需要使用相同的評量標準。','推理：如何確保比較不偏心？','en-inference'],
['The coach asked the players to share feedback. Ben said the drill was confusing, while Amy said she needed more time. The coach changed the instructions and gave everyone another try.','教練主要回應了哪兩項問題？','說明不清楚和時間不足',['說明不清楚和時間不足','球場太大和天氣太冷','球員沒有帶球棒','比賽沒有裁判'],'confusing instructions 對應說明不清；needed more time 對應時間。','結合兩個人提出的不同需求。','en-context'],
['The team can use either the school field or the community field. The school field is closer, but it closes at 5:00. Practice ends at 5:30. The community field stays open until 7:00.','哪個場地較適合這次練習？','社區球場',['社區球場','學校球場','兩個都一定不能用','只要比較近就選學校球場'],'練習5:30結束，學校球場5:00已關閉；社區球場7:00才關。','把兩個條件與結束時間一起比較。','en-inference']]
};

// ===== v31：英文、邏輯、注音題庫擴充與第 4 級 =====
VOCAB[4]=[["tournament","錦標賽","🏆"],["champion","冠軍","🥇"],["defense","防守","🛡️"],["offense","進攻","⚔️"],["referee","裁判","🧑‍⚖️"],["stadium","體育場","🏟️"],["audience","觀眾","👥"],["applause","掌聲","👏"],["determined","下定決心的","💪"],["nervous","緊張的","😬"],["proud","驕傲的","😊"],["disappointed","失望的","😞"],["practice","練習","🏃"],["accurate","準確的","🎯"],["approximately","大約","≈"],["calculate","計算","🧮"],["compare","比較","⚖️"],["conclusion","結論","📌"],["describe","描述","🗣️"],["discuss","討論","💬"],["experience","經驗","🧭"],["improve","改善","📈"],["increase","增加","⬆️"],["decrease","減少","⬇️"],["knowledge","知識","📚"],["necessary","必要的","❗"],["opinion","意見","💭"],["organize","整理；安排","🗂️"],["possible","可能的","🤔"],["prefer","比較喜歡","👍"],["protect","保護","🛡️"],["recognize","認出","👀"],["support","支持","🤝"],["suggest","建議","💡"],["temperature","溫度","🌡️"],["tradition","傳統","🏮"],["unusual","不尋常的","❓"],["volunteer","志工","🙋"],["whisper","低聲說","🤫"],["wonder","想知道","✨"]];
READ[1].push(
 ['The cat is on the bed.','貓在哪裡？',['床上','桌上','門外','樹上'],'床上','on the bed 是「在床上」。'],
 ['I like green apples.','我喜歡什麼？',['綠色蘋果','紅色香蕉','藍色帽子','白色牛奶'],'綠色蘋果','green 是綠色，apples 是蘋果。'],
 ['Sam has two hats.','Sam 有幾頂帽子？',['兩頂','一頂','三頂','沒有'],'兩頂','two 是「二」。'],
 ['We play in the park.','我們在哪裡玩？',['公園','學校','醫院','市場'],'公園','park 是公園。'],
 ['Mom can sing.','媽媽會做什麼？',['唱歌','游泳','跑步','畫畫'],'唱歌','sing 是唱歌。'],
 ['The ball is big and red.','球是什麼樣子？',['又大又紅','又小又藍','又長又白','又熱又黑'],'又大又紅','big 是大的，red 是紅色。']);
READ[2].push(
 ['Tom forgot his glove, so he borrowed one from Ben.','Tom 為什麼向 Ben 借手套？',['他忘了帶手套','手套太大','Ben 要送他','手套是新的'],'他忘了帶手套','forgot 是「忘記」；so 表示結果。'],
 ['It is cloudy today, but it is not raining.','今天天氣如何？',['多雲但沒下雨','下大雨','晴朗無雲','下雪'],'多雲但沒下雨','cloudy 多雲；but 後面說沒有下雨。'],
 ['Our team practices every Tuesday and Thursday.','球隊哪幾天練習？',['星期二和星期四','星期一和星期三','星期六和星期日','每天'],'星期二和星期四','Tuesday 星期二，Thursday 星期四。'],
 ['Lily is taller than Mia.','誰比較高？',['Lily','Mia','一樣高','不知道'],'Lily','taller than 是「比……高」。'],
 ['Please finish your homework before you watch TV.','看電視前要先做什麼？',['完成作業','吃晚餐','洗澡','睡覺'],'完成作業','before 是「在……之前」。'],
 ['The library opens at nine in the morning.','圖書館幾點開門？',['早上九點','晚上九點','早上七點','中午十二點'],'早上九點','at nine in the morning 是早上九點。']);
READ[3].push(
 ['Even though Ben was tired, he kept running until the end of the race.','Ben 累了之後怎麼做？',['繼續跑到終點','馬上停下來','回家睡覺','換別人跑'],'繼續跑到終點','even though 雖然；kept running 是「一直跑」。'],
 ['If it rains tomorrow, the game will be moved to Sunday.','如果明天下雨會怎樣？',['比賽改到星期日','比賽取消不打','比賽照常','比賽提早'],'比賽改到星期日','if 如果；be moved to 改到。'],
 ['Most students in my class prefer basketball, but I prefer baseball.','說話者比較喜歡什麼？',['棒球','籃球','足球','游泳'],'棒球','but 表示轉折；I prefer baseball。'],
 ['The coach reminded us to warm up carefully before exercise.','教練提醒大家做什麼？',['運動前小心做暖身','早點回家','多吃點心','買新球棒'],'運動前小心做暖身','warm up 暖身；before exercise 運動之前。'],
 ['Neither Amy nor Tom brought an umbrella, so they shared a raincoat.','誰帶了雨傘？',['兩個人都沒帶','只有 Amy','只有 Tom','兩個人都帶了'],'兩個人都沒帶','neither... nor... 是「兩者都不」。'],
 ['After losing the first game, the team watched videos to learn from their mistakes.','球隊輸球後做了什麼？',['看影片從錯誤中學習','解散球隊','責怪裁判','不再練習'],'看影片從錯誤中學習','learn from their mistakes 從錯誤中學習。']);
READ[4]=[
 ['The tournament was postponed because the field was flooded after the typhoon.','錦標賽為什麼延期？',['颱風後球場淹水','裁判生病','觀眾太少','球隊遲到'],'颱風後球場淹水','postponed 延期；flooded 淹水。'],
 ['Although our team had fewer hits, we won because we made no errors on defense.','球隊為什麼能贏？',['防守沒有失誤','安打比較多','對手棄權','比賽下雨'],'防守沒有失誤','although 雖然；no errors on defense 防守零失誤。'],
 ['The pitcher was nervous at first, but the applause from the audience made him confident.','什麼讓投手變得有自信？',['觀眾的掌聲','教練的處罰','下雨','換球衣'],'觀眾的掌聲','applause 掌聲；audience 觀眾。'],
 ['Approximately three hundred volunteers helped clean the stadium after the championship.','大約多少志工幫忙清理？',['三百人','三十人','三千人','三人'],'三百人','approximately 大約；three hundred 三百。'],
 ['She was disappointed with the result, yet she decided to practice harder instead of giving up.','她對結果失望後決定怎麼做？',['更努力練習','放棄','換別的運動','休息一整年'],'更努力練習','instead of giving up 而不是放棄。'],
 ['The umpire explained that the runner was out because a fielder tagged him with the ball before he reached the base.','跑者為什麼出局？',['到壘前被持球防守員觸碰','跑太慢','沒戴頭盔','跑錯方向'],'到壘前被持球防守員觸碰','umpire 是棒球裁判；tagged him with the ball 指持球觸碰跑者。'],
 ['To calculate the batting average, divide the number of hits by the number of at-bats.','怎麼算打擊率？',['安打數除以打數','打數除以安打數','安打數加打數','安打數乘以打數'],'安打數除以打數','divide A by B 是 A÷B。'],
 ['UV-blocking sunglasses can help protect your eyes in strong sunlight.','強烈陽光下，什麼有助於保護眼睛？',['戴抗UV太陽眼鏡','閉上眼睛','只在晚上打','多喝汽水'],'戴抗UV太陽眼鏡','UV-blocking 抗紫外線的；can help 表示可以幫助，不是保證完全防護。'],
 ['Many fans whispered nervously as the batter stepped into the box with the bases loaded.','滿壘時打者上場，球迷如何說話？',['緊張地低聲說話','開心地大聲唱歌','生氣地喊叫','完全沒有說話'],'緊張地低聲說話','whispered nervously 是緊張地低聲說話；as 在這裡表示同時發生，不直接說明原因。'],
 ['I wonder whether our team will keep the tradition of bowing to the fans after every game.','說話者想知道什麼？',['球隊會不會保持向球迷鞠躬的傳統','比賽幾點開始','誰是冠軍','球票多少錢'],'球隊會不會保持向球迷鞠躬的傳統','wonder whether 想知道是否；tradition 傳統。']];
WORD_USE[1].push(["I close one ___ and look.","eye","我閉上一隻眼睛看。"],["The soup is very ___, so I let it cool.","hot","湯很熱，所以我先讓它放涼。"],["A ___ can fly in the sky.","bird","鳥可以在天上飛。"],["I drink ___ every morning.","milk","我每天早上喝牛奶。"]);
WORD_USE[2].push(["We need a ___ to take the train.","ticket","搭火車需要票。"],["Draw a ___ with four equal sides.","square","畫一個四邊一樣長的正方形。"],["I am ___ after the long game, so I need food.","hungry","比賽很久之後我很餓，需要吃東西。"],["Doctors and nurses work in a ___.","hospital","醫生和護士在醫院工作。"],["The ___ is sunny and warm today.","weather","今天天氣晴朗溫暖。"]);
WORD_USE[3].push(["Eat vegetables for good ___.","nutrition","吃蔬菜可以有好的營養。"],["Please ___ the answer in your own words.","explain","請用自己的話解釋答案。"],["She did an ___ to see if plants need light.","experiment","她做了一個實驗看植物需不需要光。"],["We ___ bottles and paper every week.","recycle","我們每週回收瓶子和紙。"],["His hard work led to a great ___.","achievement","他的努力帶來很棒的成就。"]);
WORD_USE[4]=[["The ___ checks for fouls in the basketball game.","referee","裁判會判斷籃球比賽中的犯規。"],["Our team won the ___ and became the champion.","tournament","我們隊贏得錦標賽，成為冠軍。"],["The ___ cheered loudly when the game started.","audience","比賽開始時觀眾大聲歡呼。"],["Good ___ stops the other team from scoring.","defense","好的防守能讓對手無法得分。"],["She felt ___ before her first big game.","nervous","她在第一場大比賽前覺得很緊張。"],["Please ___ your bag before practice.","organize","練習前請整理好你的包包。"],["It is ___ to drink water on a hot day.","necessary","熱天喝水是必要的。"],["I ___ baseball to soccer.","prefer","我比較喜歡棒球勝過足球。"],["A ___ helped clean the stadium for free.","volunteer","一位志工免費幫忙打掃球場。"],["Wear a helmet to ___ your head.","protect","戴頭盔保護頭部。"],["The stadium holds ___ twenty thousand people.","approximately","這座體育場大約可容納兩萬人。"],["We should ___ different ways before we choose one.","compare","選擇之前我們應該比較不同的方法。"]];
DEEP_READ[1].push(
 ['Kai has a red bat. Ben has a blue bat. Kai gives his bat to Ben for one day.','今天誰有兩支球棒？','Ben',['Ben','Kai','教練','沒有人'],'Ben 本來有一支，Kai 又借他一支。','數一數每個人手上的球棒。','en-inference'],
 ['The sky is dark. Mia hears thunder. She goes inside.','Mia 為什麼進到屋裡？','因為打雷了',['因為打雷了','因為肚子餓','因為天氣很熱','因為要睡覺'],'thunder 是打雷，打雷要進到室內。','找出 Mia 聽到什麼。','en-inference'],
 ['First, Tom puts on his shoes. Then he takes his glove. Last, he runs to the field.','Tom 最後做什麼？','跑去球場',['跑去球場','穿鞋子','拿手套','吃早餐'],'Last 表示最後。','找出 last。','en-order']);
DEEP_READ[2].push(
 ['Amy wanted to buy a ball for 50 dollars. She had 30 dollars, so she saved money for two more weeks.','Amy 為什麼要再存兩週的錢？','她的錢不夠買球',['她的錢不夠買球','球賣完了','她不想要球','店休息'],'她只有 30 元，球要 50 元。','比較她有的錢和球的價錢。','en-inference'],
 ['The game started at 2:00. It lasted three hours because of a long rain delay.','比賽大約幾點結束？','五點',['五點','三點','兩點','七點'],'2 點開始、打了 3 小時，所以 5 點結束。','把開始時間加上比賽時間。','en-context'],
 ['Leo hit the ball far, but the center fielder caught it before it touched the ground.','Leo 這一打結果如何？','被接殺出局',['被接殺出局','全壘打','安打上壘','保送'],'球落地前被接住就是接殺。','注意 before it touched the ground。','en-inference']);
DEEP_READ[3].push(
 ['Nora practiced piano for ten minutes on six days each week, while her brother practiced for sixty minutes only on Sundays. They each practiced for one hour a week. After a month, Nora improved more.','這個故事最可能想說明什麼？','分散到多天練習可能有幫助',['分散到多天練習可能有幫助','練越久一定越好','只要星期日練就好','練習沒有用'],'兩人每週都練60分鐘；故事中的Nora分散到六天練習，進步較多，但這個例子不能保證每個人都會得到同樣結果。','比較兩人練習的方式和結果。','en-inference'],
 ['The scoreboard showed 3–3 in the ninth inning. The home team scored one run in the bottom of the ninth, and the fans cheered from their seats.','比賽結果是什麼？','主隊以 4 比 3 獲勝',['主隊以 4 比 3 獲勝','客隊以 4 比 3 獲勝','雙方平手','比賽延期'],'3 比 3 時主隊下半局再得 1 分，再見勝利。','原本平手，再加一分。','en-context']);
DEEP_READ[4]=[
 ['The Hawks had lost their last game 2–5. Before the next game, the coach changed the batting order. The new leadoff hitter reached base three times, and the Hawks won 6–5.','下一場比賽前後，文章提到哪項調整與表現？','教練調整打序，新的第一棒多次上壘',['教練調整打序，新的第一棒多次上壘','對手主動投降','比賽因雨提前結束','裁判判錯'],'教練在下一場比賽前調整打序，新的第一棒上壘三次；文章未證明勝利只由這項調整造成。','找出比賽中「改變」的是什麼。','en-inference'],
 ['A survey asked 40 students about their favorite sport. Half chose baseball, a quarter chose basketball, and the rest chose swimming.','選游泳的有幾人？','10 人',['10 人','20 人','5 人','30 人'],'一半 20 人選棒球，四分之一 10 人選籃球，剩下 40−20−10＝10 人選游泳。','把英文的 half、quarter 換成數字。','en-context'],
 ['Kevin believed that lucky socks helped him hit home runs. His sister recorded ten games with the socks and ten games without them. He hit the same number of home runs in each group.','妹妹的紀錄說明了什麼？','這20場紀錄未顯示幸運襪增加全壘打',['這20場紀錄未顯示幸運襪增加全壘打','襪子讓他打更多全壘打','他應該每天換襪子','妹妹不喜歡棒球'],'這20場中，穿與不穿各10場，兩組全壘打數相同。紀錄沒有顯示增加效果，但不能證明任何情況下都沒有影響。','比較「有穿」和「沒穿」的結果。','en-inference'],
 ['Before the championship, the players organized a volunteer day to clean the beach. Their coach said that teamwork on the field starts with helping each other off the field.','教練想表達什麼？','場外互相幫忙，也能培養場上的團隊合作',['場外互相幫忙，也能培養場上的團隊合作','打掃比練球重要','冠軍賽不重要','海灘比球場好玩'],'on the field 球場上；off the field 球場外。','注意教練說的話。','en-inference'],
 ['The game was scheduled for Saturday, but heavy rain was predicted. The league decided to play on Friday night instead, one day earlier.','比賽最後改到什麼時候？','星期五晚上',['星期五晚上','星期六','星期日','下星期六'],'instead 表示改成；one day earlier 提早一天。','找出 instead 後面的時間。','en-context'],
 ['Maya noticed that her throws were inaccurate when she was tired. She suggested that the team take short breaks during long practices, and the coach agreed to try it for two weeks.','教練同意做什麼？','試兩週在長時間練習中短暫休息',['試兩週在長時間練習中短暫休息','取消所有練習','只讓 Maya 休息','每天練更久'],'suggested 建議；agreed to try 同意試試。','找出 Maya 的建議和教練的回應。','en-order']];
// --- 邏輯題庫擴充 ---
ODD_BANK.push(
 {l:1,q:'哪一個不是交通工具？',a:'冰箱',o:['公車','火車','腳踏車','冰箱'],e:'公車、火車、腳踏車都可以載人移動；冰箱是電器。'},
 {l:1,q:'哪一個不是身體的部位？',a:'鉛筆',o:['手','腳','眼睛','鉛筆'],e:'手、腳、眼睛都是身體部位；鉛筆是文具。'},
 {l:1,q:'哪個數字的個位不是0？',a:'9',o:['10','20','30','9'],e:'10、20、30 的個位都是0；9的個位是9。'},
 {l:1,q:'哪一個不是棒球用品？',a:'泳鏡',o:['球棒','手套','頭盔','泳鏡'],e:'泳鏡是游泳用的。'},
 {l:1,q:'哪一個不是水果？',a:'紅蘿蔔',o:['西瓜','芒果','葡萄','紅蘿蔔'],e:'紅蘿蔔是蔬菜（植物的根）。'},
 {l:2,q:'哪一個是一天中的時段，而不是「星期幾」？',a:'中午',o:['星期一','星期二','星期五','中午'],e:'星期一、二、五是星期幾；中午是一天中的時段。'},
 {l:2,q:'哪一個不是昆蟲？',a:'蜘蛛',o:['螞蟻','蜜蜂','蝴蝶','蜘蛛'],e:'昆蟲有 6 隻腳；蜘蛛有 8 隻腳，不是昆蟲。'},
 {l:2,q:'哪一個數字的個位不是5？',a:'14',o:['5','15','25','14'],e:'5、15、25 個位數都是 5，而且都是 5 的倍數；14 不是。'},
 {l:2,q:'哪一個不是固體？',a:'果汁',o:['石頭','冰塊','木頭','果汁'],e:'果汁是液體，其他是固體。'},
 {l:2,q:'哪一個打擊結果不記為安打？',a:'界外球',o:['一壘安打','二壘安打','全壘打','界外球'],e:'前三個都是安打；界外球不算安打。'},
 {l:3,q:'哪一個不是整數的平方數？',a:'27',o:['16','36','49','27'],e:'16＝4×4、36＝6×6、49＝7×7 都是「平方數」；27 不是。'},
 {l:3,q:'哪一個不是爬蟲類？',a:'青蛙',o:['烏龜','蛇','蜥蜴','青蛙'],e:'青蛙是兩棲類；烏龜、蛇、蜥蜴是爬蟲類。'},
 {l:3,q:'哪一個通常不列為再生能源？',a:'煤',o:['太陽能','風力','水力','煤'],e:'太陽能、風力、水力通常列為再生能源；煤是形成需很長時間的化石燃料，屬非再生能源。'},
 {l:3,q:'哪一個不是守備的「內野」位置？',a:'右外野手',o:['一壘手','二壘手','游擊手','右外野手'],e:'右外野手守外野。'},
 {l:3,q:'哪一個不是長度單位？',a:'公斤',o:['公分','公尺','公里','公斤'],e:'公分、公尺、公里量長度；公斤量重量。'},
 {l:4,q:'哪一個不是質數？',a:'21',o:['2','3','5','21'],e:'2、3、5 都是質數（只有 1 和自己兩個因數）；21＝3×7 不是質數。'},
 {l:4,q:'哪一個不是行星？',a:'月球',o:['金星','火星','土星','月球'],e:'月球是地球的衛星，不是行星。'},
 {l:4,q:'哪個詞表示數量變多？',a:'增加',o:['減少','降低','縮小','增加'],e:'減少、降低、縮小都是變少；增加是變多。'},
 {l:4,q:'哪一個分數不等於二分之一？',a:'2/5',o:['1/2','2/4','3/6','2/5'],e:'1/2、2/4、3/6 都等於二分之一；2/5 不是。'},
 {l:4,q:'哪一個不是哺乳類？',a:'企鵝',o:['蝙蝠','鯨魚','海豚','企鵝'],e:'蝙蝠、鯨魚、海豚是哺乳類；企鵝是鳥類。'}
);
RULES_BANK.push(
 {l:1,q:'打出的飛球越過一壘或三壘後，第一次落在界外地區且未被接住，叫做什麼？',a:'界外球',o:['界外球','全壘打','安打','三振'],e:'這裡的飛球越過一壘或三壘後，首次落在界外地區，判為界外球；內野落地後再滾動的球，還要看球的位置與觸碰情況。'},
 {l:1,q:'防守時，誰站在本壘後面接投手的球？',a:'捕手',o:['捕手','投手','一壘手','中外野手'],e:'捕手蹲在本壘後方接球。'},
 {l:1,q:'棒球比賽一隊上場守備有幾個人？',a:'9 人',o:['9 人','5 人','11 人','3 人'],e:'棒球守備是 9 人：投手、捕手、4 位內野手、3 位外野手。'},
 {l:2,q:'一局上半，紅隊已經兩出局，打者擊出高飛球被接殺，接下來會怎樣？',a:'三出局，換邊',o:['三出局，換邊','打者上一壘','跑者全部得分','比賽結束'],e:'兩出局再一個出局就是三出局，攻守交換。'},
 {l:2,q:'「如果下雨，練習就改在室內。」今天練習在室外，可以知道什麼？',a:'今天沒有下雨',o:['今天沒有下雨','今天有下雨','明天會下雨','練習取消了'],e:'下雨一定在室內；在室外就表示沒有下雨。'},
 {l:2,q:'小紀比大顏早到，二弟比小紀早到。誰最早到？',a:'二弟',o:['二弟','小紀','大顏','無法判斷'],e:'二弟 → 小紀 → 大顏，二弟最早。'},
 {l:3,q:'「所有的投手都會做伸展。」浣熊二哥有做伸展，他一定是投手嗎？',a:'不一定，其他人也可能做伸展',o:['不一定，其他人也可能做伸展','一定是投手','一定不是投手','他不會投球'],e:'「投手都會伸展」不代表「會伸展的都是投手」。'},
 {l:3,q:'小佑、小紀、大顏三人中只有一人帶了球。小佑說：「不是我帶的。」小紀說：「是大顏帶的。」如果兩人都說真話，誰帶了球？',a:'大顏',o:['大顏','小佑','小紀','無法判斷'],e:'小紀說真話：是大顏帶的；也符合小佑的話。'},
 {l:3,q:'「只要得分比對手多就贏。」紅隊和藍隊都得 4 分，比賽結果是？',a:'平手（或需要延長賽）',o:['平手（或需要延長賽）','紅隊贏','藍隊贏','兩隊都輸'],e:'兩隊分數一樣，沒有人比較多，所以不是誰贏。'},
 {l:3,q:'一隊有 9 人，每人都要和隊友各擊掌一次，一共擊掌幾次？',a:'36 次',o:['36 次','81 次','18 次','9 次'],e:'8＋7＋6＋5＋4＋3＋2＋1＝36 次（每兩人只算一次）。'},
 {l:4,q:'「如果 A，則 B」成立。下列哪一句一定也成立？',a:'如果不是 B，就不是 A',o:['如果不是 B，就不是 A','如果 B，就是 A','如果不是 A，就不是 B','A 和 B 沒有關係'],e:'這叫「逆否命題」，和原句一定同真。例：下雨就延期 → 沒延期就沒下雨。'},
  {l:4,q:'四個人賽跑：二弟不是第一；大王在二弟後面；小佑在大王後面；雞柳條不是最後。誰是第一名？',a:'雞柳條',o:['雞柳條','二弟','大王','小佑'],e:'二弟不是第一，大王和小佑又都在二弟後面，所以第一名只能是雞柳條（順序：雞柳條、二弟、大王、小佑）。',h:'先排二弟、大王、小佑三個人的先後。'},
  {l:4,q:'三個盒子分別裝紅球、藍球、紅藍混合，但三個標籤全部貼錯了。最少要拿出幾顆球來看，就能把標籤全部改對？',a:'1 顆',o:['1 顆','2 顆','3 顆','0 顆'],e:'從貼著「混合」的盒子拿 1 顆：它一定不是混合，所以拿到紅球就是紅球盒；剩下兩盒標籤也都錯，就能推出全部。',h:'標籤「一定」是錯的，這是很重要的線索。'},
 {l:4,q:'一場預定9局的比賽，主隊每個實際進攻的半局都得1分，客隊只在第5局得6分。正常進行到第9局時，最後比數是？',a:'主隊 8 比 6 獲勝',o:['主隊 8 比 6 獲勝','主隊 9 比 6 獲勝','客隊獲勝','平手'],e:'主隊後攻。前 8 局主隊已得 8 分、客隊 6 分；第 9 局上半客隊沒得分，主隊已經領先，第 9 局下半不用打，所以是 8 比 6。',h:'主隊是後攻的那一隊，想想第 9 局下半還需要打嗎？'}
);
// --- 注音語詞擴充 ---
ZY_WORDS.push(['衣服','ㄧ ㄈㄨˊ','👕'],['眼鏡','ㄧㄢˇ ㄐㄧㄥˋ','👓'],['花生','ㄏㄨㄚ ㄕㄥ','🥜'],['蛋糕','ㄉㄢˋ ㄍㄠ','🎂'],['電視','ㄉㄧㄢˋ ㄕˋ','📺'],['草莓','ㄘㄠˇ ㄇㄟˊ','🍓'],['鋼琴','ㄍㄤ ㄑㄧㄣˊ','🎹'],['醫生','ㄧ ㄕㄥ','🧑‍⚕️'],['公車','ㄍㄨㄥ ㄔㄜ','🚌'],['獅子','ㄕ ˙ㄗ','🦁'],['老鷹','ㄌㄠˇ ㄧㄥ','🦅'],['捕手','ㄅㄨˇ ㄕㄡˇ','🧤'],['投手','ㄊㄡˊ ㄕㄡˇ','⚾'],['全壘打','ㄑㄩㄢˊ ㄌㄟˇ ㄉㄚˇ','💥']);

CONFUSE.push(['nervous','proud','disappointed','determined','unusual','possible','accurate','necessary'],['compare','discuss','organize','describe','suggest','improve','calculate','recognize','protect','support'],['audience','referee','champion','volunteer'],['milk','water'],['nutrition','energy','balance'],['explain','communicate','identify'],['recycle','reduce'],['achievement','result','opportunity','challenge','progress'],['tournament','tradition','experience']);


// ===== v32：三個世界（棒球／公主城堡／可愛動物），名稱與題目跟著球員風格切換 =====
function currentWorld(){const t=activeProfile().theme;return ['princess','animals','space'].includes(t)?t:'baseball'}
const WORLD_INFO={
 baseball:{name:'小小探索學院',sub:'LEARN × EXPLORE',icon:'⚾',footer:'⚾ 為孩子設計的棒球學習場',step:'STEP 01 · FIRST BASE',go:'上場'},
 princess:{name:'小小探索學院',sub:'LEARN × EXPLORE',icon:'👑',footer:'👑 為小公主設計的魔法學習城堡',step:'STEP 01 · 第一道魔法',go:'出發'},
 animals:{name:'小小探索學院',sub:'LEARN × EXPLORE',icon:'🐰',footer:'🐰 為小朋友設計的森林學習樂園',step:'STEP 01 · 第一站',go:'出發'}};
const worldInfo=()=>WORLD_INFO[currentWorld()];
// 得分方式：棒球是壘包和分數；公主是星星換皇冠；動物是腳印換紅蘿蔔
const WORLD_SCORE={
 princess:{unit:'顆星星',big:'頂皇冠',bigIcon:'👑',slot:'⭐',empty:'☆',line:c=>`今天答對 <b>${c}</b> 題＝收集 <b>${c}</b> 顆星星`,next:n=>`再答對 ${n} 題，就能換到一頂皇冠！`,rule:'每答對 1 題得到 1 顆星星，集滿 4 顆換 1 頂皇冠。',today:'今日皇冠',round:c=>`✨ 這回合收集了 ${c} 顆星星`},
 animals:{unit:'步',big:'根紅蘿蔔',bigIcon:'🥕',slot:'🐾',empty:'·',line:c=>`今天答對 <b>${c}</b> 題＝往前走 <b>${c}</b> 步`,next:n=>`再答對 ${n} 題，就能找到一根紅蘿蔔！`,rule:'每答對 1 題往前走 1 步，走滿 4 步找到 1 根紅蘿蔔。',today:'今日紅蘿蔔',round:c=>`🐾 這回合往前走了 ${c} 步`}};
function worldProgressVisual(runner){const W=WORLD_SCORE[currentWorld()];return `<div class="wp-slots" role="img" aria-label="已收集 ${runner} 個，共 4 個">${[0,1,2,3].map(i=>`<span class="${i<runner?'on':''}">${i<runner?W.slot:W.empty}</span>`).join('')}<span class="wp-goal">${W.bigIcon}</span></div>`}
const _progressCardV31=progressCard;
progressCard=function(){const w=currentWorld();if(w==='baseball')return _progressCardV31();const p=progressStats(),W=WORLD_SCORE[w],earned=new Set(earnedBadgeIds());
 return `<section class="card ballpark"><div class="ballpark-top"><div>${worldProgressVisual(p.runner)}</div><div><h3>${themeCopy().ballpark}</h3><p class="ballpark-line">${W.line(p.todayCorrect)}</p><p class="ballpark-line">${W.today} <b class="runs">${p.todayRuns}</b> ${W.big[0]} · 全部 <b>${p.careerRuns}</b></p><p class="note" style="margin:6px 0 0">${p.todayCorrect?W.next(p.toNext):W.rule}</p></div></div><details class="badges"><summary>🏅 我的${themeCopy().badgeWord} ${earned.size}／${BADGES.length}</summary><div class="badge-grid">${BADGES.map(b=>`<div class="badge ${earned.has(b.id)?'got':''}" title="${h(b.desc)}"><span>${earned.has(b.id)?b.icon:'🔒'}</span><strong>${h(b.name)}</strong><small>${h(b.desc)}</small></div>`).join('')}</div></details></section>`};
const _resultBallparkV31=resultBallpark;
resultBallpark=function(s){const w=currentWorld();if(w==='baseball')return _resultBallparkV31(s);const p=progressStats(),W=WORLD_SCORE[w],nb=(s.newBadges||[]).map(id=>BADGES.find(b=>b.id===id)).filter(Boolean);
 return `<section class="card ballpark-result"><div>${worldProgressVisual(p.runner)}</div><div><strong>${W.round(s.correct)}</strong><p class="note" style="margin:4px 0 0">${W.today} ${p.todayRuns} · 全部 ${p.careerRuns}</p>${nb.length?`<div class="new-badges">${nb.map(b=>`<span class="badge got"><span>${b.icon}</span><strong>新${themeCopy().badgeWord}：${h(b.name)}</strong></span>`).join('')}</div>`:''}</div></section>`};

// --- 角色名字、圖示、事件 ---
const WORLD_NAMES={princess:['莓莓','月月','花花','彩彩','雪雪','蝶蝶','糖糖','露露','甜甜'],animals:['兔兔','熊熊','喵喵','汪汪','鹿鹿','狐狐','鼠鼠','鴨鴨','豬豬']};
const WORLD_PATTERN={princess:['👑','💎','🌸','🦋','🎀','⭐'],animals:['🐰','🐱','🐶','🐻','🦊','🐥']};
const WORLD_COUNT={princess:{'👑':'皇冠','💎':'寶石','🌸':'小花','🦋':'蝴蝶','🍓':'草莓','🎀':'蝴蝶結','⭐':'星星','🧁':'杯子蛋糕'},animals:{'🐰':'兔子','🐱':'小貓','🐶':'小狗','🐻':'小熊','🦊':'狐狸','🐥':'小雞','🐟':'小魚','🐞':'瓢蟲'}};
const WORLD_TRUTH={princess:['找到了遺失的皇冠','把花園的花澆好水','幫迷路的小貓找到家','把茶會的杯子洗乾淨','做了一個生日蛋糕'],animals:['找到了迷路的小鴨','把樹屋打掃乾淨','幫松鼠收好橡實','種了一棵小樹','把野餐墊鋪好']};
// --- 推理場景 ---
const mkOrder=(id,title,unit,ask,verb)=>({id,title,unit:i=>unit(i),ask:i=>ask(i),at:(a,i)=>`${a}是${unit(i)}。`,not:(a,i)=>`${a}不是${unit(i)}。`,before:verb.before,next:verb.next,first:verb.first,last:verb.last,mid:verb.mid,gap:(a,b,k)=>`${a}和${b}中間隔了 ${k} 位。`,intro:verb.intro});
const WORLD_ORDER={
 princess:[
  mkOrder('dance','舞會跳舞的順序',i=>`第${CN5[i]}個跳舞`,i=>`誰是第${CN5[i]}個跳舞的？`,{before:(a,b)=>`${a}比${b}先上台跳舞。`,next:(a,b)=>`${b}緊接在${a}後面上台跳舞。`,first:a=>`${a}第一個跳舞。`,last:a=>`${a}最後一個跳舞。`,mid:a=>`${a}不是第一個，也不是最後一個跳舞。`,intro:n=>`${n} 位公主輪流上台跳舞。`}),
  mkOrder('castle','誰先到城堡',i=>`第${CN5[i]}個到城堡`,i=>`誰是第${CN5[i]}個到城堡的？`,{before:(a,b)=>`${a}比${b}早到城堡。`,next:(a,b)=>`${a}一到，${b}就緊接著到了。`,first:a=>`${a}最早到城堡。`,last:a=>`${a}最晚到城堡。`,mid:a=>`${a}不是最早到，也不是最晚到。`,intro:n=>`${n} 位公主一位一位到城堡參加舞會。`}),
  mkOrder('tea','茶會的座位',i=>`左邊數來第${CN5[i]}個座位`,i=>`誰坐在左邊數來第${CN5[i]}個座位？`,{before:(a,b)=>`${a}坐在${b}的左邊（不一定相鄰）。`,next:(a,b)=>`${b}就坐在${a}的右手邊（相鄰）。`,first:a=>`${a}坐最左邊。`,last:a=>`${a}坐最右邊。`,mid:a=>`${a}沒有坐在最左邊，也沒有坐在最右邊。`,intro:n=>`${n} 位公主在茶會長桌坐成一排。`}),
  mkOrder('cake','排隊拿蛋糕',i=>`第${CN5[i]}個拿到蛋糕`,i=>`誰是第${CN5[i]}個拿到蛋糕的？`,{before:(a,b)=>`${a}比${b}先拿到蛋糕。`,next:(a,b)=>`${b}排在${a}的正後面。`,first:a=>`${a}排第一個。`,last:a=>`${a}排最後一個。`,mid:a=>`${a}不是排第一個，也不是最後一個。`,intro:n=>`${n} 位公主排隊拿生日蛋糕。`}),
  mkOrder('tall','從矮到高拍照',i=>`第${CN5[i]}個`,i=>`從矮到高排，第${CN5[i]}個是誰？`,{before:(a,b)=>`${a}比${b}矮。`,next:(a,b)=>`${b}剛好排在${a}的下一個。`,first:a=>`${a}最矮。`,last:a=>`${a}最高。`,mid:a=>`${a}不是最矮，也不是最高。`,intro:n=>`${n} 位公主從矮到高排好拍照，沒有人一樣高。`})],
 animals:[
  mkOrder('race','森林賽跑名次',i=>`第${CN5[i]}名`,i=>`誰是第${CN5[i]}名？`,{before:(a,b)=>`${a}比${b}先衝過終點線。`,next:(a,b)=>`${b}緊跟在${a}後面衝過終點。`,first:a=>`${a}跑第一名。`,last:a=>`${a}跑最後一名。`,mid:a=>`${a}不是第一名，也不是最後一名。`,intro:n=>`${n} 隻小動物比賽跑步，沒有同時到的。`}),
  mkOrder('tree','誰先到樹屋',i=>`第${CN5[i]}個到樹屋`,i=>`誰是第${CN5[i]}個到樹屋的？`,{before:(a,b)=>`${a}比${b}早到樹屋。`,next:(a,b)=>`${a}一到，${b}就緊接著到了。`,first:a=>`${a}最早到。`,last:a=>`${a}最晚到。`,mid:a=>`${a}不是最早到，也不是最晚到。`,intro:n=>`${n} 隻小動物一隻一隻到樹屋集合。`}),
  mkOrder('picnic','野餐墊上的位子',i=>`左邊數來第${CN5[i]}個位子`,i=>`誰坐在左邊數來第${CN5[i]}個位子？`,{before:(a,b)=>`${a}坐在${b}的左邊（不一定相鄰）。`,next:(a,b)=>`${b}就坐在${a}的右手邊（相鄰）。`,first:a=>`${a}坐最左邊。`,last:a=>`${a}坐最右邊。`,mid:a=>`${a}沒有坐在最左邊，也沒有坐在最右邊。`,intro:n=>`${n} 隻小動物在野餐墊上坐成一排。`}),
  mkOrder('lunch','排隊吃午餐',i=>`第${CN5[i]}個吃到午餐`,i=>`誰是第${CN5[i]}個吃到午餐的？`,{before:(a,b)=>`${a}比${b}先拿到午餐。`,next:(a,b)=>`${b}排在${a}的正後面。`,first:a=>`${a}排第一個。`,last:a=>`${a}排最後一個。`,mid:a=>`${a}不是排第一個，也不是最後一個。`,intro:n=>`${n} 隻小動物排隊拿午餐。`}),
  mkOrder('tall','從矮到高排隊',i=>`第${CN5[i]}個`,i=>`從矮到高排，第${CN5[i]}個是誰？`,{before:(a,b)=>`${a}比${b}矮。`,next:(a,b)=>`${b}剛好排在${a}的下一個。`,first:a=>`${a}最矮。`,last:a=>`${a}最高。`,mid:a=>`${a}不是最矮，也不是最高。`,intro:n=>`${n} 隻小動物從矮到高排好，沒有一樣高的。`})]};
const mkAssign=(id,title,items,verb,numeric=false)=>({id,title,items,numeric,...verb});
const WORLD_ASSIGN={
 princess:[
  mkAssign('dress','禮服的顏色',['粉紅色','紫色','天藍色','金色','白色'],{is:(a,x)=>`${a}穿${x}的禮服。`,not:(a,x)=>`${a}沒有穿${x}的禮服。`,either:(a,b,x)=>`穿${x}禮服的是${a}或${b}。`,askWho:x=>`誰穿${x}的禮服？`,askWhat:a=>`${a}的禮服是什麼顏色？`,intro:n=>`這 ${n} 位公主的禮服顏色都不一樣。`}),
  mkAssign('pet','公主的寵物',['小貓','小狗','小兔子','小鳥','小馬'],{is:(a,x)=>`${a}養${x}。`,not:(a,x)=>`${a}沒有養${x}。`,either:(a,b,x)=>`養${x}的是${a}或${b}。`,askWho:x=>`誰養${x}？`,askWhat:a=>`${a}養什麼寵物？`,intro:n=>`這 ${n} 位公主各養一種不同的寵物。`}),
  mkAssign('sweet','茶會點心',['草莓蛋糕','馬卡龍','冰淇淋','布丁','餅乾'],{is:(a,x)=>`${a}吃${x}。`,not:(a,x)=>`${a}沒有吃${x}。`,either:(a,b,x)=>`吃${x}的是${a}或${b}。`,askWho:x=>`誰吃${x}？`,askWhat:a=>`${a}吃什麼點心？`,intro:n=>`茶會上這 ${n} 位公主各吃一種不同的點心。`}),
  mkAssign('room','城堡房間號碼',['2號','5號','8號','13號','21號'],{is:(a,x)=>`${a}住${x}房。`,not:(a,x)=>`${a}不是住${x}房。`,either:(a,b,x)=>`住${x}房的是${a}或${b}。`,gt:(a,b)=>`${a}的房間號碼比${b}大。`,odd:(a,o)=>`${a}的房間號碼是${o?'單數':'雙數'}。`,askWho:x=>`誰住${x}房？`,askWhat:a=>`${a}住幾號房？`,intro:n=>`這 ${n} 位公主住在城堡裡不同的房間。`},true)],
 animals:[
  mkAssign('food','最愛的食物',['紅蘿蔔','蜂蜜','小魚','骨頭','橡實'],{is:(a,x)=>`${a}最愛吃${x}。`,not:(a,x)=>`${a}最愛的不是${x}。`,either:(a,b,x)=>`最愛吃${x}的是${a}或${b}。`,askWho:x=>`誰最愛吃${x}？`,askWhat:a=>`${a}最愛吃什麼？`,intro:n=>`這 ${n} 隻小動物最愛的食物都不一樣。`}),
  mkAssign('home','住的房子',['樹洞','草屋','木屋','石洞','樹屋'],{is:(a,x)=>`${a}住在${x}。`,not:(a,x)=>`${a}沒有住在${x}。`,either:(a,b,x)=>`住在${x}的是${a}或${b}。`,askWho:x=>`誰住在${x}？`,askWhat:a=>`${a}住在哪裡？`,intro:n=>`這 ${n} 隻小動物住在不同的房子。`}),
  mkAssign('scarf','圍巾顏色',['紅色','黃色','綠色','藍色','紫色'],{is:(a,x)=>`${a}的圍巾是${x}。`,not:(a,x)=>`${a}的圍巾不是${x}。`,either:(a,b,x)=>`${x}圍巾是${a}或${b}的。`,askWho:x=>`誰的圍巾是${x}？`,askWhat:a=>`${a}的圍巾是什麼顏色？`,intro:n=>`這 ${n} 隻小動物的圍巾顏色都不一樣。`}),
  mkAssign('tag','比賽號碼牌',['3號','6號','9號','14號','20號'],{is:(a,x)=>`${a}拿${x}。`,not:(a,x)=>`${a}不是拿${x}。`,either:(a,b,x)=>`拿${x}的是${a}或${b}。`,gt:(a,b)=>`${a}的號碼比${b}大。`,odd:(a,o)=>`${a}的號碼是${o?'單數':'雙數'}。`,askWho:x=>`誰拿${x}？`,askWhat:a=>`${a}拿幾號？`,intro:n=>`森林運動會上，這 ${n} 隻小動物的號碼牌都不一樣。`},true)]};

// --- 題庫（公主、動物世界共用；{A}{B}{C} 依世界換成角色名字） ---
const GIRL_RULES=[
 {l:1,q:'下雨天去公園，最需要帶什麼？',a:'雨傘',o:['雨傘','太陽眼鏡','泳圈','風箏'],e:'下雨要撐雨傘才不會淋濕。'},
 {l:1,q:'過馬路時，紅燈亮了要怎麼做？',a:'停下來等',o:['停下來等','快跑過去','閉上眼睛走','跳過去'],e:'紅燈停、綠燈行，過馬路要看清楚紅綠燈。'},
 {l:1,q:'{A}的生日派對上，大家一起唱什麼歌？',a:'生日快樂歌',o:['生日快樂歌','晚安歌','下雨歌','刷牙歌'],e:'生日派對會唱生日快樂歌。'},
 {l:1,q:'圖書館裡應該怎麼做？',a:'輕聲細語、保持安靜',o:['輕聲細語、保持安靜','大聲唱歌','跑來跑去','在書上畫畫'],e:'圖書館是大家看書的地方，要保持安靜。'},
 {l:1,q:'吃飯前一定要先做什麼？',a:'洗手',o:['洗手','睡覺','穿外套','看電視'],e:'洗手可以把細菌洗掉。'},
 {l:1,q:'溜滑梯要排隊，{A}排在{B}前面，誰先溜？',a:'{A}',o:['{A}','{B}','兩個一起','都不能溜'],e:'排在前面的人先溜。'},
 {l:1,q:'借了朋友的蠟筆，用完要怎麼做？',a:'還給朋友並說謝謝',o:['還給朋友並說謝謝','偷偷帶回家','丟掉','折斷'],e:'借東西要記得還，還要說謝謝。'},
 {l:1,q:'晚上睡覺前，應該先做什麼？',a:'刷牙',o:['刷牙','吃糖果','大聲唱歌','跳床'],e:'睡前刷牙可以保護牙齒。'},
 {l:2,q:'{A}有 5 顆糖，給了{B} 2 顆，{B}本來有 1 顆。現在誰的糖比較多？',a:'一樣多',o:['{A}','{B}','一樣多','無法判斷'],e:'{A}剩 5−2＝3 顆，{B}有 1＋2＝3 顆，兩人一樣多。',h:'兩個人都算一算。'},{l:1,q:'不小心撞到朋友，應該說什麼？',a:'對不起',o:['對不起','走開','哈哈','不關我的事'],e:'不小心撞到別人要說對不起。'},
 {l:2,q:'{A}比{B}高，{B}比{C}高。誰最矮？',a:'{C}',o:['{C}','{A}','{B}','無法判斷'],e:'{A} > {B} > {C}，所以{C}最矮。'},
 {l:2,q:'「如果下雨，野餐就改在室內。」大家遵守這個規則，今天野餐在室外草地上，可以知道什麼？',a:'今天沒有下雨',o:['今天沒有下雨','今天有下雨','明天會下雨','野餐取消了'],e:'下雨一定在室內；在草地上就表示沒有下雨。'},
 {l:2,q:'{A}比{B}早起床，{C}比{A}早起床。誰最早起床？',a:'{C}',o:['{C}','{A}','{B}','無法判斷'],e:'{C} → {A} → {B}，{C}最早。'},
 {l:2,q:'盒子裡有 3 顆紅糖果和 1 顆藍糖果。將糖果充分混合，每顆大小形狀相同，不看顏色隨機拿一顆，比較可能拿到哪一種？',a:'紅糖果',o:['紅糖果','藍糖果','一樣可能','一定拿不到'],e:'紅糖果比較多，所以比較可能拿到紅的。'},
 {l:2,q:'這週的派對在星期六，今天是星期四，還有幾天？',a:'2 天',o:['2 天','1 天','3 天','6 天'],e:'星期四 → 星期五 → 星期六，再過 2 天。'},
 {l:3,q:'「每一位參加派對的朋友都會拿到氣球。」{A}拿到了氣球，她一定參加了派對嗎？',a:'不一定，別的地方也可能拿到氣球',o:['不一定，別的地方也可能拿到氣球','一定有參加','一定沒參加','她不喜歡氣球'],e:'「參加的都有氣球」不代表「有氣球的都參加」。'},
 {l:3,q:'{A}、{B}、{C}三人只有一人帶了禮物。{A}說：「不是我帶的。」{B}說：「是{C}帶的。」兩人都說真話，誰帶了禮物？',a:'{C}',o:['{C}','{A}','{B}','無法判斷'],e:'{B}說真話，所以是{C}；也符合{A}說的話。'},
 {l:3,q:'假設大家遵守「只有寫完作業才能看卡通」。{A}在看卡通，可以知道什麼？',a:'{A}寫完作業了',o:['{A}寫完作業了','{A}沒寫作業','{A}不喜歡卡通','大家都在看卡通'],e:'沒寫完作業不能看卡通；{A}在看，就表示寫完了。'},
 {l:3,q:'有 4 位朋友，每兩人都要互相送一張卡片（一人送一張給對方）。一共要送幾張？',a:'12 張',o:['12 張','6 張','8 張','4 張'],e:'每個人要送給另外 3 個人：4×3＝12 張。'},
 {l:4,q:'「如果 A，則 B」成立。下列哪一句一定也成立？',a:'如果不是 B，就不是 A',o:['如果不是 B，就不是 A','如果 B，就是 A','如果不是 A，就不是 B','A 和 B 沒有關係'],e:'這叫「逆否命題」，和原句一定同真。例：下雨就在室內 → 不在室內就是沒下雨。'},
 {l:4,q:'三個盒子分別裝草莓糖、葡萄糖、兩種混合，但三個標籤全部貼錯了。最少要拿出幾顆糖來看，就能把標籤全部改對？',a:'1 顆',o:['1 顆','2 顆','3 顆','0 顆'],e:'從貼著「混合」的盒子拿 1 顆：它一定不是混合，拿到草莓就是草莓盒；剩下兩盒標籤也都錯，就能推出全部。',h:'標籤「一定」是錯的，這是很重要的線索。'},
 {l:4,q:'{A}說：「我比{B}大 2 歲。」{B}今年 6 歲。3 年後，{A}幾歲？',a:'11 歲',o:['11 歲','8 歲','9 歲','10 歲'],e:'{A}今年 6＋2＝8 歲，3 年後 8＋3＝11 歲。'},
 {l:4,q:'5 位朋友圍成一圈手牽手，一共有幾個「牽手的地方」？',a:'5 個',o:['5 個','4 個','10 個','6 個'],e:'圍成圓圈時，頭尾也牽在一起，人數和牽手處一樣多：5 個。'}];
const GIRL_ODD=[
 {l:1,q:'哪一個不是花？',a:'蘋果',o:['玫瑰','向日葵','鬱金香','蘋果'],e:'蘋果是水果，其他是花。'},
 {l:1,q:'哪一個不是甜點？',a:'青菜',o:['蛋糕','冰淇淋','餅乾','青菜'],e:'青菜是蔬菜。'},
 {l:1,q:'哪一個不是動物？',a:'椅子',o:['小貓','小兔','小鳥','椅子'],e:'椅子是家具。'},
 {l:1,q:'哪一個通常是用餐的餐具？',a:'湯匙',o:['裙子','襪子','外套','湯匙'],e:'湯匙是餐具。'},
 {l:1,q:'哪一個不是顏色？',a:'星星',o:['粉紅色','紫色','黃色','星星'],e:'星星是形狀（或天上的星體），不是顏色。'},
 {l:1,q:'哪一個通常不會靠自己飛行？',a:'小兔子',o:['蝴蝶','麻雀','蜜蜂','小兔子'],e:'小兔子用跳的，不會飛。'},
 {l:1,q:'哪一個通常生活在水中？',a:'魚',o:['太陽','月亮','雲','魚'],e:'魚住在水裡。'},
 {l:1,q:'哪一個不是頭上戴的？',a:'鞋子',o:['皇冠','帽子','髮夾','鞋子'],e:'鞋子穿在腳上。'},
 {l:2,q:'哪一個主要生活在陸地樹林裡？',a:'松鼠',o:['海豚','章魚','海蟹','松鼠'],e:'松鼠住在樹上。'},
 {l:2,q:'哪一個不是樂器？',a:'剪刀',o:['鋼琴','小提琴','鈴鼓','剪刀'],e:'剪刀是文具。'},
 {l:2,q:'哪一個圖形的外框含有彎曲的線？',a:'愛心',o:['正方形','長方形','三角形','愛心'],e:'正方形、長方形、三角形都是由直線組成；愛心有彎彎的邊。'},
 {l:2,q:'哪一個通常在白天、陽光照到空中水滴時可看見？',a:'彩虹',o:['月亮','星星','螢火蟲','彩虹'],e:'彩虹通常由陽光經水滴折射、反射形成；夜晚也可能有微弱的月虹，因此不能說彩虹一定不會在夜晚出現。'},
 {l:3,q:'哪一個是哺乳類而不是魚類？',a:'海豚',o:['金魚','鯊魚','鮭魚','海豚'],e:'海豚是哺乳類，用肺呼吸；其他是魚。'},
 {l:3,q:'哪一個是現代電子設備？',a:'電腦',o:['城堡','魔法棒','王冠','電腦'],e:'電腦是現代電子設備；不能只靠物品名稱就斷定它會不會出現在童話中。'}];
const GIRL_SCIENCE={
 body:[{l:1,q:'跳舞跳很久之後，心跳會怎樣？',a:'變快',o:['變快','變慢','停止','不變'],e:'運動時身體需要更多氧氣，心臟跳得更快。'},{l:1,q:'跳繩前先做什麼比較不會受傷？',a:'暖身',o:['暖身','吃糖果','睡覺','穿拖鞋'],e:'暖身讓肌肉準備好。'},{l:2,q:'跳芭蕾舞時，是什麼拉動骨頭讓腳踮起來？',a:'肌肉',o:['肌肉','頭髮','指甲','衣服'],e:'肌肉收縮會拉動骨頭。'}],
 force:[{l:1,q:'吹泡泡時，泡泡為什麼會飄起來？',a:'泡泡很輕，被空氣帶著飄',o:['泡泡很輕，被空氣帶著飄','泡泡有翅膀','泡泡會自己飛','泡泡被磁鐵吸'],e:'泡泡很輕，空氣流動就能把它帶走。'},{l:1,q:'積木原本靜止在水平桌面，沒有推拉、桌面也不晃動時，積木會怎樣？',a:'停在原地不動',o:['停在原地不動','自己跑走','飛起來','變大'],e:'原本靜止的物體，在合外力為零時會保持靜止；原本已在移動的物體，則不需要持續受力才能維持等速直線運動。'},{l:1,q:'在沒有明顯氣流的室內，放開已綁緊、內裝普通空氣的氣球，通常會怎樣？',a:'慢慢掉到地上',o:['慢慢掉到地上','飛到天上','停在空中不動','變成雲'],e:'普通空氣加上氣球皮的總重量，大於它排開空氣的重量，通常會落下；若裝足夠的氦氣，浮力可能使它上升。'},{l:1,q:'盪鞦韆盪到高處後，誰把鞦韆拉回來？',a:'地心引力',o:['地心引力','風','磁鐵','聲音'],e:'地心引力把鞦韆往下拉。'},{l:2,q:'溜冰鞋為什麼可以滑得很遠？',a:'輪子讓摩擦力變小',o:['輪子讓摩擦力變小','鞋子有魔法','地面在動','風一直推'],e:'輪子轉動時摩擦力小，所以滑得遠。'}],
 nature:[{l:1,q:'蝴蝶的毛毛蟲幼蟲，經過蛹的階段後會變成什麼？',a:'蝴蝶',o:['蝴蝶','小鳥','青蛙','蜜蜂'],e:'蝴蝶的幼蟲會化蛹，再羽化成蝴蝶；並非所有毛毛蟲都變蝴蝶，有些是蛾的幼蟲。'},{l:1,q:'許多常見的小鳥會用樹枝和草築成什麼，來產卵育雛？',a:'鳥巢',o:['鳥巢','紙箱','鞋子','杯子'],e:'許多小鳥會築巢來產卵育雛；不同鳥類的築巢方式與材料不完全相同。'},{l:2,q:'冬天時，有些熊會長時間睡覺，這叫什麼？',a:'冬眠',o:['冬眠','午睡','發呆','遷徙'],e:'冬眠可以度過食物很少的冬天。'},{l:2,q:'企鵝住在很冷的地方，牠們身上有什麼幫助保暖？',a:'厚厚的脂肪和緊密的羽毛',o:['厚厚的脂肪和緊密的羽毛','毛衣','電暖器','鱗片'],e:'脂肪和羽毛能保持體溫。'},{l:3,q:'有些候鳥會隨季節往返不同地區，這種移動叫什麼？',a:'遷徙',o:['遷徙','冬眠','脫皮','換毛'],e:'候鳥會隨季節遷徙，以尋找適合繁殖、覓食或度冬的環境；並非每種候鳥都只在秋天向溫暖處移動。'}],
 lab:[{l:1,q:'大人確認花朵安全且自己不過敏後，想比較氣味，主要用哪個感官？',a:'用鼻子輕輕聞氣味',o:['用鼻子輕輕聞氣味','耳朵聽','尺量','秤重'],e:'鼻子能感覺氣味。先由大人確認花朵安全，不把花或不明物品貼近鼻子，也不品嚐。'},{l:2,q:'想知道哪種杯子保溫最好，倒進去的熱水要怎樣？',a:'一樣多、一樣熱',o:['一樣多、一樣熱','有的多有的少','有的熱有的冷','隨便倒'],e:'只改變杯子，其他條件都一樣才公平。'}]};
const GIRL_VOCAB={1:[["crown","皇冠","👑"],["dress","洋裝","👗"],["cake","蛋糕","🎂"],["bunny","小兔子","🐰"],["kitten","小貓","🐱"],["puppy","小狗","🐶"],["star","星星","⭐"],["heart","愛心","❤️"],["pink","粉紅色","🩷"],["bear","熊","🐻"]],2:[["castle","城堡","🏰"],["princess","公主","👸"],["garden","花園","🌷"],["butterfly","蝴蝶","🦋"],["rainbow","彩虹","🌈"],["ribbon","緞帶","🎀"],["forest","森林","🌲"],["squirrel","松鼠","🐿️"],["dance","跳舞","💃"],["magic","魔法","✨"],["picnic","野餐","🧺"]],3:[["kingdom","王國","🏰"],["gentle","溫柔的","🤲"],["brave","勇敢的","🦁"],["sparkle","閃閃發光","✨"],["adventure","冒險","🗺️"],["treasure","寶藏","💎"],["habitat","棲息地","🌳"],["hibernate","冬眠","🐻"]],4:[["elegant","優雅的","🦢"],["generous","慷慨的","🎁"],["enchanted","被施了魔法的","🪄"],["endangered","瀕臨絕種的","🐼"],["migrate","遷徙","🦆"],["ceremony","典禮","🎊"],["celebrate","慶祝","🥳"],["imagination","想像力","💭"],["nocturnal","夜行性的","🦉"]]};
const GIRL_READ={1:[['The bunny is white.','小兔子是什麼顏色？',['白色','黑色','紅色','綠色'],'白色','white 是白色。'],['She has a pink dress.','她有什麼？',['粉紅色洋裝','藍色帽子','紅色鞋子','黃色雨傘'],'粉紅色洋裝','pink dress 是粉紅色洋裝。'],['The kitten can jump.','小貓會做什麼？',['跳','游泳','唱歌','畫畫'],'跳','jump 是跳。'],['I like cake.','我喜歡什麼？',['蛋糕','魚','書','鞋子'],'蛋糕','cake 是蛋糕。']],
 2:[['The princess lives in a big castle.','公主住在哪裡？',['大城堡','小樹屋','學校','醫院'],'大城堡','castle 是城堡。'],['We have a picnic in the garden.','我們在哪裡野餐？',['花園','廚房','海邊','車上'],'花園','garden 是花園。'],['The butterfly is on the flower.','蝴蝶在哪裡？',['花上','樹下','水裡','桌上'],'花上','on the flower 在花上。'],['After it rains, we see a rainbow.','下雨過後看到什麼？',['彩虹','月亮','雪','星星'],'彩虹','rainbow 是彩虹。']],
 3:[['The rabbit and the turtle wanted to see who was faster. The rabbit took a nap, so the slow turtle won.','為什麼烏龜贏了？','因為兔子中途睡覺了',['因為兔子中途睡覺了','因為烏龜跑最快','因為兔子迷路','因為下雨'],'took a nap 睡午覺；so 表示結果。'],['Lulu wanted to buy a doll, but she did not have enough money, so she saved her pocket money for a month.','Lulu 為什麼存零用錢？','錢不夠買娃娃',['錢不夠買娃娃','想買書','要還錢','想買糖果'],'did not have enough money 錢不夠。'],['The brave princess helped the lost bunny find its home.','勇敢的公主做了什麼？',['幫迷路的小兔子找到家','把小兔子帶走','去游泳','睡午覺'],'幫迷路的小兔子找到家','lost 迷路的；find its home 找到家。'],['In winter, the bear sleeps in its cave because food is hard to find.','熊冬天為什麼睡在洞裡？',['因為很難找到食物','因為想看雪','因為洞裡有電視','因為牠生病了'],'因為很難找到食物','because 後面說明原因。'],['The squirrel hides nuts so it can eat them later.','松鼠為什麼藏堅果？',['之後可以吃','想送給熊','因為太重','想種花'],'之後可以吃','so it can eat them later 之後可以吃。']],
 4:[['Elegant swans glided across the lake while the children watched quietly from the bridge.','孩子們在哪裡看天鵝？','橋上',['橋上','湖裡','樹上','屋頂'],'from the bridge 從橋上。'],['The kingdom held a grand ceremony to celebrate the princess’s birthday.','王國為什麼舉辦典禮？','慶祝公主的生日',['慶祝公主的生日','歡迎新國王','慶祝豐收','送別朋友'],'to celebrate... birthday 慶祝生日。'],['At night, the nocturnal animals came out of the quiet forest to look for food.','夜行性動物晚上出來做什麼？','找食物',['找食物','睡覺','上學','游泳'],'to look for food 找食物。'],['Her imagination was so wonderful that she wrote a story about a flying castle.','她寫了什麼故事？','會飛的城堡',['會飛的城堡','會說話的狗','海底王國','森林運動會'],'a flying castle 會飛的城堡。'],['The enchanted garden sparkled at night, and the nocturnal owls watched quietly from the trees.','誰在樹上安靜地看？',['夜行性的貓頭鷹','小兔子','公主','蝴蝶'],'夜行性的貓頭鷹','nocturnal owls 夜行性的貓頭鷹。'],['Every autumn, the ducks migrate to a warmer lake, and the children celebrate their return in spring.','鴨子秋天做什麼？',['遷徙到比較溫暖的湖','冬眠','留在原地','學游泳'],'遷徙到比較溫暖的湖','migrate 遷徙；warmer 比較溫暖。'],['The generous queen shared her treasure with everyone in the kingdom.','女王怎麼處理她的寶藏？',['和王國裡的每個人分享','藏起來','丟掉','賣掉'],'和王國裡的每個人分享','generous 慷慨的；shared 分享。']]};
// 統一短句格式：[句子, 問題, 選項, 答案, 解析]
for(const lv of [1,2,3,4])GIRL_READ[lv]=GIRL_READ[lv].map(x=>typeof x[2]==='string'&&Array.isArray(x[3])?[x[0],x[1],x[3],x[2],x[4]]:x);
const GIRL_USE={1:[["The princess wears a ___.","crown","公主戴著皇冠。"],["I put on my pink ___.","dress","我穿上粉紅色洋裝。"],["The ___ hops in the grass.","bunny","小兔子在草地上跳。"],["We eat ___ at the birthday party.","cake","我們在生日派對吃蛋糕。"],["A little ___ says meow.","kitten","小貓會喵喵叫。"]],2:[["The princess lives in a ___.","castle","公主住在城堡。"],["We see a ___ after the rain.","rainbow","雨後我們看到彩虹。"],["I tie a ___ in my hair.","ribbon","我在頭髮綁上緞帶。"],["Let's have a ___ under the tree.","picnic","我們在樹下野餐吧。"],["The ___ has colorful wings.","butterfly","蝴蝶有彩色的翅膀。"]],3:[["The ___ girl was not afraid of the dark.","brave","勇敢的女孩不怕黑。"],["The pirates found a box of ___.","treasure","海盜找到一箱寶藏。"],["Some bears ___ in winter.","hibernate","有些熊在冬天冬眠。"],["The forest is the ___ of many animals.","habitat","森林是很多動物的棲息地。"]],4:[["The swan looked ___ on the lake.","elegant","天鵝在湖上看起來很優雅。"],["Animals at serious risk of extinction are called ___.","endangered","面臨嚴重滅絕風險的動物被稱為瀕危動物。"],["Use your ___ to draw a magic castle.","imagination","用你的想像力畫一座魔法城堡。"],["Many owls are ___ animals.","nocturnal","許多貓頭鷹是夜行性動物。"],["Many birds ___ to warm places in winter.","migrate","很多鳥冬天會遷徙到溫暖的地方。"],["We ___ her birthday with a big party.","celebrate","我們辦大派對慶祝她的生日。"],["The ___ queen gave gifts to everyone.","generous","慷慨的女王送禮物給每個人。"]]};
const GIRL_DEEP={1:[['The cat sleeps on the bed. The dog sleeps on the floor. The bird sleeps in a cage.','誰睡在地板上？','小狗',['小狗','小貓','小鳥','沒有人'],'The dog sleeps on the floor.','把每隻動物和地方配對。','en-context'],['Mia has three apples. She eats one. Then she gives one to Lulu.','Mia 最後還有幾顆蘋果？','一顆',['一顆','兩顆','三顆','沒有'],'3 顆吃掉 1 顆、送出 1 顆，剩 1 顆。','一步一步算。','en-inference'],['First, the princess wakes up. Next, she brushes her teeth. Then, she eats breakfast.','公主刷牙之後做什麼？','吃早餐',['吃早餐','起床','睡覺','唱歌'],'Then 表示接下來。','找出 next 和 then。','en-order'],['It is cold today. Lulu puts on her coat and a warm hat.','Lulu 為什麼穿外套？','因為今天很冷',['因為今天很冷','因為要游泳','因為很熱','因為要睡覺'],'cold 是冷。','找出天氣線索。','en-inference'],['Lulu has a pink ribbon. Mimi has a blue ribbon. Lulu gives her ribbon to Mimi.','現在誰有兩條緞帶？','Mimi',['Mimi','Lulu','兩人都沒有','老師'],'Mimi 本來有一條，Lulu 又送她一條。','數一數每個人的緞帶。','en-inference'],['The bunny is hungry. It eats a carrot. Now it is happy.','小兔子為什麼變開心？','因為吃了紅蘿蔔',['因為吃了紅蘿蔔','因為下雨了','因為睡覺了','因為找到球'],'hungry 餓了，吃完就開心。','找出前後的變化。','en-inference']],
 2:[['The puppy wanted to play, but its friend was sleeping. So the puppy waited quietly.','小狗為什麼安靜地等？','因為朋友在睡覺',['因為朋友在睡覺','因為牠生病了','因為下雨','因為肚子餓'],'but 後面說明朋友在睡覺。','注意 but 和 so。','en-inference'],['Lulu has five stickers. Mimi has two more than Lulu.','Mimi 有幾張貼紙？','七張',['七張','三張','五張','兩張'],'two more than 是「比……多兩個」：5＋2＝7。','把英文換成算式。','en-context'],['The garden party starts at three. The princess arrives at two to help set the table.','公主為什麼兩點就到？','幫忙擺桌子',['幫忙擺桌子','派對已經開始','她走錯路','要回家'],'to help set the table 是目的。','比較 three 和 two。','en-inference'],['The bunny planted carrot seeds in spring. In summer, it had many carrots to eat.','小兔子夏天為什麼有很多紅蘿蔔？','因為春天種了種子',['因為春天種了種子','朋友送的','從商店買的','下雨變出來的'],'先在 spring 種，summer 收成。','注意季節的先後。','en-order'],['The kitten is smaller than the puppy, and the puppy is smaller than the horse.','誰最大？','馬',['馬','小貓','小狗','一樣大'],'小貓 < 小狗 < 馬。','把三隻動物排一排。','en-context'],['Mimi forgot her umbrella, so Lulu shared hers on the way home.','Lulu 做了什麼？','和 Mimi 共用雨傘',['和 Mimi 共用雨傘','把雨傘丟掉','先跑回家','借 Mimi 外套'],'shared hers 分享她的雨傘。','找出 so 後面的結果。','en-inference'],['The princess wanted to go to the garden, but it was raining. She read a book in the castle instead.','公主最後做了什麼？','在城堡裡看書',['在城堡裡看書','去花園','去游泳','睡午覺'],'instead 表示改做別的事。','注意 but 和 instead。','en-inference'],['First, the squirrel finds nuts. Next, it carries them to its tree. Last, it hides them in a hole.','松鼠最後做什麼？','把堅果藏進洞裡',['把堅果藏進洞裡','找堅果','爬樹','吃掉堅果'],'Last 表示最後。','找出 last。','en-order']],
 3:[['The fox wanted the grapes, but they were too high. After trying many times, it said the grapes were probably sour anyway.','狐狸為什麼說葡萄是酸的？','因為拿不到，所以找藉口',['因為拿不到，所以找藉口','因為牠吃過了','因為葡萄真的壞了','因為朋友告訴牠'],'牠拿不到，才說葡萄酸，這是在找藉口。','想想狐狸真正的心情。','en-inference'],['The ant worked hard all summer to store food, while the grasshopper sang and played. When winter came, only the ant had enough to eat.','這個故事想說什麼？','要為以後做準備',['要為以後做準備','唱歌最重要','冬天不用吃東西','螞蟻很小氣'],'螞蟻提前準備，冬天才有食物。','比較兩隻動物的做法和結果。','en-inference'],['On Monday the princess planted seeds. On Wednesday she watered them. On Saturday tiny green leaves appeared.','葉子在星期幾長出來？','星期六',['星期六','星期一','星期三','星期日'],'On Saturday tiny green leaves appeared.','建立時間順序。','en-order'],['The castle has four towers. Each tower has two windows. One of the eight windows is broken.','有幾扇窗戶是好的？','七扇',['七扇','八扇','六扇','四扇'],'4×2＝8 扇，壞了 1 扇，好的有 7 扇。','把英文變成算式。','en-context'],['The little bird was afraid to fly, but its mother stayed beside it and encouraged it every day. One morning, it finally flew over the lake.','媽媽如何幫助原本害怕飛翔的小鳥？','媽媽每天陪伴和鼓勵',['媽媽每天陪伴和鼓勵','牠吃了魔法藥','風把牠吹起來','牠一直都會飛'],'母鳥每天陪伴與鼓勵小鳥；題目問媽媽做了什麼，不把鼓勵當成學會飛翔的唯一原因。','找出改變的原因。','en-inference'],['The kitten was stuck in a tree. The brave puppy barked loudly until the farmer came with a ladder.','小狗為什麼一直叫？','要叫農夫來救小貓',['要叫農夫來救小貓','牠肚子餓','牠想睡覺','牠在唱歌'],'小貓被困住，小狗叫到農夫拿梯子來。','把事情的原因和結果連起來。','en-inference']],
 4:[['A survey asked 20 children about their favorite animal. Half chose rabbits, five chose cats, and the rest chose pandas.','有幾個孩子選熊貓？','5 個',['5 個','10 個','15 個','20 個'],'一半是 10 人選兔子，5 人選貓，20−10−5＝5 人選熊貓。','把 half 換成數字。','en-context'],['The gardener noticed that the roses near the window grew taller than the roses in the dark corner. She decided to move all the roses closer to the light.','園丁為什麼把玫瑰移到靠近光的地方？','她發現靠窗的玫瑰長得比較高',['她發現靠窗的玫瑰長得比較高','角落太吵','玫瑰喜歡黑暗','窗戶壞了'],'她觀察到靠窗的玫瑰比較高，因而改變擺放位置；這個故事沒有控制其他條件，不能單憑高度差就證明只有光照造成差異。','找出她觀察到的差別。','en-inference'],['Although the princess was invited to a grand party, she chose to stay home and take care of her sick puppy. Her friends admired her kindness.','朋友為什麼佩服公主？','她選擇照顧生病的小狗',['她選擇照顧生病的小狗','她跳舞跳得最好','她穿最漂亮的禮服','她最早到舞會'],'although 雖然；she chose to stay home... 照顧小狗。','注意 although 的轉折。','en-inference'],['Some endangered animals live in forests. Because people cut down many forests, these animals lost their habitat, so forests are being restored to protect them.','為什麼要種新的森林？','保護失去棲息地的動物',['保護失去棲息地的動物','讓人類蓋房子','種更多竹子來賣','讓天氣變冷'],'lost their habitat 失去棲息地；to protect them 為了保護牠們。','把原因和結果連起來。','en-inference'],['The owl sleeps all day and hunts at night. The squirrel gathers nuts in the morning and sleeps at night.','哪一隻是夜行性動物？','貓頭鷹',['貓頭鷹','松鼠','兩隻都是','兩隻都不是'],'夜行性動物晚上活動，貓頭鷹晚上打獵。','比較兩隻動物活動的時間。','en-context'],['The enchanted castle only opened its gate to visitors who were kind. Rude visitors waited outside for hours, but the gentle princess walked right in.','城堡的門為誰打開？','善良的訪客',['善良的訪客','穿最漂亮衣服的人','最早到的人','最有錢的人'],'only... visitors who were kind 只為善良的人開門。','注意 only 後面的條件。','en-inference']]};

// --- 應用題與計分題的用語轉換（公主／動物世界） ---
const WORLD_PHRASES={
 princess:[['⚾ 生活與棒球的數學','🎀 城堡裡的數學'],['🏟️ 看懂比賽數字','🏆 看懂計分板'],['棒球手套','魔法棒'],['球帽','蝴蝶結'],['球隊巴士','城堡馬車'],['球員卡','公主貼紙'],['棒球卡','公主貼紙'],['練習球','珍珠'],['一顆棒球','一顆珍珠'],['棒球','珍珠'],['球盒','珠寶盒'],['球袋','珠寶袋'],['球箱','珠寶箱'],['一箱球','一箱珍珠'],['紅球','紅寶石'],['藍球','藍寶石'],['袋球','袋珍珠'],['盒球','盒珍珠'],['顆球','顆珍珠'],['觀眾席','舞會座位'],['球場模型','城堡模型'],['棒球館地板','舞廳地板'],['棒球館','舞廳'],['練習區','花園'],['球場','城堡'],['球隊','公主們'],['球員','公主'],['教練','女王'],['紅隊','紅玫瑰隊'],['藍隊','藍星星隊'],['綠隊','綠精靈隊'],['甲組','玫瑰組'],['乙組','百合組'],['打者','公主'],['兩局得分表','兩回合得分表'],['局','回合'],['⚾','⭐']],
 animals:[['⚾ 生活與棒球的數學','🐾 森林裡的數學'],['🏟️ 看懂比賽數字','🏆 看懂計分板'],['棒球手套','小背包'],['球帽','小帽子'],['球隊巴士','森林巴士'],['球員卡','動物貼紙'],['棒球卡','動物貼紙'],['練習球','橡實'],['一顆棒球','一顆橡實'],['棒球','橡實'],['球盒','橡實盒'],['球袋','小籃子'],['球箱','木箱'],['一箱球','一箱橡實'],['紅球','紅蘋果'],['藍球','藍莓'],['袋球','袋橡實'],['盒球','盒橡實'],['顆球','顆橡實'],['觀眾席','森林看台'],['球場模型','樹屋模型'],['棒球館地板','樹屋地板'],['棒球館','大樹屋'],['練習區','草地'],['球場','森林'],['球隊','動物小隊'],['球員','小動物'],['教練','貓頭鷹老師'],['紅隊','兔子隊'],['藍隊','熊熊隊'],['綠隊','松鼠隊'],['甲組','兔子組'],['乙組','熊熊組'],['打者','小動物'],['三個人裡','三隻小動物裡'],['兩局得分表','兩回合得分表'],['局','回合'],['⚾','🐾']]};
// 這些用語在公主／動物世界不應該出現
const BASEBALL_RX=/棒球|壘|打擊|打者|投手|捕手|球員|球隊|教練|球場|球棒|手套|安打|全壘打|三振|保送|打序|棒次|跑者|球迷|游擊|外野|內野|觀眾席|比分|局|打數|左打|雄鷹|⚾|🧤|🏟️|🏏|(?:^|[^地氣月星眼])球/;
const BASEBALL_EN=/\b(baseball|bats?|gloves?|pitchers?|batters?|catchers?|innings?|coach(es)?|teams?|teammates?|helmets?|field|stadium|players?|games?|scored?|hits?|home run|bases?|fans?|referee|tournament|champion|league|captain|uniforms?|strikes?|pitch\w*|practices?|teamwork|sports?|defense|offense|applause|audience|throws?|catch|run(s|ning)?|race|ball)\b/i;
const hasBaseball=t=>BASEBALL_RX.test(String(t||''));
const WORLD_BALL={princess:'珍珠',animals:'橡實'};
function worldText(t,w){let s=String(t??'');for(const [a,b] of WORLD_PHRASES[w])s=s.split(a).join(b);return s.replace(/球/g,(ball,index,text)=>index>0&&'地氣月星眼'.includes(text[index-1])?ball:WORLD_BALL[w])}
function worldize(q,w){if(!q||w==='baseball')return q;const o={...q};for(const k of ['prompt','main','second','explain','hint','answer'])if(typeof o[k]==='string')o[k]=worldText(o[k],w);if(Array.isArray(o.choices))o.choices=o.choices.map(c=>worldText(c,w));return o}
const questionText=q=>[q.prompt,q.main,q.second,q.explain,q.hint,q.answer,...(q.choices||[])].join('｜');

// --- 套用世界：把共用的資料換成目前世界的版本 ---
const BASE_DATA={};
function snapshotBase(){if(BASE_DATA.done)return;BASE_DATA.done=true;
 BASE_DATA.names=LINEUP_NAMES.slice();BASE_DATA.pattern=PATTERN_SYMBOLS.slice();BASE_DATA.count=COUNT_ICONS.slice();BASE_DATA.countNames={...COUNT_NAMES};BASE_DATA.truth=TRUTH_EVENTS.slice();BASE_DATA.order=ORDER_SCENES.slice();BASE_DATA.assign=ASSIGN_SCENES.slice();
 BASE_DATA.odd=ODD_BANK.slice();BASE_DATA.rules=RULES_BANK.slice();BASE_DATA.sci=Object.fromEntries(Object.entries(SCIENCE_BANK).map(([k,v])=>[k,v.slice()]));
 BASE_DATA.vocab={};BASE_DATA.read={};BASE_DATA.use={};BASE_DATA.deep={};for(const lv of [1,2,3,4]){BASE_DATA.vocab[lv]=(VOCAB[lv]||[]).slice();BASE_DATA.read[lv]=(READ[lv]||[]).slice();BASE_DATA.use[lv]=(WORD_USE[lv]||[]).slice();BASE_DATA.deep[lv]=(DEEP_READ[lv]||[]).slice()}
 BASE_DATA.alphaB={...ALPHABET[1]};BASE_DATA.zyQ={...ZHUYIN.find(z=>z.sym==='ㄑ')};BASE_DATA.modes=Object.fromEntries(Object.entries(MODES).map(([s,arr])=>[s,arr.map(m=>({name:m.name,label:m.label,desc:m.desc,icon:m.icon}))]));
 BASE_DATA.meta=Object.fromEntries(Object.entries(SUBJECT_META).map(([k,v])=>[k,{...v}]));BASE_DATA.badges=BADGES.map(b=>({name:b.name,desc:b.desc,icon:b.icon}));}
const setArr=(arr,vals)=>{arr.splice(0,arr.length,...vals)};
const fillNames=(t,names)=>String(t).replace(/\{A\}/g,names[0]).replace(/\{B\}/g,names[1]).replace(/\{C\}/g,names[2]);
const nameBank=(bank,names)=>bank.map(b=>({...b,q:fillNames(b.q,names),a:fillNames(b.a,names),e:fillNames(b.e,names),o:b.o.map(x=>fillNames(x,names)),h:b.h?fillNames(b.h,names):b.h}));
const cleanBank=bank=>bank.filter(b=>!hasBaseball(b.q+b.a+b.e+b.o.join()+(b.h||'')));
const WORLD_MODE_TEXT={
 princess:{math:{calc:['計算魔法','從加減到乘除，一步一步施展計算魔法。','🪄'],story:['城堡應用題','把城堡裡的生活變成算式。','🎀'],score:['舞會計分板','看計分板，理解差距與總分。','🏆']},logic:{lineup:['公主推理','跳舞順序、茶會座位、禮服顏色……從線索推出答案。'],rules:['規則與推論','認識生活規則，練習「如果……就……」的推論。']},english:{listening:['魔法小耳朵'],vocab:[null,null,'👑'],use:[null,'把單字放進生活、城堡和花園的句子，理解後再選。']}},
 animals:{math:{calc:['計算探險','從加減到乘除，一步一步完成探險。','🧭'],story:['森林應用題','把森林裡的生活變成算式。','🐾'],score:['運動會計分板','看計分板，理解差距與總分。','🏆']},logic:{lineup:['動物推理','賽跑名次、野餐座位、最愛的食物……從線索推出答案。'],rules:['規則與推論','認識生活規則，練習「如果……就……」的推論。']},english:{listening:['動物小耳朵'],vocab:[null,null,'🐰'],use:[null,'把單字放進生活、森林和動物的句子，理解後再選。']}}};
const WORLD_META={
 princess:{math:{tile:'計算、城堡應用題、計分板'},logic:{levelNote:'第1級 3 位公主推理與簡單規律；第2級 4 位公主推理；第3級加入「如果……就……」的推論。',tile:'公主推理、數獨、誰說謊、找規律',route:'找規律 → 分類找不同 → 公主推理 → 規則與因果',desc:'像小偵探一樣想事情：找線索、排除不可能，再下結論。',tip:'邏輯題最重要的是「說出理由」。孩子答完後，請她用一句話說明：「因為……所以……」。'},science:{desc:'蝴蝶怎麼長大？彩虹從哪裡來？從身邊的問題認識科學。'}},
 animals:{math:{tile:'計算、森林應用題、計分板'},logic:{levelNote:'第1級 3 隻小動物推理與簡單規律；第2級 4 隻小動物推理；第3級加入「如果……就……」的推論。',tile:'動物推理、數獨、誰說謊、找規律',route:'找規律 → 分類找不同 → 動物推理 → 規則與因果',desc:'像小偵探一樣想事情：找線索、排除不可能，再下結論。',tip:'邏輯題最重要的是「說出理由」。孩子答完後，請她用一句話說明：「因為……所以……」。'},science:{desc:'熊為什麼冬眠？小鳥怎麼蓋房子？從動物和大自然認識科學。'}}};
const WORLD_BADGES={
 princess:{'debut':['第一場舞會','完成第一回合練習'],'two-way':['雙重魔法','同一天練習兩科以上'],'all-four':['全能公主','英文、數學、邏輯、科學都練過'],'perfect':['完美魔法','一回合全部答對'],'runs10':['十頂皇冠','累積 10 頂皇冠'],'runs50':['五十頂皇冠','累積 50 頂皇冠'],'runs100':['百冠女王','累積 100 頂皇冠'],'streak3':['連續三天','連續 3 天都有練習'],'streak7':['一週小天使','連續 7 天都有練習'],'review10':['錯題剋星','複習題答對 10 題'],'logic5':['聰明小公主','完成 5 回合邏輯練習'],'science5':['小小科學家','完成 5 回合科學練習']},
 animals:{'debut':['森林初探險','完成第一回合練習'],'two-way':['雙倍探險','同一天練習兩科以上'],'all-four':['全能小隊長','英文、數學、邏輯、科學都練過'],'perfect':['滿分小動物','一回合全部答對'],'runs10':['十根紅蘿蔔','累積 10 根紅蘿蔔'],'runs50':['五十根紅蘿蔔','累積 50 根紅蘿蔔'],'runs100':['紅蘿蔔大王','累積 100 根紅蘿蔔'],'streak3':['連續三天','連續 3 天都有練習'],'streak7':['勤勞小松鼠','連續 7 天都有練習'],'review10':['錯題剋星','複習題答對 10 題'],'logic5':['聰明貓頭鷹','完成 5 回合邏輯練習'],'science5':['森林科學家','完成 5 回合科學練習']}};
const ALPHA_B={baseball:null,girl:{word:'bear',meaning:'熊',icon:'🐻'}};const ZY_Q={girl:{word:'氣球',zy:'ㄑㄧˋ ㄑㄧㄡˊ',icon:'🎈'}};
let appliedWorld=null;
function applyWorld(){snapshotBase();const w=currentWorld();if(w===appliedWorld)return;appliedWorld=w;const B=BASE_DATA;
 if(w==='baseball'){setArr(LINEUP_NAMES,B.names);setArr(PATTERN_SYMBOLS,B.pattern);setArr(COUNT_ICONS,B.count);setArr(TRUTH_EVENTS,B.truth);setArr(ORDER_SCENES,B.order);setArr(ASSIGN_SCENES,B.assign);setArr(ODD_BANK,B.odd);setArr(RULES_BANK,B.rules);for(const k of Object.keys(SCIENCE_BANK))setArr(SCIENCE_BANK[k],B.sci[k]);
  for(const lv of [1,2,3,4]){setArr(VOCAB[lv],B.vocab[lv]);setArr(READ[lv],B.read[lv]);setArr(WORD_USE[lv],B.use[lv]);setArr(DEEP_READ[lv],B.deep[lv])}}
 else{const names=WORLD_NAMES[w];setArr(LINEUP_NAMES,names);setArr(PATTERN_SYMBOLS,WORLD_PATTERN[w]);setArr(COUNT_ICONS,Object.keys(WORLD_COUNT[w]));Object.assign(COUNT_NAMES,WORLD_COUNT[w]);setArr(TRUTH_EVENTS,WORLD_TRUTH[w]);setArr(ORDER_SCENES,WORLD_ORDER[w]);setArr(ASSIGN_SCENES,WORLD_ASSIGN[w]);
  setArr(ODD_BANK,[...cleanBank(B.odd),...GIRL_ODD]);setArr(RULES_BANK,nameBank(GIRL_RULES,shuffle(names).slice(0,3)));
  for(const k of Object.keys(SCIENCE_BANK))setArr(SCIENCE_BANK[k],k==='space'?B.sci[k]:[...cleanBank(B.sci[k]),...(GIRL_SCIENCE[k]||[])]);
  for(const lv of [1,2,3,4]){const v=[...B.vocab[lv].filter(x=>!BASEBALL_EN.test(x[0])&&!hasBaseball(x[1])),...GIRL_VOCAB[lv]];setArr(VOCAB[lv],v);const words=new Set(v.map(x=>x[0]));
   setArr(READ[lv],[...B.read[lv].filter(x=>!BASEBALL_EN.test(x[0])&&!hasBaseball(x[1]+x[2].join()+x[4])),...GIRL_READ[lv]]);
   setArr(WORD_USE[lv],[...B.use[lv].filter(x=>!BASEBALL_EN.test(x[0])&&!hasBaseball(x[2])&&words.has(x[1])),...GIRL_USE[lv]]);
   setArr(DEEP_READ[lv],[...B.deep[lv].filter(x=>!BASEBALL_EN.test(x[0])&&!hasBaseball(x[1]+x[2]+x[3].join()+x[4]+x[5])),...GIRL_DEEP[lv]])}}
 Object.assign(ALPHABET[1],w==='baseball'?BASE_DATA.alphaB:ALPHA_B.girl);Object.assign(ZHUYIN.find(z=>z.sym==='ㄑ'),w==='baseball'?BASE_DATA.zyQ:ZY_Q.girl);
 // 題型名稱、科目說明、徽章
 for(const [s,arr] of Object.entries(MODES))arr.forEach((m,i)=>{const b=B.modes[s][i];if(b)Object.assign(m,b);const o=WORLD_MODE_TEXT[w]?.[s]?.[m.id];if(o){if(o[0])m.name=o[0];if(o[1])m.desc=o[1];if(o[2])m.icon=o[2]}});
 for(const [k,v] of Object.entries(SUBJECT_META)){Object.assign(v,B.meta[k]);Object.assign(v,WORLD_META[w]?.[k]||{})}
 BADGES.forEach((b,i)=>{Object.assign(b,B.badges[i]);const o=WORLD_BADGES[w]?.[b.id];if(o){b.name=o[0];b.desc=o[1]}});
 try{document.title=worldInfo().name+'｜國語 × 注音 × 英文 × 數學 × 邏輯 × 科學'}catch(_){}}
// 出題：公主／動物世界會轉換用語，並排除任何仍帶棒球用語的題目
const _genV31=generateQuestions;
generateQuestions=function(sub,m,lv){applyWorld();const w=currentWorld();if(w==='baseball'||['science','chinese','english','zhuyin'].includes(sub))return _genV31(sub,m,lv);
 if(m==='review')return _genV31(sub,m,lv).map(q=>worldize(q,w));
 const want=data.settings.roundSize||8,out=[],seen=new Set();for(let t=0;t<8&&out.length<want;t++){for(const q0 of _genV31(sub,m,lv)){const q=worldize(q0,w);if(seen.has(q.signature)||hasBaseball(questionText(q)))continue;seen.add(q.signature);out.push(q);if(out.length>=want)break}}
 return out};

// ===== v33：登入頁（選擇小朋友），每個人進入自己的學院 =====
const PICKED_KEY='homerun_picked_v1';
const STYLE_CHOICES=[['field','⚾ 棒球','小小探索學院'],['space','🚀 太空探險','小小探索學院'],['princess','👑 公主城堡','小小探索學院'],['animals','🐰 可愛動物','小小探索學院']];
const worldNameOf=p=>WORLD_INFO[['princess','animals','space'].includes(p.theme)?p.theme:'baseball'];
function styleSelect(cur){return `<select name="theme" aria-label="風格">${STYLE_CHOICES.map(([k,l])=>`<option value="${k}" ${k===cur?'selected':''}>${l}</option>`).join('')}</select>`}
function loginPage(){const list=profiles.list;return `<main class="login-wrap"><div class="login-logo" aria-hidden="true">⚾ 🚀 👑 🐰</div><h1>今天誰要來學習？</h1><p class="login-sub">點自己的卡片，進入自己的學院</p>
 <div class="login-tools"><button type="button" class="btn btn-dark" data-action="nav-parent">📋 家長區</button><button type="button" class="btn btn-outline" data-action="guide-open">❔ 使用說明</button></div><div class="login-grid">${list.map(p=>{const wi=worldNameOf(p);return `<button class="login-card theme-${p.theme}" data-action="login-pick" data-id="${p.id}"><span class="lc-avatar" aria-hidden="true">${p.avatar}</span><strong>${h(p.name)}</strong><small>${wi.icon} ${wi.name}</small><small class="lc-grade">${GRADES[p.grade]}</small></button>`}).join('')}</div>
 ${list.length<6?`<details class="login-add" ${list.length<2?'open':''}><summary>＋ 新增小朋友</summary><form class="login-form" data-player-form="new-login"><label>名字<input name="name" maxlength="12" required placeholder="例如：妹妹"></label><label>頭像<select name="avatar">${AVATARS.map(a=>`<option>${a}</option>`).join('')}</select></label><label>畫面風格${styleSelect('princess')}</label><label>年級<select name="grade">${Object.entries(GRADES).map(([k,v])=>`<option value="${k}" ${k==='k'?'selected':''}>${v}</option>`).join('')}</select></label><button class="btn btn-dark" type="submit">建立並進入</button></form></details>`:''}
 <p class="note login-note">每個小朋友的紀錄、難度、風格都分開保存。修改或刪除請進入後到「家長區 → 小朋友管理」。</p></main>`}
function pickPlayer(id){try{sessionStorage.setItem(PICKED_KEY,'1')}catch(_){}switchPlayer(id)}
// 修正：公主／動物風格在讀取球員資料之後才登記，重新讀一次，避免風格被重設成棒球
profiles=loadProfiles();

// ===== v35：容易混淆的注音不放在同一題（家長指定） =====
// 易混淆符號仍需練習辨識；不可因同時含有不同韻母而跳過語詞或換成其他題型。
function deepQuestion(level,used){const pool=DEEP_READ[level],index=pool.map((x,i)=>({x,i})).filter(v=>!used.has('deep-'+level+'-'+v.i));const {x,i}=one(index.length?index:pool.map((x,i)=>({x,i})));return {skill:x[6],prompt:'📖 先讀完故事，再根據線索回答',main:x[0],second:x[1],answer:x[2],choices:shuffle(x[3]),explain:x[4],hint:x[5],signature:'deep-'+level+'-'+i,concept:'deep-'+x[6],isEnglish:true,readingOnly:true,speech:x[0]};}
function reasonQuestion(level,concept=null){const patterns=[];
 function add(id,make){patterns.push({id,make})}
 if(level===1){
  add('find-missing',()=>{const x=rand(3,10),y=rand(2,8),tot=x+y;return [`球盒原有 ${x} 顆球，教練又放了一些進去，現在共有 ${tot} 顆。教練放了幾顆？`,y,`先想：${x}＋□＝${tot}。所以 □＝${tot}−${x}＝${y}。`,'總數−原有＝新增。']});
  add('two-step',()=>{const a=rand(5,11),b=rand(3,6),c=rand(1,a+b-1),v=a+b-c;return [`今天球隊先拿 ${a} 顆球，再借到 ${b} 顆，後來收走 ${c} 顆。現在有幾顆？`,v,`${a}＋${b}＝${a+b}；${a+b}−${c}＝${v}。`,'分兩步算：先增加，再減少。']});
  add('compare',()=>{const x=rand(6,13),d=rand(2,7),y=x+d;return [`阿明有 ${x} 張棒球卡，阿宇有 ${y} 張。阿宇比阿明多幾張？`,d,`${y}−${x}＝${d} 張。`,'「比⋯多幾個」要找差。']});
  add('group',()=>{const each=rand(2,4),groups=rand(2,4),total=each*groups;return [`有 ${groups} 位小朋友，每人拿到 ${each} 顆球。總共需要幾顆？`,total,`把 ${each} 加 ${groups} 次，或用 ${groups}×${each}＝${total}。`,'先看每人幾顆，再看有幾人。']});
  add('order',()=>{const x=rand(3,8),y=rand(1,x-1),addend=rand(1,5);return [`球隊原有 ${x} 顆球，借出 ${y} 顆後又買了 ${addend} 顆。現在有幾顆？`,x-y+addend,`先借出：${x}−${y}＝${x-y}；再買：${x-y}＋${addend}＝${x-y+addend}。`,'注意借出和買進的先後。']});
  add('which-more',()=>{const a=rand(6,9),b=rand(5,9),c=rand(1,4),d=rand(1,4);return [`紅隊上午拿 ${a} 分、下午拿 ${b} 分；藍隊上午拿 ${c} 分、下午拿 ${d} 分。紅隊比藍隊多幾分？`,a+b-c-d,`紅隊 ${a}＋${b}＝${a+b}；藍隊 ${c}＋${d}＝${c+d}；相差 ${a+b-c-d}。`,'先分別求兩隊總分，再比較差。']});
  add('money',()=>{const a=rand(2,5)*10,b=rand(1,3)*5,paid=a+b+rand(1,3)*10;return [`買一本筆記本 ${a} 元、一支鉛筆 ${b} 元，付了 ${paid} 元。找回多少元？`,paid-a-b,`一共 ${a}＋${b}＝${a+b} 元；${paid}−${a+b}＝${paid-a-b} 元。`,'先算花了多少，再算找零。']});
  add('bar',()=>{const red=rand(3,7),blue=rand(1,6),green=rand(2,5);return [`練習紀錄（每個 ⚾ 表示 1 次）：\n紅隊：${'⚾'.repeat(red)}\n藍隊：${'⚾'.repeat(blue)}\n綠隊：${'⚾'.repeat(green)}\n三隊共完成幾次練習？`,red+blue+green,`${red}＋${blue}＋${green}＝${red+blue+green} 次。`,'按每隊圖示數量相加。','math-data']});
 }else if(level===2){
  add('multi',()=>{const groups=rand(3,6),each=rand(4,8),used=rand(5,groups*each-4);return [`教練買了 ${groups} 袋球，每袋 ${each} 顆，已拿出 ${used} 顆使用。還剩幾顆？`,groups*each-used,`先算總數：${groups}×${each}＝${groups*each}；減去 ${used}，剩 ${groups*each-used}。`,'先乘再減。']});
  add('unknown',()=>{const per=one([2,5,10]),bags=rand(3,7),all=per*bags;return [`一共有 ${all} 顆球，平均裝進 ${bags} 個袋子。每袋幾顆？`,per,`${all}÷${bags}＝${per} 顆。`,'知道總數和袋數，可以平均分。']});
  add('money',()=>{const x=rand(3,8)*10,y=rand(2,6)*5,cost=x+y,paid=Math.ceil(cost/100)*100+100;return [`運動水壺 ${x} 元、筆記本 ${y} 元。帶了 ${paid} 元，全部買下後剩多少？`,paid-cost,`先算 ${x}＋${y}＝${cost} 元，再算 ${paid}−${cost}＝${paid-cost} 元。`,'錢夠不夠？先算合計。','math-money']});
  add('table',()=>{const r1=rand(3,9),r2=rand(2,8),b1=rand(3,9),b2=rand(1,7);return [`兩局得分表：\n隊伍　第一局　第二局\n紅隊　${r1}　　　${r2}\n藍隊　${b1}　　　${b2}\n兩隊合計得了幾分？`,r1+r2+b1+b2,`紅隊 ${r1+r2}，藍隊 ${b1+b2}；合計 ${r1+r2+b1+b2}。`,'四個數字都要加，不要只看一列。','math-data']});
  add('time',()=>{const h=rand(8,16),start=one([0,15,30]),dur=one([15,30,45]),tm=h*60+start+dur;const hh=Math.floor(tm/60),mm=tm%60;return [`練習從 ${String(h).padStart(2,'0')}:${String(start).padStart(2,'0')} 開始，練習了 ${dur} 分鐘，幾點結束？`,`${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}`,`把 ${dur} 分鐘加到開始時間，得到 ${String(hh).padStart(2,'0')}:${String(mm).padStart(2,'0')}。`,'注意分鐘滿60要進一小時。','math-money','time']});
  add('average-groups',()=>{const per=rand(3,8),n=rand(3,6),extra=rand(1,4);return [`每個小組需要 ${per} 顆球，共有 ${n} 個小組，另外增加 ${extra} 顆備用球，全部需要多少？`,per*n+extra,`${per}×${n}＝${per*n}；再加 ${extra}＝${per*n+extra}。`,'先算每組，再加備用。']});
  add('reverse',()=>{const x=rand(15,40),take=rand(5,14);return [`一箱球原來有一些球。教練取出 ${take} 顆後還有 ${x} 顆，原來有多少顆？`,x+take,`原有＝剩下 ${x}＋拿出 ${take}＝${x+take}。`,'反向想：取出的要補回。']});
  add('compare',()=>{const r=rand(13,30),b=rand(11,28),bonus=rand(3,9);return [`紅隊兩天練習 ${r} 次，藍隊兩天 ${b} 次。藍隊又增加 ${bonus} 次，現在兩隊相差幾次？`,Math.abs(r-(b+bonus)),`藍隊更新為 ${b}+${bonus}＝${b+bonus}；差 ${Math.abs(r-(b+bonus))} 次。`,'先更新藍隊，再比較兩隊。']});
 }else{
  add('budget',()=>{const price=rand(4,9)*10,n=rand(3,6),budget=price*n+rand(2,6)*10;return [`球隊準備買 ${n} 個水壺，每個 ${price} 元，預算 ${budget} 元。買完還剩多少預算？`,budget-price*n,`總價 ${price}×${n}＝${price*n}；預算剩 ${budget}−${price*n}＝${budget-price*n} 元。`,'先乘出總價，再跟預算比較。','math-money']});
  add('travel',()=>{const a=rand(2,7)*10,b=rand(3,8)*10,c=rand(1,5)*10;return [`從家到球場：先走 ${a} 公尺，再走 ${b} 公尺，最後走 ${c} 公尺。全程幾公尺？`,a+b+c,`${a}＋${b}＋${c}＝${a+b+c} 公尺。`,'把三段長度合併。']});
  add('tickets',()=>{const n=rand(3,8),p=rand(4,9)*10,discount=rand(1,3)*10;return [`${n} 張入場券每張 ${p} 元，團體購票總共折扣 ${discount} 元。最後要付多少？`,n*p-discount,`${n}×${p}＝${n*p} 元；扣掉 ${discount}，付 ${n*p-discount} 元。`,'先乘原價，再減折扣。','math-money']});
  add('table',()=>{const a=rand(4,9),b=rand(3,7),c=rand(2,8),d=rand(4,9);return [`安打統計：\n　　　週一　週三\n甲組　 ${a}　　 ${b}\n乙組　 ${c}　　 ${d}\n甲組兩天安打數比乙組多幾支？（若較少，填差距）`,Math.abs(a+b-c-d),`甲組 ${a+b}，乙組 ${c+d}；相差 ${Math.abs(a+b-c-d)} 支。`,'先計算兩組合計，再取差距。','math-data']});
  add('two-mult',()=>{const a=rand(3,8),b=rand(3,7),c=rand(2,6),d=rand(1,4);return [`每箱有 ${a} 顆球，買了 ${b} 箱；又收到 ${c} 袋、每袋 ${d} 顆。總共多少顆球？`,a*b+c*d,`${a}×${b}＝${a*b}；${c}×${d}＝${c*d}；合計 ${a*b+c*d}。`,'兩種包裝分開算，再加在一起。']});
  add('fraction',()=>{const total=one([12,16,20,24]),part=total/4;return [`班上共有 ${total} 人，其中四分之一參加棒球社。棒球社有幾人？`,part,`把 ${total} 平均分成4組，每組 ${total}÷4＝${part} 人。`,'四分之一代表平均分成4份、取1份。']});
  add('op-order',()=>{const a=rand(3,7),b=rand(4,8),c=rand(4,15);return [`教練準備 ${a} 盒球，每盒 ${b} 顆，又多拿 ${c} 顆。總數是？`,a*b+c,`先算 ${a}×${b}＝${a*b}，再加 ${c}＝${a*b+c}。`,'別把盒數跟每盒顆數直接相加。']});
  add('reverse',()=>{const n=rand(5,9),per=rand(3,8),given=rand(3,12);return [`球袋中原有一些球，分別發給 ${n} 個人、每人 ${per} 顆後，還剩 ${given} 顆。原來有多少？`,n*per+given,`發出去 ${n}×${per}＝${n*per}，加上剩餘 ${given}＝${n*per+given}。`,'要倒回去：原有＝發出＋剩下。']});
 }
 const chosen=(patterns.find(x=>x.id===concept)||one(patterns));const made=chosen.make();const [main,ans,explain,hint,skill='math-reason',form='number']=made;
 let choices;if(form==='time'){
  const [hh,mm]=String(ans).split(':').map(Number),tm=hh*60+mm;const offsets=[-30,-15,15,30,45];const set=new Set([ans]);for(const offset of shuffle(offsets)){const x=tm+offset;if(x>=0&&x<1440)set.add(String(Math.floor(x/60)).padStart(2,'0')+':'+String(x%60).padStart(2,'0'));if(set.size===4)break}choices=shuffle([...set]);
 }else choices=choicesForAnswer(ans,level);
 return {skill,prompt:'🧩 不只算答案，先想要分成哪幾步',main,answer:String(ans),choices,explain,hint,signature:'reason-'+level+'-'+chosen.id+'-'+main,concept:chosen.id,reason:true};
}
function safeReviewQuestion(q){if(!q||typeof q!=='object'||typeof q.main!=='string'||typeof q.answer!=='string'||!Array.isArray(q.choices)||q.choices.length!==4||!q.choices.every(x=>typeof x==='string')||new Set(q.choices).size!==4||!q.choices.includes(q.answer)||!Object.prototype.hasOwnProperty.call(SKILLS,q.skill)||q.main.length>650||q.explain?.length>800)return null;
 const result={};for(const k of ['skill','prompt','main','second','answer','explain','hint','signature','concept','speech','zySym','zyAnswerSym','zhSound','courseLabel','cnLessonId','sciCourseId'])if(typeof q[k]==='string')result[k]=q[k].slice(0,800);
 result.choices=q.choices.map(x=>String(x).slice(0,120));for(const k of ['isEnglish','isListening','readingOnly','reason','showAudio','noReadMain','noReadOptions','bigChoices','gridMain'])if(typeof q[k]==='boolean')result[k]=q[k];return result;
}
function sanitizeReviewQueue(raw){if(!Array.isArray(raw))return [];return raw.slice(-140).flatMap(e=>{if(!e||!SUBJECT_KEYS.includes(e.subject)||!MODES[e.subject].some(m=>m.id===e.mode)||e.mode==='review'||typeof e.id!=='string'||!Number.isFinite(+e.dueAt))return [];const q=safeReviewQuestion(e.q);if(!q)return [];return [{id:e.id.slice(0,75),subject:e.subject,mode:e.mode,level:[1,2,3,4].includes(+e.level)?+e.level:1,q,stage:Math.min(3,Math.max(0,Number(e.stage)||0)),dueAt:+e.dueAt,lastAttemptAt:Number(e.lastAttemptAt)||0,misses:Math.min(30,Math.max(1,Number(e.misses)||1))}]})}
function dueReviews(sub=null){if(data.settings.reviewEnabled===false)return [];return data.reviewQueue.filter(e=>(!sub||e.subject===sub)&&canPractice(e.subject,e.mode)&&(e.mode==='times'||e.level<=effectiveLevel(e.subject,e.level))&&e.dueAt<=Date.now()).sort((a,b)=>a.dueAt-b.dueAt)}
function newReviewMiss(q,s){if(data.settings.reviewEnabled===false)return;const safe=safeReviewQuestion(q);if(!safe)return;const same=data.reviewQueue.find(x=>x.subject===s.subject&&x.mode===s.mode&&x.level===s.level&&x.q.signature===q.signature);if(same){same.misses=Math.min(30,same.misses+1);same.stage=0;same.dueAt=Date.now();same.q=safe;return}
 const id=String(Date.now())+'-'+String(Math.random()).slice(2,10);data.reviewQueue.push({id,subject:s.subject,mode:s.mode,level:s.level,q:safe,stage:0,dueAt:Date.now(),lastAttemptAt:0,misses:1});data.reviewQueue=data.reviewQueue.slice(-140);
}
function markReview(q,ok){const idx=data.reviewQueue.findIndex(x=>x.id===q.reviewId);if(idx<0)return;const item=data.reviewQueue[idx];if(ok){item.stage++;if(item.stage>=4){data.reviewQueue.splice(idx,1);return}const days=[0,1,3,7][item.stage];item.dueAt=Date.now()+days*86400000;item.lastAttemptAt=Date.now();}
 else{item.stage=0;item.dueAt=Date.now()+86400000;item.lastAttemptAt=Date.now();item.misses=Math.min(30,item.misses+1)}
}
function freshReviewQuestion(item){
 applyWorld();
 if(item.subject==='math'&&item.mode==='story'&&grade()==='g1')return {...worldize(gradeStoryQuestion(),currentWorld()),reviewId:item.id,reviewLevel:1};
 if(item.subject==='english'&&['letters','vocab','listen','sentence','use','deep'].includes(item.mode)){
 const lv=effectiveLevel('english',item.level),q=item.mode==='deep'?deepQuestion(lv,new Set()):englishQuestion(lv,item.mode,new Set());return {...q,reviewId:item.id,reviewLevel:lv};}
if(item.subject==='math'&&item.mode==='calc'&&grade()!=='g3'){const q=worldize(gradeCalculation(effectiveLevel('math',item.level)),currentWorld());return {...q,reviewId:item.id,reviewLevel:effectiveLevel('math',item.level)}}if(item.subject==='math'&&item.mode==='measure'&&grade()==='g2'){const q=worldize(measureQuestion(1,one([0,1,3,4,5,7])),currentWorld());return {...q,reviewId:item.id,reviewLevel:1}}if(item.subject==='chinese'){const pool=cnBank(CN.lessons),q=pool.find(q=>q.signature===item.q.signature)||pool.find(q=>q.cnLessonId===item.q.cnLessonId)||pool[0];return {...q,reviewId:item.id,reviewLevel:item.level}} {const w=freshV26Review(item);if(w){w.reviewId=item.id;w.reviewLevel=item.level;return w}}{const v=freshV25Review(item);if(v){v.reviewId=item.id;v.reviewLevel=item.level;return v}}if(item.subject==='logic'||item.subject==='science'){const q=freshNewSubjectReview(item);q.reviewId=item.id;q.reviewLevel=item.level;return q}let q=structuredClone(item.q);if(item.subject==='math'){try{if(item.mode==='reason'&&item.q.concept)q=reasonQuestion(item.level,item.q.concept);else if(item.mode==='calc')q=calcQuestion(item.level);else if(['story','score'].includes(item.mode))q=storyQuestion(item.level,item.mode==='score')}catch(_){}}
 if(item.subject==='english'&&item.mode==='deep'){const pool=DEEP_READ[item.level],alt=pool.map((x,i)=>i).filter(i=>('deep-'+item.level+'-'+i)!==item.q.signature&&xSkill(pool[i][6])===xSkill(item.q.skill));if(alt.length){const v=pool[one(alt)],ix=pool.indexOf(v);q={skill:v[6],prompt:'📖 先讀完故事，再根據線索回答',main:v[0],second:v[1],answer:v[2],choices:shuffle(v[3]),explain:v[4],hint:v[5],signature:'deep-'+item.level+'-'+ix,concept:'deep-'+v[6],isEnglish:true,readingOnly:true,speech:v[0]}}}
 q.reviewId=item.id;q.reviewLevel=item.level;return q;
}
function xSkill(s){return String(s||'')}
function reviewSuggestion(){const en=dueReviews('english').length,ma=dueReviews('math').length,lo=dueReviews('logic').length,sc=dueReviews('science').length,zy=dueReviews('zhuyin').length,cn=dueReviews('chinese').length;const recent=data.sessions.slice(-12).flatMap(s=>Array.isArray(s.attempts)?s.attempts:[]).filter(a=>a&&typeof a==='object'&&Object.prototype.hasOwnProperty.call(SKILLS,a.skill));const by=new Map();for(const r of recent){const arr=by.get(r.skill)||[];arr.push(r.correct);by.set(r.skill,arr)}let worst=[...by].filter(x=>x[1].length>=3).map(([skill,a])=>({skill,p:a.filter(Boolean).length/a.length})).sort((a,b)=>a.p-b.p)[0];return {en,ma,lo,sc,zy,cn,total:en+ma+lo+sc+zy+cn,worst};}

function generateQuestionsBase(sub,m,lv){if(m==='review')return dueReviews(sub).slice(0,8).map(freshReviewQuestion);if(sub==='zhuyin')return roundFrom(u=>zhuyinQuestion(lv,m,u));if(sub==='math'&&['count','compare','add10'].includes(m))return roundFrom(()=>kidMathQuestion(m,lv));if(sub==='logic'||sub==='science')return generateNewSubjectRound(sub,m,lv);
 const list=[],used=new Set(),fixedKinds=shuffle([0,1,2,3,4,5,6,7]);for(let i=0;i<8;i++){let q,k=0;do{q=sub==='english'?(m==='deep'?deepQuestion(lv,used):englishQuestion(lv,m,used)):m==='reason'?reasonQuestion(lv):m==='pattern'?patternQuestion(lv,fixedKinds[i]):m==='measure'?measureQuestion(lv,fixedKinds[i]):m==='calc'?calcQuestion(lv):storyQuestion(lv,m==='score');k++}while(used.has(['reason','pattern','measure'].includes(m)?q.concept:q.signature)&&k<60);used.add(['reason','pattern','measure'].includes(m)?q.concept:q.signature);list.push(q)}
 // 正常練習也帶入近期錯題（最多2題），並保留其他題目的廣度。
 if(data.settings.reviewEnabled&&m!=='letters'&&m!=='deep'&&m!=='reason'){const pending=dueReviews(sub).filter(e=>e.mode===m).slice(0,2);for(let i=0;i<pending.length;i++)list[5+i]=freshReviewQuestion(pending[i]);}
 return list}
function start(m){handInk=[];handAnswerInk=[];handOcrResult='';handQuizOpen=false;handResult='';clearAdvance();if(!canPractice(subject,m))return;mode=m;let items=practiceQuestions(subject,m,data.settings[subject]);if(!items.length){toast('目前沒有到期錯題，先練習新題目吧！');return;}session={subject,mode,level:effectiveLevel(subject),items,idx:0,correct:0,attempts:[],missed:[],usedHint:false};feedback=null;page='quiz';window.scrollTo(0,0);render();focusLesson();autoReadSoon()}

function quiz(){if(!session)return '';const q=session.items[session.idx],selected=feedback?.selected??null;const m=MODES[session.subject].find(x=>x.id===session.mode),tot=session.items.length;return `<div class="quiz-wrap"><div class="quiz-top"><button class="quit" data-action="quit">✕ 暫停練習</button><span class="quiz-progress">${m.name} · 第 ${session.idx+1} / ${tot} 題</span></div><div class="track" role="progressbar" aria-valuemin="0" aria-valuemax="${tot}" aria-valuenow="${session.idx}" aria-label="練習進度"><div class="fill" style="width:${session.idx/tot*100}%"></div></div><section class="quiz-card" style="--qaccent:${SUBJECT_COLOR[session.subject]||'var(--navy)'}"><span class="topiccap">${m.icon} ${m.label}　｜　${q.courseLabel?h(q.courseLabel):session.subject==='chinese'?'二年級國語':q.skill==='math-times'?'九九乘法 1～9（不分難度）':'難度 '+(q.reviewLevel||session.level)} ${q.reviewId?'· 🔁 複習題':''}</span><div class="question-prompt">${h(q.prompt)}</div><div class="question-main ${q.isEnglish?'question-en':''} ${q.gridMain?'grid':isEmojiMain(q)?'emoji':!q.isEnglish&&q.main.length>34?'long':''}" style="white-space:pre-line" ${q.isEnglish?'lang="en"':''}>${h(q.main)}</div>${q.second?`<div style="font-weight:800;margin:2px 0 13px">❓ ${h(q.second)}</div>`:''}<div class="read-row"><button type="button" class="speaker zh" data-action="speak-q">🔊 唸題目給我聽</button>${q.zhSound?'<button type="button" class="speaker" data-action="speak-zh-sound">🎧 播放聲音</button>':''}</div>${q.speech?`<button type="button" class="speaker" data-action="speak">${isEnglishSentence(q.speech)?'🔊 聽自然英文句型 <small>0.93 倍・清楚不斷句</small>':'🔊 播放英文發音 <small>可以重複聽</small>'}</button>${isEnglishSentence(q.speech)?'<button type="button" class="speech-test" data-action="speak-slower" style="margin-bottom:12px;margin-left:8px">🐢 再慢一點（0.86 倍）</button>':''}<div class="speech-status" id="speech-status" role="status" aria-live="polite"></div>${q.isListening&&!q.choices.some(c=>c.replace(/\s/g,'').toLowerCase().includes(String(q.speech).replace(/\s/g,'').toLowerCase()))?`<button type="button" data-action="transcript" style="display:block;background:none;border:0;color:#718490;font-size:12px;padding:0 3px">聽不清楚？顯示英文提示</button><div id="transcript" class="hidden note" style="margin-top:7px" lang="en">${h(q.speech)}</div>`:''}`:''}${q.readingOnly?'<div class="tipline">📚 這是自主閱讀關卡：先自己讀、圈出線索；不必搶快，也不用一次全懂。</div>':''}${q.hint&&!feedback?`<div class="hint-box"><button type="button" class="hint-toggle" data-action="hint">💭 不知道怎麼開始？看思路提示</button>${session.usedHint?`<p class="hint-text">${h(q.hint)}</p>`:''}</div>`:''}<button type="button" class="hw-quiz-toggle" data-action="quiz-handwrite" aria-expanded="${handQuizOpen}">✍️ ${session.subject==='math'?'手寫計算草稿':session.subject==='english'?'手寫英文草稿':'手寫思考草稿'}　${handQuizOpen?'▲ 收起':'▼ 展開'}（可用手指／Apple Pencil）</button>${handQuizOpen?`<section class="hw-quiz-box">${handPadMarkup('',false,true)}${session.subject==='math'?handRecognizerControls('math'):session.subject==='english'?handRecognizerControls('english'):''}${session.subject==='math'?`<form class="hw-check" data-hw-form="quiz"><div class="hw-field"><label for="hw-check-input">算好後輸入答案驗算</label><input id="hw-check-input" inputmode="decimal" autocomplete="off" placeholder="例如：24" aria-label="輸入計算答案"></div><button class="btn btn-dark" type="submit">✅ 驗算</button></form><div class="hw-message" id="hw-feedback" role="status" aria-live="polite">${h(handResult)}</div>`:''}<p class="hw-note">試用免費本機筆跡辨識；辨識可能有誤，請確認自動填入的答案後，再按核對或驗算。原本的選擇題分數不受影響。</p></section>`:''}<div class="optiongrid ${q.bigChoices?'big':''}" role="group" aria-label="選擇答案">${q.choices.map((o,i)=>{const correct=feedback&&o===q.answer,wrong=feedback&&o===selected&&o!==q.answer;return `<button class="option ${correct?'correct':''} ${wrong?'incorrect':''}" data-action="answer" data-choice="${i}" ${feedback?'disabled':''}><span class="letter">${'ABCD'[i]}</span><span>${h(o)}</span></button>`}).join('')}</div>${feedback?`<div role="status" aria-live="polite" class="feedback ${feedback.correct?'':'bad'}"><strong>${feedback.correct?themeCopy().right:'💡 沒關係，我們一起看看'}</strong><p>正確答案：<b>${h(q.answer)}</b><br>${h(q.explain)}</p>${session.mode==='use'?'<button class="speech-test" type="button" data-action="speak-answer">🔊 聽正確單字</button>':''}${q.zyAnswerSym?`<button class="speech-test" type="button" data-action="zy-play-answer">🔊 聽「${h(q.zyAnswerSym)}」</button>`:''}${q.reviewId?'<p class="auto-next-hint">🔁 複習題：即使答對，也會隔一段時間再複習，確認真的記得。</p>':''}${feedback.correct&&data.settings.autoNext&&!handQuizOpen&&!q.reason&&!q.readingOnly?'<p class="auto-next-hint">⏳ 至少停留 6 秒後繼續；可以按下方按鈕慢慢看。<button type="button" class="speech-test" data-action="stay-feedback">📖 我要慢慢看</button></p>':(q.reason||q.readingOnly)?'<p class="auto-next-hint">🧠 深度題不自動跳題，請想一想解題思路再繼續。</p>':!feedback.correct?'<p class="auto-next-hint">先看懂解析，再按下一題。</p>':''}</div><button class="btn btn-dark quiz-next" data-action="next">${session.idx===tot-1?'看這回合的練習回顧':'下一題 →'}</button>`:''}</section><p class="mobile-note" style="text-align:center;margin-top:14px">不用搶快。答錯是找出學習方向的重要線索。</p></div>`}
function answer(choiceIndex){clearAdvance();if(!session||feedback)return;const q=session.items[session.idx],sel=q.choices[choiceIndex];if(sel===undefined)return;const ok=sel===q.answer;feedback={selected:sel,correct:ok};chime(ok);if(ok)session.correct++;else session.missed.push({main:(q.courseLabel?q.courseLabel+'\n':'')+(q.isListening?q.speech:q.main)+(q.second?'\n'+q.second:''),answer:q.answer,explain:q.explain});session.attempts.push({skill:q.skill,correct:ok,hintUsed:!!session.usedHint,review:!!q.reviewId,concept:q.concept||'',level:q.reviewLevel||session.level});if(q.reviewId)markReview(q,ok);else if(!ok)newReviewMiss(q,session);session.usedHint=false;render();if(ok&&data.settings.autoNext&&!handQuizOpen&&!q.reason&&!q.readingOnly){const currentSession=session,currentFeedback=feedback;advanceTimer=setTimeout(()=>{advanceTimer=null;if(page==='quiz'&&session===currentSession&&feedback===currentFeedback)next()},Math.max(6000,Math.min(20000,Array.from(q.explain||'').length*180)))}}
function next(){clearAdvance();if(!session||!feedback)return;session.idx++;feedback=null;handInk=[];handAnswerInk=[];handOcrResult='';handQuizOpen=false;handResult='';session.usedHint=false;if(session.idx>=session.items.length)finish();else{render();focusLesson();autoReadSoon()}}
function finish(){clearAdvance();const s=session;if(!s)return;const badgesBefore=new Set(earnedBadgeIds());finished={...s};const entry={date:new Date().toISOString(),subject:s.subject,mode:s.mode,level:s.level,total:s.items.length,correct:s.correct,attempts:s.attempts};rememberRound(s);data.sessions.push(entry);data.sessions=data.sessions.slice(-300);data.practiceDraft=null;save();finished.newBadges=earnedBadgeIds().filter(x=>!badgesBefore.has(x));page='result';session=null;window.scrollTo(0,0);render()}
function result(){if(!finished)return '';const s=finished,tot=s.items.length;const rate=Math.round(100*s.correct/tot),title=rate>=88?'今天完成了一場好練習！':rate>=63?'每一題都在讓你進步！':'錯的題目，就是下一次的起點！';const due=dueReviews(s.subject).length;return `<div class="result"><div class="result-hero"><div class="result-emoji" aria-hidden="true">${rate>=88?'🏆':rate>=63?worldInfo().icon:'🌱'}</div><h1>${title}</h1><p>${subName(s.subject)} · ${s.subject==='chinese'?'二年級':s.mode==='lesson'?'課後練習':s.mode==='times'?'九九乘法 1～9':'第 '+s.level+' 級'} · ${MODES[s.subject].find(m=>m.id===s.mode).name}</p><div class="result-score">${s.correct} <span style="font-size:20px">/ ${tot} 題</span></div><p>理解比速度重要；有錯題就透過下次練習慢慢補強。</p></div>${resultBallpark(s)}${s.missed.length?`<section class="card review"><h3>💡 今天可以再想一想的題目</h3><ul style="padding-left:20px">${s.missed.slice(0,4).map(x=>`<li>${h(x.main)}<br><strong>答案：${h(x.answer)}</strong>　${h(x.explain)}</li>`).join('')}</ul><p class="note">答錯題目會加入本機複習清單；如果已關閉複習功能，則只保留本回合的解析。</p></section>`:''}<section class="card reflection"><label for="reflection">💬 用一句話告訴家人：今天我學到……（可不填）</label><textarea id="reflection" maxlength="160" placeholder="例如：我知道 because 表示原因；我會先算總價再找零。"></textarea><div class="rowactions"><button class="btn btn-outline" data-action="save-reflection">儲存小心得</button></div></section><div class="result-buttons">${due?`<button class="btn btn-primary" data-action="review-sub" data-subject="${s.subject}">🔁 立即複習 ${due} 題</button>`:''}<button class="btn btn-dark" data-action="again">再練一次</button><button class="btn btn-outline" data-action="nav-home">回到首頁</button></div></div>`}

function getSkillStat(skill){const attempts=data.sessions.flatMap(s=>Array.isArray(s.attempts)?s.attempts:[]).filter(a=>a.skill===skill);const n=attempts.length,hit=attempts.filter(a=>a.correct).length;return {n,hit,pct:n?Math.round(hit/n*100):0}}
function subjectReport(sub){const x=getSubStats(sub),s=data.sessions.filter(x=>x.subject===sub),recent=s.slice(-4),rAcc=recent.length?Math.round(recent.reduce((a,x)=>a+x.correct,0)/recent.reduce((a,x)=>a+x.total,0)*100):null;return `<div style="display:flex;justify-content:space-between;gap:10px"><strong style="font-size:18px">${SUBJECT_META[sub].icon+' '+SUBJECT_META[sub].name}</strong><span class="tag">${sub==="chinese"?"二年級":"難度 "+data.settings[sub]}</span></div><div class="statrow" style="margin-top:14px"><div class="stat"><strong>${x.num}</strong><small>已完成回合</small></div><div class="stat"><strong>${rAcc===null?'—':rAcc+'%'}</strong><small>近4回合正確率</small></div></div>${recent.length?`<p class="note">${recent.length<2?'目前資料很少，先累積幾次練習。':recent.filter(x=>x.correct/x.total>=0.85).length>=2?'近4回合至少兩回合正確率達85%以上，可考慮先觀察孩子解題過程，再試進階。':'練習時可優先複習答錯的概念，不必急著升級。'}</p>`:`<p class="note">還沒有練習紀錄。先從基礎級玩一回合吧。</p>`}`}
function parent(){if(!parentUnlocked)return parentGate();const ss=data.sessions.slice(-8).reverse();const w=Object.values(SKILL_GROUPS).flat();const weakest=w.map(k=>({k,...getSkillStat(k)})).filter(x=>x.n>=5).sort((a,b)=>a.pct-b.pct).slice(0,2);return `<div class="pageheading"><div class="eyebrow">PARENT COACH CENTER</div><h1>📋 家長陪練中心</h1><p style="margin:2px 0 8px"><span class="pill">目前查看：${activeProfile().avatar} ${h(activeProfile().name)} · ${GRADES[grade()]}</span></p><p>陪孩子探索國語、英數與生活知識，依理解程度慢慢練習。</p></div><div class="parent-banner">🔒 <b>隱私說明：</b>這是單機試作版，不需要帳號，不會上傳學習紀錄。家長區設有本機密碼，可阻止孩子誤入，但無法取代正式帳號與伺服器權限管理。</div>${recoveryPanel()}${parentTabsNav()}<div class="ptabs" data-active="${parentTab}"><div class="ptab" data-tab="report"><div class="parent-grid">${SUBJECT_KEYS.map(sb=>`<section class="card"><h3>${subName(sb)}進度</h3>${subjectReport(sb)}</section>`).join('')}</div>
<div class="section-title"><div><h2>各項練習能力</h2><p>以練習題答對比例估算，不能當作正式能力鑑定。</p></div></div><div class="parent-grid">${SUBJECT_KEYS.map(sb=>`<section class="card"><h3>${SUBJECT_META[sb].icon} ${subName(sb)}能力</h3>${SKILL_GROUPS[sb].map(skillMeter).join('')}</section>`).join('')}</div>
<div class="section-title"><div><h2>個人化複習排程</h2><p>答錯先加入清單；答對後於1、3、7天再複習，逐步鞏固理解。這是設計規則，不是教育成效保證。</p></div></div><section class="card"><div class="statrow"><div class="stat"><strong>${data.reviewQueue.length}</strong><small>待鞏固概念</small></div><div class="stat"><strong>${dueReviews().length}</strong><small>目前可複習</small></div></div><div class="rowactions" style="margin-top:13px">${SUBJECT_KEYS.map(sb=>dueReviews(sb).length?`<button class="btn btn-outline" data-action="review-sub" data-subject="${sb}">${subName(sb)}複習 ${dueReviews(sb).length} 題</button>`:'').join('')}</div><p class="note">複習清單存在本機；答錯後可以當天再挑戰，接著按間隔安排下一次。大人應一起確認解題過程，不只看正確率。</p></section><div class="section-title"><div><h2>每週陪伴建議</h2><p>把練習學到的東西用回生活，比多刷幾題更重要。</p></div></div><div class="two-col"><section class="card"><h3>🏡 本週家中任務</h3><div class="mini-plan"><b>英文：</b>先認 3 個大小寫字母並聽發音，再找家裡 1 個物品學英文名稱。<br><b>數學：</b>去超市時請孩子估算 2～3 件商品的總價，再核對結果。<br><b>表達：</b>請孩子解釋一題他算對或算錯的題目，重點是「怎麼想」。<br><b>自主管理：</b>自己檢查球具與隔天上學用品。</div><p class="note">上面的生活任務是家長可自行調整的建議，不是標準化教育測驗。</p></section><section class="card"><h3>🧭 需要多一點陪練的地方</h3>${weakest.length?weakest.map(x=>`<p class="note">• <strong>${SKILLS[x.k]}</strong>：目前 ${x.hit}/${x.n} 題正確，適合一起回顧錯題與概念。</p>`).join(''):'<div class="empty">各項能力至少練過 5 題後，這裡才會提示值得複習的領域。</div>'}<div class="wellbeing" style="margin-top:16px">🌿 孩子疲倦、挫折或不想練時，可以直接結束，不用補做或追進度。</div></section></div>
</div><div class="ptab" data-tab="players">${playerManager()}</div><div class="ptab" data-tab="practice"><div class="section-title"><div><h2>練習難度設定</h2><p>請依孩子實際理解調整，不以年齡直接決定。</p></div></div><section class="card"><div class="settings-row"><label for="set-en">英文難度<small>字母 A～Z 不分難度。第1級生活與棒球單字；第2級句子較長；第3級抽象字詞與長篇推理；第4級菁英：段落閱讀與進階單字（約國小高年級）</small></label><select id="set-en" data-action="level" data-subject="english"><option value="1" ${data.settings.english===1?'selected':''}>1 基礎</option><option value="2" ${data.settings.english===2?'selected':''}>2 進階</option><option value="3" ${data.settings.english===3?'selected':''}>3 挑戰</option><option value="4" ${data.settings.english===4?'selected':''}>4 菁英</option></select></div><div class="settings-row"><label for="set-ma">數學難度<small>第1級：以20以內加減為主，含簡單乘法、時間與錢；第2級：100以內加減與九九乘法；第3級：三位數、除法與多步驟；第4級菁英：四位數、兩位數乘法、餘數、分數</small></label><select id="set-ma" data-action="level" data-subject="math"><option value="1" ${data.settings.math===1?'selected':''}>1 基礎</option><option value="2" ${data.settings.math===2?'selected':''}>2 進階</option><option value="3" ${data.settings.math===3?'selected':''}>3 挑戰</option><option value="4" ${data.settings.math===4?'selected':''}>4 菁英</option></select></div>${levelRow('zhuyin','set-zy','第1級符號辨認；第2級加入聲調與拼音、選項更相近；第3級容易混淆的符號一起出現')}${levelRow('logic','set-lo','第1級 3 人打序、簡單規律；第2級 4 人打序與棒球規則；第3級「如果……就……」推論')}${levelRow('science','set-sc','題目依級別累加；第1級生活觀察，第2～3級加入原理與科學方法')}<div class="settings-row"><label for="round-size">每回合題數<small>大班建議 5 題；覺得太少可以調到 8 或 10 題。</small></label><select id="round-size" data-action="round-size">${[5,8,10].map(v=>`<option value="${v}" ${(data.settings.roundSize||8)===v?'selected':''}>${v} 題</option>`).join('')}</select></div><p class="note">覺得太簡單：把難度調高一級，並試試數學「思考挑戰」、邏輯「數獨」「誰說謊」、英文「拼字」「句子重組」、注音「語詞注音」。第3級會增加閱讀難度、三位數與除法。若孩子不理解題目，建議先降級並補充口頭示範。</p></section>
<div class="section-title"><div><h2>答題節奏</h2><p>答對給短暫回饋、答錯保留解析，避免為了過關而忽略理解。</p></div></div><section class="card"><div class="settings-row"><label for="auto-next-toggle">答對自動下一題<small>預設手動繼續。開啟後至少停留 6 秒，長解析會多留時間；孩子也可按「我要慢慢看」。</small></label><input type="checkbox" id="auto-next-toggle" data-action="auto-next" ${data.settings.autoNext?'checked':''} style="width:24px;height:24px;accent-color:#1b9277"/></div><p class="note">建議：保留正確答案的簡短提示。數學應用題若需要時間理解，也可以關閉自動切題。</p></section>
<section class="card" style="margin-top:14px"><div class="settings-row"><label for="review-toggle">個人化錯題複習<small>答錯保留題目，安排當日、1天、3天與7天的重練。</small></label><input type="checkbox" id="review-toggle" data-action="review-enabled" ${data.settings.reviewEnabled?'checked':''} style="width:24px;height:24px;accent-color:#1b9277"/></div></section></div><div class="ptab" data-tab="voice"><div class="section-title"><div><h2>朗讀與音效</h2><p>朗讀使用裝置內建的國語語音，免費、不需網路帳號。</p></div></div><section class="card"><div class="settings-row"><label for="auto-read-toggle">每題自動朗讀<small>進入新題目時自動唸題目；適合還不識字的孩子。也可以隨時按「🔊 唸題目給我聽」。</small></label><input type="checkbox" id="auto-read-toggle" data-action="auto-read" ${data.settings.autoRead?'checked':''} style="width:24px;height:24px;accent-color:#1b9277"/></div><div class="settings-row"><label for="sound-toggle">答對音效<small>答對時播放短短的提示音。</small></label><input type="checkbox" id="sound-toggle" data-action="sound" ${data.settings.sound!==false?'checked':''} style="width:24px;height:24px;accent-color:#1b9277"/></div>${voiceSettings()}</section>${recordingStudio()}</div><div class="ptab" data-tab="data"><div class="section-title"><div><h2>家長密碼</h2><p>離開家長區會自動鎖定。可以在這裡更換密碼。</p></div></div><section class="card"><div class="rowactions"><button type="button" class="btn btn-outline" data-action="lock-parent">🔒 立即鎖定家長區</button></div><details style="margin-top:16px"><summary style="font-weight:850;cursor:pointer">更換家長密碼</summary><form data-pin-form="change" class="pin-form"><label for="parent-old">原密碼</label><input id="parent-old" name="current" type="password" inputmode="numeric" autocomplete="off" required /><label for="parent-new">新密碼（6～12 位數字）</label><input id="parent-new" name="pin" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="off" /><label for="parent-new-confirm">確認新密碼</label><input id="parent-new-confirm" name="confirm" type="password" inputmode="numeric" pattern="[0-9]{6,12}" minlength="6" maxlength="12" required autocomplete="off" /><button class="btn btn-dark" type="submit">確認更換密碼</button></form></details><p class="note">設定僅保存在這個瀏覽器，不會與其他家長或手機共享。</p></section>
</div><div class="ptab" data-tab="report"><div class="section-title"><div><h2>最近的練習紀錄</h2><p>記錄保存在這個瀏覽器，不會跨裝置同步。</p></div></div><section class="card">${ss.length?`<div style="overflow:auto"><table class="history-table"><thead><tr><th>日期</th><th>科目</th><th>練習項目</th><th>級別</th><th>答對</th></tr></thead><tbody>${ss.map(s=>`<tr><td>${fmtDate(s.date)}</td><td>${subName(s.subject)}</td><td>${h(MODES[s.subject].find(m=>m.id===s.mode)?.name||s.mode)}</td><td>${s.level}</td><td>${s.correct}/${s.total}</td></tr>`).join('')}</tbody></table></div>`:'<div class="empty">尚無紀錄；完成一次練習後會出現在這裡。</div>'}</section>
</div><div class="ptab" data-tab="data"><div class="section-title"><div><h2>資料管理</h2><p>可匯出備份，也可以完全清除本機學習紀錄。</p></div></div><section class="card"><p class="note" style="margin-top:0">不輸入孩子姓名、不需要登入、沒有廣告或外部分析服務；資料使用瀏覽器 localStorage。清除瀏覽器資料、無痕模式或換裝置，紀錄可能遺失。匯出的 JSON 備份檔可能包含練習心得，請妥善保管。</p><div class="rowactions"><button class="btn btn-outline" data-action="export">⬇ 匯出目前孩子的紀錄</button><button class="btn btn-outline" data-action="export-raw">⬇ 匯出原始儲存資料</button><button class="btn btn-outline" data-action="export-previous">⬇ 匯出上一份自動備份</button><button class="btn btn-outline" data-action="import">⬆ 匯入紀錄 JSON</button><input class="hidden" type="file" id="import-file" accept=".json,application/json" aria-label="選擇練習紀錄 JSON"/><button class="btn btn-outline" data-action="print">🖨 列印家長報告</button><button class="btn btn-danger" data-action="reset">🗑 清除本機紀錄</button></div></section></div></div>`}
function skillMeter(k){const a=getSkillStat(k),state=a.n<5?'資料不足':a.pct>=85?'近期表現穩定':a.pct>=65?'繼續練習':'建議一起複習';return `<div class="meter"><div class="meter-label"><span>${SKILLS[k]}</span><small>${a.n?a.hit+'/'+a.n+' 題 · '+state:'尚未練習'}</small></div><div class="meter-bar"><div style="width:${a.pct}%"></div></div></div>`}

// v18：一張免費的觸控畫布；不使用影像辨識或付費 API。
function handWordPool(){return VOCAB[effectiveLevel('english')]||VOCAB[1]}
function currentHandTarget(){const words=handWordPool();return handMode==='letter'?ALPHABET[handLetter].upper:words[handWord%words.length][0]}
function handPadMarkup(target='',showGuide=false,quizMode=false){const size=target.length>3?'word':'letter';return `<div class="hw-pad ${showGuide?'guide':''} ${handExpanded?'is-expanded':''}"><div class="hw-guide-text ${!showGuide?'scratch':size}" aria-hidden="true">${showGuide?h(target):''}</div><canvas id="hw-canvas" width="780" height="360" aria-label="${quizMode?'手寫草稿畫板':'英文或數學手寫畫板'}，可用手指、觸控筆或滑鼠書寫" role="img"></canvas></div><div class="hw-actions"><button type="button" class="btn btn-outline" data-action="hand-undo">↩️ 撤銷一筆</button><button type="button" class="btn btn-outline" data-action="hand-clear">🧽 清空重寫</button><button type="button" class="btn hw-zoom" data-action="hand-zoom" aria-pressed="${handExpanded}">🔎 ${handExpanded?'還原':'放大'}書寫區</button></div>`}
function handAnswerPadMarkup(){return `<div class="hw-canvas-head">🖊️ 最後答案手寫區</div><p class="hw-ocr-hint">先在上方草稿列式，再只把最後答案寫在下面。數字之間留一點空隙，較容易辨識。</p><div class="hw-pad hw-answer-pad ${handAnswerExpanded?'is-expanded':''}"><canvas id="hw-answer-canvas" aria-label="手寫最後數字答案；畫板上滑動不會捲動畫面"></canvas></div><div class="hw-actions"><button type="button" class="btn btn-outline" data-action="hand-answer-undo">↩️ 撤銷一筆</button><button type="button" class="btn btn-outline" data-action="hand-answer-clear">🧽 清空最後答案</button><button type="button" class="btn hw-zoom" data-action="hand-answer-zoom" aria-pressed="${handAnswerExpanded}">🔎 ${handAnswerExpanded?'還原':'放大'}答案區</button></div>`}
function handRecognizerControls(kind){return `${kind==='math'?handAnswerPadMarkup():`<p class="hw-ocr-hint">✏️ 英文請用印刷體寫字母，字母之間留一點間隔。辨識結果只供參考，不會直接當成正確答案。</p>`}<div class="hw-ocr-actions"><button type="button" class="btn btn-dark" data-action="hand-recognize" ${handRecognitionBusy?'disabled':''}>🔎 ${handRecognitionBusy?'正在辨識…':'辨識手寫'+(kind==='math'?'答案':'英文')}</button></div><div class="hw-ocr-result" id="hw-ocr-result" role="status" aria-live="polite">${h(handOcrResult)}</div><div class="hw-score" id="hw-score" role="status" aria-live="polite" ${handScoreHtml?'':'hidden'}>${handScoreHtml}</div><div id="hw-ocr-candidates" class="hw-ocr-actions" aria-label="可能的英文單字"></div>`}
function handwritingPage(){
 if(!handMath||handMath.practiceGrade!==grade()||handMath.practiceLevel!==effectiveLevel('math'))handMath=Object.assign(handCalculation(),{practiceGrade:grade(),practiceLevel:effectiveLevel('math')});
 const english=handTab==='english',pool=handWordPool(),word=pool[handWord%pool.length],target=currentHandTarget();
 return `<div class="hw-layout"><button class="back" data-action="nav-home">← 回到學習首頁</button><div class="pageheading"><div class="eyebrow">HANDWRITING × BASEBALL</div><h1>✍️ 手寫練習場</h1><p>手機用手指、平板用觸控筆、電腦用滑鼠。寫完可以核對拼字或數學答案，不需要額外費用。</p></div><div class="hw-tabs" role="group" aria-label="選擇手寫練習科目"><button type="button" data-action="hand-tab-english" class="${english?'selected':''}" aria-pressed="${english}">🔤 英文手寫</button><button type="button" data-action="hand-tab-math" class="${!english?'selected':''}" aria-pressed="${!english}">🧮 數學計算</button></div>
 <section class="hw-main">${english?`<div class="hw-modes" role="group" aria-label="英文手寫類型"><button type="button" data-action="hand-mode-letter" class="${handMode==='letter'?'selected':''}" aria-pressed="${handMode==='letter'}">🔡 A～Z 字母</button><button type="button" data-action="hand-mode-word" class="${handMode==='word'?'selected':''}" aria-pressed="${handMode==='word'}">📚 英文單字</button></div><div class="hw-practice-target"><div class="target" lang="en">${h(target)}${handMode==='letter'?` <span style="color:#7691a0">${ALPHABET[handLetter].lower}</span>`:''}</div><small>${handMode==='letter'?`第 ${handLetter+1}／26 個字母・${ALPHABET[handLetter].word}（${ALPHABET[handLetter].meaning}）`:`第 ${handWord%pool.length+1}／${pool.length} 個單字 · ${h(word[1])}`}</small></div><div class="rowactions"><button type="button" class="btn btn-outline" data-action="hand-listen">🔊 聽發音</button><button type="button" class="btn btn-outline" data-action="hand-prev">← 上一個</button><button type="button" class="btn btn-dark" data-action="hand-next">下一個 →</button></div>${handPadMarkup(handMode==='letter'?target+' '+ALPHABET[handLetter].lower:target,true)}${handRecognizerControls('english')}<form class="hw-check" data-hw-form="english"><div class="hw-field"><label for="hw-check-input">🖊️ 用鍵盤拼一次，再核對</label><input id="hw-check-input" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" maxlength="35" aria-label="輸入單字核對拼字" placeholder="例如：${h(target)}"></div><button class="btn btn-dark" type="submit">✅ 核對拼字</button></form>`:
 `<div class="hw-practice-target"><div style="font-size:13px;color:#627779;font-weight:800">數學計算 · ${GRADES[grade()]}適用題目</div><div style="font-size:clamp(20px,4vw,28px);font-weight:900;margin-top:7px;white-space:pre-wrap">${h(handMath.main)}</div></div><div class="rowactions"><button class="btn btn-outline" type="button" data-action="hand-math-next">🔄 換一題</button><button class="btn btn-outline" type="button" data-action="hand-math-explain">💡 ${handSolution?'隱藏解析':'看解題解析'}</button></div>${handPadMarkup('',false)}${handRecognizerControls('math')}<form class="hw-check" data-hw-form="math"><div class="hw-field"><label for="hw-check-input">🧮 寫完算式，再輸入答案驗算</label><input id="hw-check-input" type="text" inputmode="decimal" autocomplete="off" maxlength="20" aria-label="輸入數學答案" placeholder="輸入數字，例如：24"></div><button class="btn btn-dark" type="submit">✅ 驗證計算</button></form>${handSolution?`<div class="hw-message">📖 ${h(handMath.explain)}</div>`:''}`}
 <div class="hw-message" id="hw-feedback" role="status" aria-live="polite">${h(handResult)}</div><p class="hw-note">⚠️ 評分分成「答案是否正確」與「筆跡形狀相似度參考」。形狀分數是本機筆畫和印刷字樣的簡易比較，並非老師評分，不適合判斷孩子真正的字體美觀或書寫能力。辨識錯誤時可自行修正；資料不會上傳，也不會更改原本的測驗紀錄。</p></section></div>`;
}
function handReset(){handInk.length=0;handAnswerInk.length=0;handInkRevision++;handOcrCandidates=[];handOcrResult='';handScoreHtml='';handResult='';handSolution=false;handActivePointer=null}
function paintHandCanvas(canvas){
 const ctx=canvas.getContext('2d');if(!ctx)return;
 const ink=canvas.id==='hw-answer-canvas'?handAnswerInk:handInk;
 const r=canvas.getBoundingClientRect(),w=Math.max(1,r.width),hh=Math.max(1,r.height),dpr=Math.min(3,window.devicePixelRatio||1);
 if(canvas.width!==Math.round(w*dpr)||canvas.height!==Math.round(hh*dpr)){canvas.width=Math.round(w*dpr);canvas.height=Math.round(hh*dpr)}
 ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,hh);
 ctx.strokeStyle='#264eab';ctx.fillStyle='#264eab';ctx.lineWidth=4.2;ctx.lineCap='round';ctx.lineJoin='round';
 for(const stroke of ink){if(!stroke.length)continue;if(stroke.length===1){ctx.beginPath();ctx.arc(stroke[0][0]*w,stroke[0][1]*hh,2.1,0,Math.PI*2);ctx.fill();continue}
 ctx.beginPath();ctx.moveTo(stroke[0][0]*w,stroke[0][1]*hh);for(let i=1;i<stroke.length;i++)ctx.lineTo(stroke[i][0]*w,stroke[i][1]*hh);ctx.stroke()}
}
function returnToWritingPad(id){const c=document.getElementById(id);if(!c)return;requestAnimationFrame(()=>{if(!c.isConnected)return;try{c.scrollIntoView({block:'center',behavior:'auto'})}catch(_){c.scrollIntoView()}})}
const handPendingFrames=new WeakMap();
function queueHandPaint(canvas){
 if(!canvas||!canvas.isConnected||handPendingFrames.has(canvas))return;
 const ticket=requestAnimationFrame(()=>{handPendingFrames.delete(canvas);if(canvas.isConnected)paintHandCanvas(canvas)});
 handPendingFrames.set(canvas,ticket);
}
function initHandCanvas(){
 if(handResizeObserver){handResizeObserver.disconnect();handResizeObserver=null}
 const canvases=[...document.querySelectorAll('#hw-canvas,#hw-answer-canvas')];if(!canvases.length)return;
 handActivePointer=null;
 for(const c of canvases){const inkNow=()=>c.id==='hw-answer-canvas'?handAnswerInk:handInk;let drawingPointer=null;
 // iOS Safari: explicitly suppress touch scrolling only if the event began inside the canvas.
 const noScroll=e=>{if(e.cancelable)e.preventDefault()};
 c.addEventListener('touchstart',noScroll,{passive:false});c.addEventListener('touchmove',noScroll,{passive:false});
 c.addEventListener('gesturestart',noScroll,{passive:false});
 const loc=e=>{const r=c.getBoundingClientRect();return [Math.min(1,Math.max(0,(e.clientX-r.left)/Math.max(1,r.width))),Math.min(1,Math.max(0,(e.clientY-r.top)/Math.max(1,r.height)))]};
 c.addEventListener('pointerdown',e=>{if(drawingPointer!==null||e.isPrimary===false||(e.pointerType==='mouse'&&e.button!==0))return;e.preventDefault();drawingPointer=e.pointerId;const ink=inkNow();ink.push([loc(e)]);handInkRevision++;handScoreHtml='';if(ink.length>240)ink.shift();try{c.setPointerCapture(e.pointerId)}catch(_){}paintHandCanvas(c)});
 c.addEventListener('pointermove',e=>{const ink=inkNow();if(e.pointerId!==drawingPointer||!ink.length)return;e.preventDefault();const stroke=ink[ink.length-1];if(stroke.length<5000)stroke.push(loc(e));queueHandPaint(c)});
 const end=e=>{if(e.pointerId!==drawingPointer)return;e.preventDefault();drawingPointer=null;try{if(c.hasPointerCapture(e.pointerId))c.releasePointerCapture(e.pointerId)}catch(_){}paintHandCanvas(c);persistOpenDraft()};
 c.addEventListener('pointerup',end);c.addEventListener('pointercancel',end);c.addEventListener('lostpointercapture',()=>{drawingPointer=null});
 }
 if('ResizeObserver'in window){handResizeObserver=new ResizeObserver(entries=>{for(const entry of entries){const c=entry.target;if(c.isConnected)queueHandPaint(c)}});canvases.forEach(c=>handResizeObserver.observe(c))}
 requestAnimationFrame(()=>canvases.forEach(c=>{if(c.isConnected)paintHandCanvas(c)}));
}

// 免費本機辨識：優先使用支援的瀏覽器原生筆跡 API；其他瀏覽器使用本地筆畫形狀比對。
// 沒有網路傳送，也不需模型下載。非正式 OCR 校正，結果需由孩子核對。
function handStrokeGroups(ink){
 const strokes=ink.filter(s=>s&&s.length).map(points=>({points,x1:Math.min(...points.map(p=>p[0])),x2:Math.max(...points.map(p=>p[0])),y1:Math.min(...points.map(p=>p[1])),y2:Math.max(...points.map(p=>p[1]))}));
 if(!strokes.length)return [];
 // Horizontal overlap combines multi-stroke glyphs (A, H, t and dotted i).
 let groups=strokes.map(s=>({strokes:[s],x1:s.x1,x2:s.x2,y1:s.y1,y2:s.y2}));
 let changed=true,rounds=0;
 while(changed&&rounds++<100){changed=false;outer:for(let i=0;i<groups.length;i++)for(let j=i+1;j<groups.length;j++){
 const a=groups[i],b=groups[j];const overlap=Math.min(a.x2,b.x2)-Math.max(a.x1,b.x1);
 const eps=.007;
 const gap=Math.max(0,Math.max(a.x1,b.x1)-Math.min(a.x2,b.x2));
 const centerClose=Math.abs((a.x1+a.x2)-(b.x1+b.x2))<Math.max(.027,Math.min(a.x2-a.x1,b.x2-b.x1)*.8);
 const nearby=overlap>=-.002||(gap<eps&&centerClose);
 if(nearby){groups[i]={strokes:a.strokes.concat(b.strokes),x1:Math.min(a.x1,b.x1),x2:Math.max(a.x2,b.x2),y1:Math.min(a.y1,b.y1),y2:Math.max(a.y2,b.y2)};groups.splice(j,1);changed=true;break outer}
 }}
 return groups.sort((a,b)=>a.x1-b.x1);
}
function handMaskFromStrokes(strokes){
 const useAnswer=handTab==='math'||page==='quiz'&&session?.subject==='math';
 const el=document.getElementById(useAnswer?'hw-answer-canvas':'hw-canvas');
 const ratio=el?Math.max(.9,Math.min(useAnswer?2.4:1.65,el.clientWidth/Math.max(1,el.clientHeight))):1.4;
 const points=strokes.flatMap(s=>(s.points||s).map(p=>[p[0]*ratio,p[1]]));if(!points.length)return null;
 let xmin=1,xmax=0,ymin=1,ymax=0;
 for(const [x,y]of points){xmin=Math.min(xmin,x);xmax=Math.max(xmax,x);ymin=Math.min(ymin,y);ymax=Math.max(ymax,y)}
 const ww=Math.max(.004,xmax-xmin),hh=Math.max(.004,ymax-ymin),size=52,pad=5;
 const canvas=document.createElement('canvas');canvas.width=size;canvas.height=size;const ctx=canvas.getContext('2d',{willReadFrequently:true});
 ctx.fillStyle='#fff';ctx.fillRect(0,0,size,size);ctx.strokeStyle='#000';ctx.lineWidth=3.2;ctx.lineCap='round';ctx.lineJoin='round';
 const scale=Math.min((size-2*pad)/ww,(size-2*pad)/hh);const px=(size-ww*scale)/2,py=(size-hh*scale)/2;
 for(const st of strokes){const ps=(st.points||st).map(p=>[p[0]*ratio,p[1]]);if(ps.length<1)continue;ctx.beginPath();ctx.moveTo(px+(ps[0][0]-xmin)*scale,py+(ps[0][1]-ymin)*scale);for(const pt of ps.slice(1))ctx.lineTo(px+(pt[0]-xmin)*scale,py+(pt[1]-ymin)*scale);if(ps.length===1){ctx.lineTo(px+(ps[0][0]-xmin)*scale+.1,py+(ps[0][1]-ymin)*scale)}ctx.stroke()}
 return handImageFeatures(ctx.getImageData(0,0,size,size).data,size);
}
function handImageFeatures(rgba,size){const pixel=[];for(let i=0;i<size*size;i++){const value=rgba[i*4];pixel.push(value<165?1:0)}return pixel}
let handTemplateCache=null;
function handTemplates(){
 if(handTemplateCache)return handTemplateCache;
 const all=[];const glyphs='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-.';
 const canv=document.createElement('canvas');canv.width=80;canv.height=80;const ctx=canv.getContext('2d',{willReadFrequently:true});
 for(const char of glyphs){for(const font of ['Arial','Georgia','monospace','cursive']){
 ctx.clearRect(0,0,80,80);ctx.fillStyle='white';ctx.fillRect(0,0,80,80);ctx.font='bold 64px '+font;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillStyle='#000';ctx.fillText(char,40,43);
 const d=ctx.getImageData(0,0,80,80).data;let x1=80,x2=0,y1=80,y2=0;
 for(let y=0;y<80;y++)for(let x=0;x<80;x++){const i=(y*80+x)*4;if(d[i]<160){x1=Math.min(x1,x);x2=Math.max(x2,x);y1=Math.min(y1,y);y2=Math.max(y2,y)}}
 if(x1>x2)continue;const pad=5,srcw=x2-x1+1,srch=y2-y1+1,scale=Math.min(42/srcw,42/srch);
 const res=document.createElement('canvas');res.width=52;res.height=52;const rc=res.getContext('2d',{willReadFrequently:true});rc.fillStyle='white';rc.fillRect(0,0,52,52);rc.imageSmoothingEnabled=true;
 rc.drawImage(canv,x1,y1,srcw,srch,(52-srcw*scale)/2,(52-srch*scale)/2,srcw*scale,srch*scale);
 all.push({char,mask:handImageFeatures(rc.getImageData(0,0,52,52).data,52),ratio:srcw/srch});
 }}handTemplateCache=all;return all;
}
function handMaskDistance(a,b){
 // Symmetric nearest-neighbor strokes (chamfer-like) tolerates moderate stroke width differences.
 const n=52,ar=[],br=[];for(let i=0;i<n*n;i++){if(a[i])ar.push(i);if(b[i])br.push(i)}if(!ar.length||!br.length)return Infinity;
 // 5x5 soft overlap. Fast approximation to distance transform.
 const neigh=(src,dst)=>{let sum=0;for(const i of src){const x=i%n,y=(i/n)|0;let best=12;
 for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){
 const xx=x+dx,yy=y+dy;if(xx<0||xx>=n||yy<0||yy>=n)continue;
 if(dst[yy*n+xx])best=Math.min(best,dx*dx+dy*dy);
 }sum+=Math.min(12,best)}return sum/src.length};
 return neigh(ar,b)*.55+neigh(br,a)*.45;
}
function handGuessCharacter(strokes,kind){
 const allPoints=strokes.flatMap(st=>st.points||st);
 if(allPoints.length>=2){const xs=allPoints.map(p=>p[0]),ys=allPoints.map(p=>p[1]);const width=Math.max(...xs)-Math.min(...xs),height=Math.max(...ys)-Math.min(...ys);
 if(width<.006&&height>.05)return {char:kind==='digit'?'1':'l',distance:.2};
 if(kind==='digit'&&width>.055&&height>.09){
 // A handwritten 2 often ends with a long bottom horizontal underline, unlike 3, 7, or 1.
 const ymin=Math.min(...ys),ymax=Math.max(...ys),xmin=Math.min(...xs),xmax=Math.max(...xs);
 const bottomStroke=strokes.some(st=>{const pts=st.points||st;for(let i=1;i<pts.length;i++){
 const p=pts[i-1],q=pts[i];if(Math.min(p[1],q[1])>ymin+height*.78&&Math.abs(p[1]-q[1])<height*.12&&Math.abs(p[0]-q[0])>width*.4)return true;
 }return false});
 const topArc=allPoints.some(pt=>pt[1]<ymin+height*.30)&&allPoints.some(pt=>pt[0]<xmin+width*.35&&pt[1]>ymin+height*.55);
 if(bottomStroke&&topArc)return {char:'2',distance:.2};
 }
 }
 const sample=handMaskFromStrokes(strokes);if(!sample)return null;
 let best=null;for(const tmpl of handTemplates()){
 if(kind==='digit'&&!('0123456789'.includes(tmpl.char)))continue;
 if((kind==='letter'||kind==='word')&&!(/[A-Za-z]/.test(tmpl.char)))continue;
 let d=handMaskDistance(sample,tmpl.mask);
 if(!best||d<best.distance)best={char:tmpl.char,distance:d};
 }return best;
}
function handTryLocalRecognize(ink,kind){
 let groups=handStrokeGroups(ink);if(!groups.length)return null;
 if(kind==='letter'){return handGuessCharacter(ink.map(points=>({points})),kind)?.char||null}
 if(groups.length>25)return null;
 return groups.map(g=>handGuessCharacter(g.strokes,kind)?.char||'?').join('');
}
// 練習用評分，不是 OCR 信心指標，也不是由老師判定筆順／字體好壞。
// 分別顯示：答案核對分（100或0）＋筆跡字形近似分（僅在分字清楚時提供）。
function handShapeScore(ink,text,kind){
 const clean=String(text||'').trim();
 if(!clean||!ink||!ink.some(s=>s&&s.length))return null;
 let glyphs=[...clean];
 if(glyphs.length>18||glyphs.some(ch=>!/[A-Za-z0-9]/.test(ch)))return null;
 let groups=kind==='letter'?[{strokes:ink.map(points=>({points}))}]:handStrokeGroups(ink);
 if(groups.length!==glyphs.length)return null;
 const templates=handTemplates();const scores=[];
 for(let i=0;i<glyphs.length;i++){
   const mask=handMaskFromStrokes(groups[i].strokes);if(!mask)return null;
   let best=Infinity;
   for(const t of templates){if(t.char.toLowerCase()!==glyphs[i].toLowerCase())continue;const dist=handMaskDistance(mask,t.mask);if(dist<best)best=dist}
   if(!Number.isFinite(best))return null;
   scores.push(Math.max(0,Math.min(100,Math.round(100-21*best))));
 }
 return Math.max(0,Math.min(100,Math.round(scores.reduce((sum,n)=>sum+n,0)/scores.length)));
}
function showHandScores(correctness=null,guess=null){
 const kind=((page==='quiz'&&session?.subject==='math')||(page==='handwrite'&&handTab==='math'))?'math':'english';
 const ink=kind==='math'?handAnswerInk:handInk;
 const isLetter=kind==='english'&&page==='handwrite'&&handMode==='letter';
 const shape=handShapeScore(ink,guess,kind==='math'?'digit':isLetter?'letter':'word');
 const items=[];
 if(correctness!==null)items.push(`<div>🎯 <strong>答案核對：${correctness?'100':'0'} 分</strong>　${correctness?'答對了！':'再試一次'}</div>`);
 if(shape!==null)items.push(`<div>✍️ <strong>筆跡形狀參考：${shape} 分</strong>（與字形範本接近程度）</div>`);
 else if(ink.length)items.push('<div>✍️ 字形分數：暫無法可靠估計（請分開寫字，或先練單一字母）</div>');
 if(items.length)items.push('<small>⚠️ 形狀分數只是簡單字形比較，不代表筆順、字體美觀或英文能力；答案核對分和形狀分是兩件事。</small>');
 handScoreHtml=items.join('');const el=document.getElementById('hw-score');if(el){el.innerHTML=handScoreHtml;el.hidden=!items.length}
}
function clearHandScore(){handScoreHtml='';const score=document.getElementById('hw-score');if(score){score.innerHTML='';score.hidden=true}}
function clearHandRecognition(){handInkRevision++;handOcrCandidates=[];handOcrResult='';clearHandScore();const el=document.getElementById('hw-ocr-result');if(el)el.textContent='';const c=document.getElementById('hw-ocr-candidates');if(c)c.innerHTML=''}
function resizeHandPad(answer=false){
 const c=document.getElementById(answer?'hw-answer-canvas':'hw-canvas');if(!c)return;
 const pad=c.closest('.hw-pad');if(!pad)return;
 if(answer)handAnswerExpanded=!handAnswerExpanded;else handExpanded=!handExpanded;
 const expanded=answer?handAnswerExpanded:handExpanded;
 pad.classList.toggle('is-expanded',expanded);
 const btn=document.querySelector('[data-action="'+(answer?'hand-answer-zoom':'hand-zoom')+'"]');
 if(btn){btn.setAttribute('aria-pressed',String(expanded));btn.textContent='🔎 '+(expanded?'還原':'放大')+(answer?'答案區':'書寫區')}
 requestAnimationFrame(()=>{if(c.isConnected)paintHandCanvas(c)});
}
async function handTryNativeRecognize(ink){
 if(typeof navigator.createHandwritingRecognizer!=='function'||typeof HandwritingStroke!=='function')return null;
 let recognizer=null;
 try{recognizer=await navigator.createHandwritingRecognizer({languages:['en']});const drawing=recognizer.startDrawing({recognitionType:'text',alternatives:2});
 for(const stroke of ink){if(!stroke.length)continue;const st=new HandwritingStroke();for(const [x,y] of stroke)st.addPoint({x:x*1000,y:y*1000});drawing.addStroke(st)}
 const results=await drawing.getPrediction();return String(results?.[0]?.text||'').trim()||null;
 }catch(_){return null}finally{try{recognizer?.finish()}catch(_){}}
}
function handWordAlternatives(guess){
 const word=guess.toLowerCase();if(!/^[a-z]{2,20}$/.test(word))return [];
 const edit=(a,b)=>{const prev=Array.from({length:b.length+1},(_,j)=>j);for(let i=1;i<=a.length;i++){let before=prev[0];prev[0]=i;for(let j=1;j<=b.length;j++){const old=prev[j];prev[j]=Math.min(prev[j]+1,prev[j-1]+1,before+(a[i-1]===b[j-1]?0:1));before=old}}return prev[b.length]};
 const all=[...new Set([1,2,3].flatMap(lv=>(VOCAB[lv]||[]).map(row=>String(row[0]).toLowerCase())).filter(w=>/^[a-z]{2,20}$/.test(w)))];
 const sorted=all.filter(w=>Math.abs(w.length-word.length)<2&&w!==word).map(w=>({w,d:edit(word,w)})).sort((a,b)=>a.d-b.d||a.w.localeCompare(b.w));
 return sorted.filter(v=>v.d<=Math.max(1,Math.ceil(word.length*.28))).slice(0,3).map(v=>v.w);
}
async function handRecognize(){
 if(handRecognitionBusy)return;const kind=(page==='quiz'&&session?.subject==='math')||page==='handwrite'&&handTab==='math'?'math':'english';
 const ink=kind==='math'?handAnswerInk:handInk;
 const charKind=kind==='math'?'digit':'letter';
 if(!ink.length||ink.every(x=>!x.length)){reportHand('先在手寫畫板寫下'+(kind==='math'?'最後答案':'字母或單字')+'，再按辨識。');return}
 handRecognitionBusy=true;handOcrCandidates=[];const revisionAtStart=handInkRevision;const btn=document.querySelector('[data-action="hand-recognize"]');if(btn){btn.disabled=true;btn.textContent='⌛ 正在辨識…'}
 const box=document.getElementById('hw-ocr-result');if(box)box.textContent='🔎 正在辨識；請稍候…';
 try{
 let guess=await handTryNativeRecognize(ink);
 if(!guess)guess=handTryLocalRecognize(ink,kind==='english'?(page==='handwrite'&&handMode==='letter'?'letter':'word'):charKind);
 if(revisionAtStart!==handInkRevision){handOcrResult='';return}
 if(!guess||guess.includes('?')){handOcrResult='⚠️ 沒有辨識清楚。請寫大一點，讓每個字母／數字間保留空隙；也可以直接修正輸入欄位。';return}
 guess=guess.trim().replace(/\s+/g,' ');
 if(kind==='math')guess=guess.replace(/[^0-9.\-]/g,'').slice(0,20);
 else guess=guess.replace(/[^A-Za-z]/g,'').slice(0,35);
 if(!guess||(kind==='math'&&!/[0-9]/.test(guess))){handOcrResult='⚠️ 無法辨識有效答案，請重寫或使用輸入框完成。';return}
 if(kind==='english'&&!(page==='handwrite'&&handMode==='letter'))handOcrCandidates=handWordAlternatives(guess);const input=document.getElementById('hw-check-input');if(input)input.value=guess;
 handOcrResult='✍️ 我猜是「'+guess+'」。請先確認文字，再按下方的「核對／驗算」按鈕；辨識不等於答對。';
 showHandScores(null,guess);
 }catch(_){handOcrResult='⚠️ 這次辨識失敗，請修改輸入框或再寫一次。';}finally{
 if(box)box.textContent=handOcrResult;
 const choices=document.getElementById('hw-ocr-candidates');if(choices){choices.innerHTML=handOcrCandidates.length?'<span style="font-size:13px;font-weight:800;color:#48647a;width:100%">📚 字庫相近的單字（不代表一定正確）：</span>'+handOcrCandidates.map(w=>`<button class="btn btn-outline" data-action="hand-ocr-select" data-word="${h(w)}" type="button">${h(w)}</button>`).join(''):''}
 handRecognitionBusy=false;
 if(btn){btn.disabled=false;btn.textContent='🔎 辨識手寫'+(kind==='math'?'答案':'英文')}
 }
}

function reportHand(message){handResult=message;const out=document.getElementById('hw-feedback');if(out)out.textContent=message;else toast(message)}
function handCheck(kind){const input=document.getElementById('hw-check-input');if(!input)return;const raw=input.value.normalize('NFKC').trim();if(!raw){reportHand('先在輸入框寫下答案，才能進行核對喔。');return}
 if(kind==='english'){const target=currentHandTarget(),correct=raw.toLowerCase()===target.toLowerCase();reportHand(correct?'✅ 拼對了！再用手寫板練習筆順吧！':'💡 再檢查一次拼字，對照上方範字試試。');showHandScores(correct,raw);return}
 const target=kind==='quiz'?session?.items[session.idx]?.answer:handMath?.answer;
 if(!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw)){reportHand('請輸入一個數字作為答案，例如 24 或 3.5。');return}
 const got=Number(raw),expected=Number(target);
 if(!Number.isFinite(got)||!Number.isFinite(expected)){reportHand('這題無法用純數字驗算，請使用下方的選擇題。');return}
 const correct=got===expected;reportHand(correct?'✅ 答案正確！你的計算成功了！'+(kind==='quiz'?' 再選下方的選項完成這題。':''):'💡 還不正確。檢查進位、運算順序，再算一次。');showHandScores(correct,raw);
}

function render(){
 try{applyProfileLook();applyWorld();if(page==='login'){document.body.dataset.theme='login';document.body.classList.remove('kid');app.innerHTML=storageNotice()+loginPage()+guideMarkup();if(guideOpen)document.getElementById('guide-close')?.focus();return}if(page==='zhuyin'||(page==='select'&&subject==='zhuyin')||(page==='quiz'&&session?.subject==='zhuyin'))prefetchZyAudio();
   const view=page==='home'?home():page==='select'?selectView():page==='quiz'?quiz():page==='result'?result():page==='science-learn'?scienceLearnPage():page==='dictation'?dictationPage():page==='times'?timesPage():page==='alphabet'?alphabetPage():page==='zhuyin'?zhuyinPage():page==='players'?playersPage():page==='handwrite'?handwritingPage():parent();
   app.innerHTML=`<div class="shell">${header()}${storageNotice()}${guideMarkup()}<main id="content" tabindex="-1">${view}</main>${footer()}</div>`;
   if(guideOpen)document.getElementById('guide-close')?.focus();
   // Speech availability must never prevent displaying the lesson or writing pad.
   try{populateSpeechVoices()}catch(e){console.warn('English voice setup unavailable',e)}
   try{initHandCanvas()}catch(e){console.warn('Handwriting initialization unavailable',e)}
 }catch(e){
   console.error('App render failed',e);
   const reason=e&&e.name?String(e.name):'相容性錯誤';
   app.innerHTML=`<main style="max-width:700px;margin:40px auto;padding:30px;border-radius:20px;background:#fff;color:#17324a;font-family:-apple-system,BlinkMacSystemFont,sans-serif"><h1>⚾ 小小探索學院</h1><p>網站載入時遇到問題（${reason.replace(/[^a-zA-Z0-9 ]/g,'')}），已保留你的原有學習資料。</p><button type="button" onclick="location.reload()" style="background:#174675;color:#fff;padding:14px 22px;border:0;border-radius:12px;font-size:17px">🔄 重新載入</button></main>`;
 }
}
// Free device voice is the default. Existing recordings remain a network fallback.
// Keep full sentences intact; only gently slow the speaking rate.
function playSavedAudio(url,label,rate=null,repeat=1,allowDeviceFallback=true){
  stopEnglish();
  const id=speechAttempt;
  const audio=new Audio();activeRecordedAudio=audio;
  audio.preload='auto';audio.src=url;
  audio.playbackRate=rate??SPEEDS[voicePrefs.speed];
  // Keep the same pitch when a child slows the recording down; supported in modern Safari.
  if('preservesPitch' in audio)audio.preservesPitch=true;
  let remaining=repeat;
  audio.onplaying=()=>{if(id===speechAttempt)showSpeechStatus(page==='quiz'?'🔊 播放中…':'🔊 播放：'+label)};
  audio.onended=()=>{if(id!==speechAttempt)return;
    if(--remaining>0){
      // Keep a real pause between the two *whole words*. Otherwise iPhone replay sounds glued together.
      showSpeechStatus('👂 停頓一下，再聽第二次；可以跟著念。');
      wordReplayTimer=setTimeout(()=>{
        wordReplayTimer=null;
        if(id!==speechAttempt || activeRecordedAudio!==audio)return;
        try{audio.currentTime=0;const next=audio.play();if(next?.catch)next.catch(fail)}catch(_){fail()}
      },780);
      return;
    }
    activeRecordedAudio=null;showSpeechStatus('✅ 播放完成，可以再按一次重聽。');
  };
  function fail(){if(id!==speechAttempt)return;activeRecordedAudio=null;try{audio.pause()}catch(_){}if(allowDeviceFallback&&'speechSynthesis' in window){showSpeechStatus('音檔暫時無法播放，改用裝置英文語音。');playSyntheticEnglish(label)}else{showSpeechStatus('暫時無法播放，請確認裝置音量後再按一次；也可以先看文字提示。')}}
  audio.onerror=fail;
  try{const p=audio.play();if(p?.catch)p.catch(fail)}catch(_){fail()}
  showSpeechStatus('🔊 正在載入發音…');
  return true;
}
function playRecordedLetter(letter){return playSavedAudio(LETTER_RECORDINGS[letter],letter,1)}
function playDeviceEnglish(text,rate=null,repeat=1,fallbackUrl=null){
  const value=String(text||'').trim();
  if(!('speechSynthesis' in window)||typeof SpeechSynthesisUtterance==='undefined'){
    if(fallbackUrl)return playSavedAudio(fallbackUrl,value,rate,repeat,false);
    showSpeechStatus('⚠️ 這台裝置沒有可用的英文語音。');return false;
  }
  stopEnglish();
  const id=speechAttempt;
  const synth=window.speechSynthesis;
  const selected=pickEnglishVoice();
  let index=0,started=false,fellBack=false;
  function fail(reason){
    if(id!==speechAttempt||fellBack)return;
    fellBack=true;clearTimeout(voiceHealthTimer);
    if(fallbackUrl){showSpeechStatus('⚠️ 內建英文語音未啟動，改用原本音檔。');playSavedAudio(fallbackUrl,value,rate,repeat,false)}
    else{speechActive=null;showSpeechStatus('⚠️ 無法播放裝置語音：'+reason+'。請確認裝置有美式英文語音。')}
  }
  function begin(){
    if(id!==speechAttempt||fellBack)return;
    started=false;
    try{
      // Keep the full utterance intact. Splitting words, over-slowing the voice or
      // inserting artificial gaps makes children's example sentences robotic.
      const fullPhrase=isEnglishSentence(value)?value.replace(/\s+/g,' ').trim():value;
      const u=new SpeechSynthesisUtterance(fullPhrase);
      u.lang='en-US';
      if(selected)u.voice=selected;
      u.rate=Math.max(.82,Math.min(1.06,rate??SPEEDS[voicePrefs.speed]));
      u.pitch=1;u.volume=1;
      speechActive=u;
      u.onstart=()=>{if(id===speechAttempt){started=true;clearTimeout(voiceHealthTimer);showSpeechStatus((page==='quiz'?'🔊 播放中…':'🔊 美式英文：'+value)+(repeat>1?'（第 '+(index+1)+' 次）':''))}};
      u.onend=()=>{
        if(id!==speechAttempt||fellBack)return;
        clearTimeout(voiceHealthTimer);speechActive=null;
        index++;
        if(index<repeat){
          showSpeechStatus('⏸️ 中間停頓一秒，準備再唸一次。');
          wordReplayTimer=setTimeout(()=>{wordReplayTimer=null;begin()},1100);
        }else showSpeechStatus('✅ 播放完成，可以重聽或挑戰下一題。');
      };
      u.onerror=e=>{if(id!==speechAttempt||fellBack||['canceled','interrupted'].includes(e.error))return;fail(e.error||'裝置語音異常')};
      synth.speak(u);
      voiceHealthTimer=setTimeout(()=>{
        if(id!==speechAttempt||fellBack||started)return;
        if(!synth.speaking&&!synth.pending)fail('語音未啟動');
      },3200);
    }catch(err){fail(err.message||'播放失敗')}
  }
  try{if(synth.paused)synth.resume();begin();return true}catch(err){fail(err.message||'啟動失敗');return false}
}
function playSyntheticEnglish(text,rate=null){return playDeviceEnglish(text,rate,1,null)}
function playEnglish(text,rate=null){
  const value=String(text||'').trim();
  if(/^[A-Z]$/.test(value))return playRecordedLetter(value);
  const rep=value.match(/^([A-Za-z]+)\.\s+\1\.$/i);
  const word=rep?rep[1]:value;
  const url=WORD_RECORDINGS[word.toLowerCase()]||SENTENCE_RECORDINGS[value]||null;
  const repeat=rep?2:1;
  return playDeviceEnglish(word,rate??(isEnglishSentence(word)?SENTENCE_RATE:null),repeat,url);
}
function speak(){if(!session)return;const q=session.items[session.idx];if(q.speech)playEnglish(q.speech)}
function speakSlower(){if(!session)return;const q=session.items[session.idx];if(q.speech&&isEnglishSentence(q.speech))playEnglish(q.speech,SENTENCE_SLOW_RATE)}
function exportJson(){if(!parentUnlocked)return;const s=JSON.stringify({exportedAt:new Date().toISOString(),app:'小小探索學院',profile:activeProfile(),...data},null,2),blob=new Blob([s],{type:'application/json;charset=utf-8'});const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=activeProfile().name+'_學習備份_'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),800)}
app.addEventListener('submit',e=>{if(!e.target?.dataset?.hwForm)return;e.preventDefault();handCheck(e.target.dataset.hwForm)});
app.addEventListener('click',e=>{const b=e.target.closest('[data-action]');if(!b)return;const act=b.dataset.action;switch(act){case'sci-open':sciArea=b.dataset.area==='space'?'space':'all';sciCourse='';subject='science';navigate('science-learn');break;case'sci-back':subject='science';navigate('select');break;case'sci-list':sciCourse='';stopEnglish();render();window.scrollTo(0,0);break;case'sci-area':if(['all','core','space'].includes(b.dataset.area)){sciArea=b.dataset.area;sciCourse='';stopEnglish();render()}break;case'sci-course':if(SCI_COURSES.courses.some(c=>c.id===b.dataset.course)){sciCourse=b.dataset.course;stopEnglish();render();window.scrollTo(0,0)}break;case'sci-read':{const c=SCI_COURSES.courses.find(c=>c.id===sciCourse);if(c)speakChinese([c.title,...c.points,'一起做做看。'+c.activity]);break}case'sci-practice':if(SCI_COURSES.courses.some(c=>c.id===sciCourse)){stopEnglish();subject='science';start('lesson')}break;case'sci-planet':{const i=Number(b.dataset.index);if(Number.isInteger(i)&&i>=0&&i<8){sciPlanet=i;stopEnglish();render()}break}case'sci-planet-read':{const p=SCI_COURSES.planets[sciPlanet];speakChinese(p.name+'。由靠近太陽到較遠排列，是第'+p.order+'顆行星。'+p.fact);break}case'guide-open':guideOpen=true;render();break;case'guide-close':closeGuide();break;case'recovery-open':newParentChallenge();parentResetOpen=true;render();break;case'recovery-question':newParentChallenge();render();break;case'recovery-back':parentChallenge=null;parentResetOpen=false;render();break;case'dict-open':dictExam=null;navigate('dictation');break;case'dict-back':stopEnglish();dictExam=null;subject='chinese';navigate('select');break;case'dict-setup':stopEnglish();dictExam=null;render();window.scrollTo(0,0);break;case'dict-start':startDictation();break;case'dict-play':playDictation();break;case'dict-stop':stopEnglish();break;case'dict-prev':if(dictExam&&dictExam.index>0){stopEnglish();dictExam.index--;render()}break;case'dict-next':if(dictExam){stopEnglish();if(dictExam.index<dictExam.items.length-1)dictExam.index++;else dictExam.answers=true;render();window.scrollTo(0,0)}break;case'dict-resume':if(dictExam){dictExam.answers=false;render()}break;case'dict-word':{const allowed=dictSource().some(({vocab:v})=>[...v.characters,...v.recognition,...v.words].includes(b.dataset.word));if(allowed)speakChinese(b.dataset.word);break}case'times-open':subject='math';navigate('times');break;case'times-back':subject='math';navigate('select');break;case'times-row':{const n=Number(b.dataset.row);if(Number.isInteger(n)&&n>=0&&n<=9){timesRow=n;timesRevealed.clear();stopEnglish();render()}break}case'times-hide':timesHidden=!timesHidden;timesRevealed.clear();stopEnglish();render();break;case'times-reveal':{const a=Number(b.dataset.a),n=Number(b.dataset.b);if(a>=1&&a<=9&&n>=1&&n<=9){timesRevealed.add(a+'-'+n);render()}break}case'times-speak':{const a=Number(b.dataset.a),n=Number(b.dataset.b);if(a>=1&&a<=9&&n>=1&&n<=9)speakChinese(a+'乘以'+n+(!timesHidden||timesRevealed.has(a+'-'+n)?'等於'+a*n:'等於多少？'));break}case'times-stop':stopEnglish();break;case'times-practice':subject='math';start('times');break;case'cn-semester':if(['upper','lower'].includes(b.dataset.semester)){cnSemester=b.dataset.semester;cnLesson='all';stopEnglish();render();window.scrollTo(0,0)}break;case'cn-pick':if(CN.lessons.some(l=>l.id===b.dataset.lesson&&l.semester===cnSemester)){cnLesson=b.dataset.lesson;stopEnglish();render();window.scrollTo(0,0)}break;case'cn-read-word':if(CN.words.some(w=>w[0]===b.dataset.word))speakChinese(b.dataset.word);break;case'cn-read-story':{const lesson=CN.lessons.find(l=>l.id===cnLesson);if(lesson)speakChinese(lesson.story);break}case'nav-home':navigate('home');break;case'nav-handwrite':navigate('handwrite');break;case'nav-parent':navigate('parent');break;case'lock-parent':recoveryPlain='';parentResetOpen=false;parentUnlocked=false;render();toast('家長區已鎖定。');break;case'rec-start':if(parentUnlocked)recordClip(recSym);break;case'rec-play':playClipOr('zy:'+recSym,()=>toast('這個符號還沒有錄音'));break;case'rec-del':if(parentUnlocked)AudioStore.del('zy:'+recSym).then(()=>{toast('已刪除錄音');render()});break;case'rec-select':recSym=b.dataset.sym;render();break;case'zh-voice-test':speakChinese('小明從 1 樓走到 3 樓，要爬幾層樓梯？');break;case'ptab':{const t=b.dataset.tab;if(PARENT_TABS.some(x=>x[0]===t)){parentTab=t;render();document.querySelector('.ptab-nav')?.scrollIntoView({block:'start'})}break}case'nav-login':navigate('login');break;case'login-pick':pickPlayer(b.dataset.id);break;case'nav-players':navigate('players');break;case'switch-player':switchPlayer(b.dataset.id);break;case'set-theme':{const t=b.dataset.theme;if(THEMES[t]){activeProfile().theme=t;saveProfiles();render()}break}case'delete-player':if(parentUnlocked)deletePlayer(b.dataset.id);break;case'speak-q':speakQuestion();break;case'speak-zh-sound':speakZhSound();break;case'zy-cards':subject='zhuyin';zyIndex=0;navigate('zhuyin');break;case'zy-back':subject='zhuyin';navigate('select');break;case'zy-select':{const i=Number(b.dataset.index);if(Number.isInteger(i)&&i>=0&&i<37){zyIndex=i;render();playZySymbol(ZHUYIN[zyIndex].sym)}break}case'zy-prev':if(zyIndex>0){zyIndex--;render();playZySymbol(ZHUYIN[zyIndex].sym)}break;case'zy-next':if(zyIndex<36){zyIndex++;render();playZySymbol(ZHUYIN[zyIndex].sym)}else{subject='zhuyin';navigate('select')}break;case'zy-play-answer':if(session&&feedback){const q=session.items[session.idx];if(q?.zyAnswerSym)playZySymbol(q.zyAnswerSym)}break;case'prefer-parent':break;case'zy-sound':playZySymbol(ZHUYIN[zyIndex].sym);break;case'zy-word':speakChinese(ZHUYIN[zyIndex].word);break;case'choose-sub':{const sb=b.dataset.subject;if(SUBJECT_KEYS.includes(sb)){subject=sb;navigate('select')}break}case'review-sub':{const sb=b.dataset.subject;if(SUBJECT_KEYS.includes(sb)){subject=sb;if(!dueReviews(sb).length){toast('目前沒有到期的錯題。');break}start('review')}break}case'choose-english':subject='english';navigate('select');break;case'choose-math':subject='math';navigate('select');break;case'alphabet':subject='english';alphaIndex=0;navigate('alphabet');break;case'alpha-back':subject='english';navigate('select');break;case'alpha-select':{stopEnglish();const i=Number(b.dataset.index);if(Number.isInteger(i)&&i>=0&&i<26){alphaIndex=i;render()}break}case'alpha-prev':stopEnglish();alphaIndex=Math.max(0,alphaIndex-1);render();break;case'alpha-next':stopEnglish();if(alphaIndex<25){alphaIndex++;render()}else{subject='english';navigate('select');toast('你看完 A～Z 了！想再聽一次或挑戰一回合都可以。')}break;case'alpha-name':playEnglish(ALPHABET[alphaIndex].upper);break;case'alpha-word':playEnglish(ALPHABET[alphaIndex].word);break;case'alpha-handwrite':handTab='english';handMode='letter';handLetter=alphaIndex;navigate('handwrite');break;case'alpha-repeat':playEnglish(ALPHABET[alphaIndex].word+'. '+ALPHABET[alphaIndex].word+'.',.92);break;case'voice-test':playEnglish('ball');break;case'voice-test-apple':playEnglish('apple');break;case'alpha-quiz':subject='english';start('letters');break;case'start':if(b.dataset.mode==='review'&&!dueReviews(subject).length){toast('目前沒有到期的錯題。');break;}start(b.dataset.mode);break;case'review-english':subject='english';start('review');break;case'review-math':subject='math';start('review');break;case'hint':if(session&&!feedback){session.usedHint=true;render()}break;case'quiz-handwrite':handQuizOpen=!handQuizOpen;handAnswerInk=[];handOcrResult='';handResult='';clearAdvance();render();break;
 case'hand-tab-english':handTab='english';handReset();render();break;
 case'hand-tab-math':handTab='math';handReset();render();break;
 case'hand-mode-letter':handMode='letter';handReset();render();break;
 case'hand-mode-word':handMode='word';handReset();render();break;
 case'hand-prev':if(handMode==='letter')handLetter=(handLetter+25)%26;else handWord=(handWord+handWordPool().length-1)%handWordPool().length;handReset();render();break;
 case'hand-next':if(handMode==='letter')handLetter=(handLetter+1)%26;else handWord=(handWord+1)%handWordPool().length;handReset();render();break;
 case'hand-ocr-select':{const w=b.dataset.word;if(!w||!handOcrCandidates.includes(w))break;const input=document.getElementById('hw-check-input');if(input)input.value=w;handOcrResult='✍️ 已選擇字庫候選：'+w+'。請核對你的筆跡後，再按下方核對。';const status=document.getElementById('hw-ocr-result');if(status)status.textContent=handOcrResult;break;}case'hand-math-next':handMath=Object.assign(handCalculation(),{practiceGrade:grade(),practiceLevel:effectiveLevel('math')});handReset();render();break;case'hand-recognize':handRecognize();break;case'hand-answer-undo':if(handAnswerInk.length)handAnswerInk.pop();clearHandRecognition();{const c=document.getElementById('hw-answer-canvas');if(c)paintHandCanvas(c)}break;case'hand-answer-clear':handAnswerInk.length=0;clearHandRecognition();{const c=document.getElementById('hw-answer-canvas');if(c)paintHandCanvas(c)}returnToWritingPad('hw-answer-canvas');break;
 case'hand-math-explain':handSolution=!handSolution;render();break;case'hand-zoom':resizeHandPad(false);break;case'hand-answer-zoom':resizeHandPad(true);break;
 case'hand-listen':playEnglish(currentHandTarget());break;
 case'hand-clear':handInk.length=0;clearHandRecognition();handActivePointer=null;{const c=document.getElementById('hw-canvas');if(c)paintHandCanvas(c)}returnToWritingPad('hw-canvas');break;
 case'hand-undo':if(handInk.length)handInk.pop();clearHandRecognition();handActivePointer=null;{const c=document.getElementById('hw-canvas');if(c)paintHandCanvas(c)}break;
 case'stay-feedback':clearAdvance();b.closest('.auto-next-hint').textContent='📖 慢慢看，準備好再按下一題。';break;case'answer':stopEnglish();answer(Number(b.dataset.choice));break;case'next':stopEnglish();next();break;case'speak':speak();break;case'speak-slower':speakSlower();break;case'speak-answer':if(session&&feedback&&session.mode==='use')playEnglish(session.items[session.idx].answer);break;case'transcript':document.getElementById('transcript')?.classList.toggle('hidden');break;case'quit':navigate('select');toast(storageIssue?'進度尚未成功儲存，請先保留這個畫面。':'已暫停，可回首頁按「接著做」。');break;case'again':if(finished){const s=finished;subject=s.subject;start(s.mode)}break;case'save-reflection':{const val=document.getElementById('reflection')?.value.trim();if(!val){toast('還沒寫心得，也可以跳過喔。');break}data.reflections.push({date:new Date().toISOString(),text:val.slice(0,160)});data.reflections=data.reflections.slice(-100);if(save()){document.getElementById('reflection').value='';toast('已在這台裝置儲存小心得！');}break}case'export-previous':exportRawHistory(true);break;case'export-raw':exportRawHistory();break;case'export':if(parentUnlocked)exportJson();break;case'import':if(parentUnlocked)document.getElementById('import-file')?.click();break;case'print':if(parentUnlocked)window.print();break;case'reset':if(parentUnlocked&&confirm('確定清除這台裝置的所有練習紀錄與心得嗎？此操作無法還原。')){if(!save(structuredClone(DEFAULT)))break;render();toast('已清除本機練習紀錄。')}break;default:break}});
app.addEventListener('change',async e=>{const el=e.target;if(el.id!=='import-file'||!parentUnlocked)return;const file=el.files?.[0];if(!file)return;try{if(file.size>2_000_000)throw new Error('檔案超過2MB');const obj=JSON.parse(await file.text());if(!['小小探索學院','全壘打雙軌學院'].includes(obj.app)||!Array.isArray(obj.sessions)||!Array.isArray(obj.reflections)||!obj.settings)throw new Error('格式不符');if(!confirm('將匯入到「'+activeProfile().name+'」'+(obj.profile?.name?'，備份來源是「'+String(obj.profile.name).slice(0,12)+'」':'')+'，並取代此孩子目前的紀錄。其他孩子與錄音不受影響。確定繼續嗎？'))return;const sessions=obj.sessions.slice(-300).map(cleanHistorySession).filter(Boolean);const reflections=obj.reflections.slice(-100).map(cleanHistoryReflection).filter(Boolean);const imported={settings:normalizeSettings(obj.settings),sessions,reflections,reviewQueue:sanitizeReviewQueue(obj.reviewQueue),recent:cleanRecent(obj.recent)};if(!save(imported,{repair:true}))return;render();toast('練習紀錄已匯入。')}catch(err){toast('無法匯入：'+err.message)}finally{el.value=''}});
// No voice/engine selector: device speech is always used; fallback MP3 only for unavailable devices.
app.addEventListener('change',e=>{const x=e.target;if(x.dataset.action==='dict-kind'){if(['char','word','mix'].includes(x.value))dictKind=x.value;dictExam=null;render();return}if(x.dataset.action==='dict-count'){const n=Number(x.value);if([0,10,20].includes(n))dictCount=n;dictExam=null;render();return}if(x.dataset.action==='cn-lesson'){if(x.value==='all'||CN.lessons.some(l=>l.id===x.value&&l.semester===cnSemester)){cnLesson=x.value;stopEnglish();render();window.scrollTo(0,0)}return}if(x.dataset.action==='review-enabled'){if(!parentUnlocked)return;data.settings.reviewEnabled=x.checked;const saved=save();render();if(saved)toast(x.checked?'已開啟複習排程':'已暫停複習排程（原紀錄仍保存）');return}if(x.dataset.action==='auto-next'){if(!parentUnlocked){toast('請先解鎖家長區。');return}data.settings.autoNext=x.checked;if(save())toast(x.checked?'已開啟：答對自動下一題':'已關閉：每題都手動按下一題');return}if(x.dataset.action==='prefer-parent'){if(!parentUnlocked)return;try{localStorage.setItem(PREFER_PARENT_KEY,x.checked?'1':'0')}catch(_){}toast(x.checked?'有錄音的符號會播放家長錄音':'一律播放內建音檔');return}if(x.dataset.action==='zh-voice'){try{localStorage.setItem(VOICE_PREF_KEY,x.value)}catch(_){}speakChinese('這是新的朗讀聲音');return}if(x.dataset.action==='round-size'){if(!parentUnlocked)return;data.settings.roundSize=Number(x.value)||8;if(save())toast('每回合 '+data.settings.roundSize+' 題');return}if(x.dataset.action==='auto-read'||x.dataset.action==='sound'){if(!parentUnlocked)return;data.settings[x.dataset.action==='auto-read'?'autoRead':'sound']=x.checked;if(save())toast(x.checked?'已開啟':'已關閉');return}if(x.dataset.action!=='level')return;const sub=x.dataset.subject,lv=Number(x.value);if(!parentUnlocked||!SUBJECT_KEYS.includes(sub)||![1,2,3,4].includes(lv))return;data.settings[sub]=lv;const saved=save();render();if(saved)toast('已調整'+subName(sub)+'難度為第 '+lv+' 級。')});
if('speechSynthesis' in window){try{window.speechSynthesis.addEventListener('voiceschanged',populateSpeechVoices);window.speechSynthesis.addEventListener('voiceschanged',()=>{if(page==='parent'&&!document.activeElement?.closest?.('form'))render()},{once:true})}catch(_){}}
document.addEventListener('visibilitychange',()=>{if(document.hidden){stopEnglish();clearAdvance();if(page==='parent'){recoveryPlain='';parentUnlocked=false;render()}}});

document.addEventListener('keydown',e=>{if(!guideOpen)return;if(e.key==='Escape'){e.preventDefault();closeGuide();return}if(e.key==='Tab'){const b=document.getElementById('guide-close');if(b){e.preventDefault();b.focus()}}});

window.addEventListener('hashchange',()=>{if(location.hash==='#home')navigate('home')});

// Space styling shares the existing general learning curriculum.
WORLD_INFO.space={name:'小小探索學院',sub:'LEARN × EXPLORE',icon:'🚀',footer:'🚀 和孩子一起探索知識的宇宙',step:'STEP 01 · 探索第一站',go:'出發'};
WORLD_SCORE.space={unit:'顆能量',big:'枚徽章',bigIcon:'🏅',slot:'⚡',empty:'☆',line:c=>'今天答對 <b>'+c+'</b> 題＝收集 <b>'+c+'</b> 顆能量',next:n=>'再答對 '+n+' 題，就能獲得一枚探索徽章！',rule:'每答對 1 題獲得 1 顆能量，集滿 4 顆換 1 枚探索徽章。',today:'今日探索徽章',round:c=>'🚀 這回合收集了 '+c+' 顆能量'};
const spaceWords=t=>String(t).split('貓頭鷹老師').join('領航員').split('兔子隊').join('火箭隊').split('熊熊隊').join('星際隊').split('松鼠隊').join('月球隊').split('森林').join('太空基地').split('樹屋').join('基地').split('橡實').join('能量晶石').split('小動物').join('探險隊員').split('動物小隊').join('探索小隊').split('動物').join('探索').split('🐾').join('🚀');
WORLD_NAMES.space=['小宇','阿哲','小星','小安','阿凱','小晴','小光','小傑','小樂'];
WORLD_PATTERN.space=['🚀','🪐','⭐','🌙','🛰️','☄️'];
WORLD_COUNT.space={'🚀':'火箭','🪐':'行星','⭐':'星星','🌙':'月亮','🛰️':'衛星','🤖':'機器人','🔭':'望遠鏡','⚡':'能量'};
WORLD_TRUTH.space=['整理好了觀測紀錄','找到了遺失的工具','檢查好了機器人','收好了探索地圖','觀察到了月亮'];
WORLD_ORDER.space=WORLD_ORDER.animals.slice();
WORLD_ASSIGN.space=WORLD_ASSIGN.animals.slice();
WORLD_PHRASES.space=WORLD_PHRASES.animals.map(([a,b])=>[a,spaceWords(b)]);
WORLD_BALL.space='能量晶石';
WORLD_MODE_TEXT.space={math:{calc:['計算任務','從加減到乘除，一步一步完成計算任務。','🧮'],story:['探索應用題','把生活與探索情境變成算式。','🚀'],score:['任務計分板','看計分板，理解差距與總分。','🏆']},logic:{lineup:['小隊推理','從順序、座位和條件線索推出答案。','🛰️'],rules:['規則與推論','認識生活規則，練習因果推理。']},english:{listening:['探索小耳朵'],vocab:[null,null,'🚀'],use:[null,'把單字放進生活和探索情境，理解後再選。']}};
WORLD_META.space={math:{tile:'計算、探索應用題、計分板'},logic:{levelNote:'從 3 人順序推理開始，逐步加入更多條件。',tile:'小隊推理、數獨、誰說謊、找規律',route:'找規律 → 分類 → 小隊推理 → 規則與因果',desc:'像探險家一樣找線索，試著說出自己的理由。',tip:'先找確定的線索，再一步步排除不可能。'},science:{desc:'從身邊的觀察開始，探索身體、力與運動、天氣和實驗。'}};
WORLD_BADGES.space=Object.fromEntries(Object.entries(WORLD_BADGES.animals).map(([k,v])=>[k,[spaceWords(v[0]),v[1]]]));
Object.assign(WORLD_BADGES.space,{'debut':['探索啟航','完成第一回合練習'],'all-four':['全能探險家','英文、數學、邏輯、科學都練過'],'perfect':['任務全對','一回合全部答對'],'runs10':['十枚探索徽章','累積獲得 10 枚探索徽章'],'runs50':['五十枚探索徽章','累積獲得 50 枚探索徽章'],'runs100':['星際探險家','累積獲得 100 枚探索徽章'],'streak7':['一週探索家','連續 7 天都有練習'],'logic5':['推理領航員','完成 5 回合邏輯練習'],'science5':['小小科學家','完成 5 回合科學練習']});

installScienceCourses();
for(const meta of Object.values(WORLD_META))meta.science={...(meta.science||{}),tile:'先學習、太空、身體、自然與實驗',desc:'先到科學小教室聽讀，再練習身體、力與運動、自然、實驗與太空。'};

// Same-device drafts share the history write, so answers/review scheduling and progress save atomically.
// Bump the curriculum key after a future question/answer audit; obsolete drafts are never resumed.
const DRAFT_CURRICULUM='20261020-audit',DRAFT_FORMAT=1;
let restoringDraft=false;
function compactInk(raw){
 if(!Array.isArray(raw))return [];
 const strokes=raw.slice(-240).filter(Array.isArray),limit=Math.max(2,Math.floor(10000/Math.max(1,strokes.length)));
 return strokes.map(stroke=>{const good=stroke.filter(p=>Array.isArray(p)&&p.length===2&&p.every(v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=1));
 const n=Math.min(good.length,limit,300);return Array.from({length:n},(_,i)=>good[n===1?0:Math.round(i*(good.length-1)/(n-1))].map(v=>Math.round(v*10000)/10000));}).filter(s=>s.length);
}
function pendingPractice(){
 const d=data.practiceDraft;
 try{
  if(!d||d.v!==DRAFT_FORMAT||d.curriculum!==DRAFT_CURRICULUM||d.profile!==activeProfile().id||d.grade!==grade())return null;
  const x=d.session;if(!x||!canPractice(x.subject,x.mode)||![1,2,3,4].includes(x.level)||(x.mode!=='times'&&x.level>effectiveLevel(x.subject,x.level)))return null;
  if(!Array.isArray(x.items)||x.items.length<1||x.items.length>10||!Number.isInteger(x.idx)||x.idx<0||x.idx>=x.items.length)return null;
  const items=x.items.map(q=>{const safe=safeReviewQuestion(q);if(!safe)return null;if(typeof q.reviewId==='string')safe.reviewId=q.reviewId.slice(0,75);if([1,2,3,4].includes(q.reviewLevel))safe.reviewLevel=q.reviewLevel;return safe});if(items.some(q=>!q))return null;
  if(!Array.isArray(x.attempts)||x.attempts.length!==x.idx+(d.feedback?1:0)||!x.attempts.every(t=>t&&typeof t.correct==='boolean'))return null;
  let fb=null;if(d.feedback){const q=items[x.idx],selected=d.feedback.selected;if(!q.choices.includes(selected))return null;fb={selected,correct:selected===q.answer};if(x.attempts[x.attempts.length-1].correct!==fb.correct)return null;}
  const attempts=x.attempts.map((t,i)=>({skill:items[i].skill,correct:t.correct,hintUsed:!!t.hintUsed,review:!!items[i].reviewId,concept:items[i].concept||'',level:items[i].reviewLevel||x.level}));
  const missed=attempts.flatMap((t,i)=>{const q=items[i];return t.correct?[]:[{main:(q.courseLabel?q.courseLabel+'\n':'')+(q.isListening?q.speech:q.main)+(q.second?'\n'+q.second:''),answer:q.answer,explain:q.explain}]});
  return {session:{subject:x.subject,mode:x.mode,level:x.level,items,idx:x.idx,attempts,missed,correct:attempts.filter(t=>t.correct).length,usedHint:!!x.usedHint},feedback:fb,ink:compactInk(d.ink),answerInk:compactInk(d.answerInk),open:!!d.open};
 }catch(_){return null}
}
function pendingWriting(){
 const d=data.writingDraft;
 if(!d||d.v!==DRAFT_FORMAT||d.curriculum!==DRAFT_CURRICULUM||d.profile!==activeProfile().id||d.grade!==grade()||d.theme!==activeProfile().theme)return null;
 if(!['english','math'].includes(d.tab)||!['letter','word'].includes(d.mode)||!Number.isInteger(d.letter)||d.letter<0||d.letter>25||!Number.isInteger(d.word)||d.word<0||d.word>=handWordPool().length)return null;
 const math=safeReviewQuestion(d.math);if(!math||d.mathLevel!==effectiveLevel('math'))return null;
 return {...d,math:Object.assign(math,{practiceGrade:grade(),practiceLevel:d.mathLevel}),ink:compactInk(d.ink),answerInk:compactInk(d.answerInk)};
}
function persistOpenDraft(){
 if(restoringDraft)return false;
 if(page==='quiz'&&session&&session.idx<session.items.length){data.practiceDraft={v:DRAFT_FORMAT,curriculum:DRAFT_CURRICULUM,profile:activeProfile().id,grade:grade(),session:structuredClone(session),feedback:feedback?{...feedback}:null,ink:compactInk(handInk),answerInk:compactInk(handAnswerInk),open:handQuizOpen};return save();}
 if(page==='handwrite'&&handMath){data.writingDraft={v:DRAFT_FORMAT,curriculum:DRAFT_CURRICULUM,profile:activeProfile().id,grade:grade(),theme:activeProfile().theme,tab:handTab,mode:handMode,letter:handLetter,word:handWord,math:handMath,mathLevel:effectiveLevel('math'),ink:compactInk(handInk),answerInk:compactInk(handAnswerInk),solution:handSolution};return save();}
 return false;
}
function resumePractice(){const d=pendingPractice();if(!d){toast('這份進度已不適用目前教材或年級，請開始新的練習。');return false;}
 clearAdvance();stopEnglish();session=d.session;feedback=d.feedback;subject=session.subject;mode=session.mode;handInk=d.ink;handAnswerInk=d.answerInk;handQuizOpen=d.open;handOcrResult='';handResult='';finished=null;parentUnlocked=false;page='quiz';window.scrollTo(0,0);render();focusLesson();toast('已接著上次的進度；準備好再繼續。');return true;
}
function resumeMarkup(){const d=pendingPractice(),w=pendingWriting();if(!d&&!w)return '';
 const q=d?.session,m=q&&MODES[q.subject].find(m=>m.id===q.mode);
 return '<section class="card" style="margin-bottom:20px" aria-label="上次的練習"><h2>🌱 接著上次的練習</h2><p class="note">進度保留在這台裝置與目前瀏覽器；未完成的回合還不計入成績。</p>'+(q?'<p><strong>'+h(subName(q.subject)+'・'+m.name)+'</strong> · 第 '+(q.idx+1)+'／'+q.items.length+' 題'+(d.feedback?'（已作答，接著看解析）':'')+'</p><button type="button" class="btn btn-dark" data-action="resume-practice">▶ 接著做</button>':'')+(w?'<p>✍️ 手寫草稿也已保留。</p><button type="button" class="btn btn-outline" data-action="nav-handwrite">繼續手寫 →</button>':'')+'</section>';
}
const homeWithoutDraft=home;home=function(){return resumeMarkup()+homeWithoutDraft()};
const selectWithoutDraft=selectView;selectView=function(){return (pendingPractice()?.session.subject===subject?resumeMarkup():'')+selectWithoutDraft()};
const renderWithoutDraft=render;render=function(){renderWithoutDraft();persistOpenDraft()};
const navigateWithoutDraft=navigate;navigate=function(target){persistOpenDraft();const writing=target==='handwrite'&&page!=='alphabet'?pendingWriting():null;
 restoringDraft=true;try{navigateWithoutDraft(target)}finally{restoringDraft=false}
 if(writing){handTab=writing.tab;handMode=writing.mode;handLetter=writing.letter;handWord=writing.word;handMath=writing.math;handInk=writing.ink;handAnswerInk=writing.answerInk;handSolution=!!writing.solution;render()}else if(target==='handwrite')persistOpenDraft();
};
const switchWithoutDraft=switchPlayer;switchPlayer=function(id){persistOpenDraft();restoringDraft=true;try{switchWithoutDraft(id)}finally{restoringDraft=false}};
const startWithoutDraft=start;start=function(m){const d=pendingPractice();if(d&&typeof confirm==='function'&&!confirm('還有一回合未完成。開始新回合會取代它；想接著做，請按取消後選「接著做」。'))return;startWithoutDraft(m)};
const modesWithoutGradeCopy=visibleModes;visibleModes=function(sub){return modesWithoutGradeCopy(sub).map(m=>{
 if(sub!=='math'||grade()==='g3')return m;const g=grade(),copy={
 calc:{label:g==='g2'?'加減與乘法':'加減練習',desc:g==='g2'?'練習100以內加減與九九乘法。':'練習20以內加減法。'},
 story:{desc:g==='g1'?'用20以內加減法，解決放進、拿走的生活問題。':'用加減法理解購物、數量與生活情境。'},
 score:{desc:'從簡單計分紀錄，練習總數與分差。'},
 reason:{desc:'找出增加、減少與分組的線索，練習一到兩步解題。'},
 pattern:{desc:'找數字增加或減少的規律，認識十和一，練習重複加法。'},
 measure:{label:'長度・錢幣・圖形',desc:'練習長度加減、10元硬幣、數四條邊與每排磁磚的數量。'}
 };return {...m,...copy[m.id]};})};
app.addEventListener('click',e=>{const action=e.target.closest('[data-action]')?.dataset.action;if(action==='resume-practice')resumePractice();else if(action&&/^hand-(?:clear|undo|answer-clear|answer-undo)$/.test(action))persistOpenDraft();});
window.addEventListener('pagehide',persistOpenDraft);
document.addEventListener('visibilitychange',()=>{if(document.hidden)persistOpenDraft()});

try{if(!sessionStorage.getItem(PICKED_KEY))page='login'}catch(_){page='login'}
render();
populateSpeechVoices();
})();
