const fs=require('node:fs'),crypto=require('node:crypto');
const files=["index.html","assets/app.js","check-tablet.cjs","TABLET_COMPATIBILITY.md"];
if(process.argv[2]==='manifest')console.log(JSON.stringify(files.map((path,index)=>{const b=fs.readFileSync(path);return {path,index,length:b.toString('base64').length,sha:crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length+String.fromCharCode(0)),b])).digest('hex')};})));
else{const path=files[Number(process.argv[2])],start=Number(process.argv[3]);if(!path||!Number.isInteger(start)||start<0)throw Error('Invalid read');process.stdout.write(fs.readFileSync(path).toString('base64').slice(start,start+20000));}
