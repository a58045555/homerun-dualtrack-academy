# 小小探索學院・專案交接

## 一、現在的狀態（2026-10-22，台灣）

| 項目 | 已確認內容 |
| --- | --- |
| 正式站 | https://homerun-dualtrack-academy.vercel.app/ |
| Repository | https://github.com/a58045555/homerun-dualtrack-academy |
| 最新業務程式提交 | 92acf65ce0fce477a4183f30c14e549a4c811488 |
| 正式版標記 | 2026-10-22-tablet-compat |
| Vercel | GitHub提交狀態已回success，正式HTML與app.js和交接來源逐位元相同；詳見STATUS.json |
| 尚未確認 | 使用者實際平板的型號、系統版本、瀏覽器和錯誤畫面；不等於實機已驗證成功 |
| 本機Git | 原工作區HEAD仍為0f65acc，git status回報非工作樹。不可據此reset或覆蓋工作檔；ZIP排除了.git |

前一則對話中曾因自動部署未出現、Vercel連線403而回報尚未上線。準備本交接時重新確認，自動部署已完成，正式站已是修正版。請使用本節和STATUS.json，不要沿用「尚未發布」的舊結論。

Vercel專案為 homerun-dualtrack-academy，原管理團隊slug為 srxbykfmr8-1971。既有連線讀取該團隊曾被拒絕；沒有把token、cookies、登入資訊或授權寫進ZIP。這個403不代表公開網站不可連線。

## 二、使用者的既定需求

- 給孩子學習，手機和平板要可直接用。回覆以繁體中文、簡單可執行為主。
- 改名「小小探索學院」，包含瀏覽器標題與頁面品牌。保留四風格，不恢復舊棒球配色選項。
- 年級：幼兒園大班、一年級、二年級、三年級以上。目前三年級以上仍為共用能力題庫，不是完整逐年級課綱。
- 國語以康軒115學年度二年級為對照，提供生字圈詞及播音後在紙上聽寫；不能把二下原創先修說成正式康軒內容。
- 九九乘法1～9一次完整納入，獨立且不分難度。保留81組、全混合練習和錯題。
- 首次使用說明、首頁家長區、孩子管理。忘記家長密碼只需數學驗證，不需要Email、手機或雲端帳號。
- 科學要能先學習再答題，包含太空與星體。現有12課，其中8課太空，每課3題；另有8行星互動卡。
- 先免費，不做贊助、付費、訂閱或Apple上架。
- 優先完成的「中斷續作」及「低年級說明」已上線，恢復原題、答題回饋與筆跡，不跨裝置同步。

## 三、先前完成的修正

1. 固定題庫逐項語意審核與來源核對：國語、注音、英文、科學、邏輯；詳細歷程在CURRICULUM_AUDIT.md。
2. 低年級出題入口與複習、手寫一致套用限制；大班以數數／10內圖像題，一年級一般計算與生活題20內加減，二年級一般計算不直接出除法算式。九九乘法是明示的延伸例外。
3. 數學和邏輯動態題的獨立驗算與唯一解檢查。修正猜數候選漏99、零用錢先花超支、含兩個問題的單選題、數線方向和真假推理前提。
4. 防止風格替換把「球」改成別物，造成注音、科學或閱讀語意與答案不一致。英文選字加入中文語意，避免多個合理答案。
5. 舊錯題改從現行題庫重建；多音字聽寫用詞語提示及第幾個字，避免孤立單字誤讀。
6. 續作與手寫草稿每位孩子分開存；完成後清除續作，避免重複計分。低年級每回合5／8／10題設定已修正。
7. 平板已知啟動問題：app.js的兩個lookbehind正規表示式常值會使Safari16.4以前在解析時失敗。已改成不需lookbehind的判斷；同時移除Array.at與String.replaceAll依賴。

測試通過不等於所有隨機組合或所有實體平板零錯誤。1045筆稽核記錄是資料物件數，不是1045道不重複題目；動態測試次數也不能當題庫數。

## 四、內容邊界

- 國語：24組課程、312題原創練習；上學期12課對照來源，下學期12組原創先修。
- 教育雲二上清單：216生字、23認讀字、138語詞。曾即時核對12課的字詞順序與分類；證據保存在artifacts/chinese-source-verification.json。
- 原創短文、釋義、例句與題目不是課文全文或出版社原題；無康軒插圖／錄音授權聲明。
- 科學：12課、36課後題、8行星卡。固定科學題229筆包含其他風格新增題，不要將課程題重複計算成額外題量。
- 中文語音主要依裝置；實機聽寫仍應試聽，尤其多音字。家長錄音存在IndexedDB，JSON備份不含錄音和家長密碼。
- 來源、音檔授權與限制：CHINESE_SOURCES.md、SCIENCE_SOURCES.md、audio/ATTRIBUTION.txt、audio/zhuyin/README.md。

## 五、檔案與資料流

| 檔案 | 用途 |
| --- | --- |
| index.html | 啟動fallback、structuredClone降級、載入順序、academy-release與快取版本 |
| assets/app.js | IIFE內全部UI、題庫、演算法、年級規則、儲存、音效、手寫及底部續作包裝 |
| assets/styles.css | 手機／平板／桌面樣式、手寫畫板 |
| assets/chinese-content.js | 國語原創課程／題目 |
| assets/chinese-vocabulary.js | 已核對教材字詞清單 |
| assets/science-courses.js | 陪讀課程與星體卡 |
| curriculum-runtime.cjs | 載入與check.cjs相同的隔離VM，不完整執行舊測試 |
| artifacts/*.json | 內容審核雜湊與教育雲來源證據 |

啟動：index載入三份內容資料→app IIFE→讀取profiles與本機history→套用風格→render。
練習：選孩子／科目→practiceQuestions→年級與難度規則→出題→answer→save與practiceDraft→finish只記一回合。
本網站沒有API或資料庫，外部能力主要是靜態音檔和裝置內建語音；不要為了除錯突然引入後端。

儲存鍵沿用舊名：homerun_profiles_v1；第一個孩子baseball_dualtrack_v1，其他孩子baseball_dualtrack_v1__加id；homerun_parent_pin_v1；__previous為上一份歷史快照。品牌改名不能直接改掉鍵值。
續作格式：DRAFT_FORMAT=1，DRAFT_CURRICULUM=20261020-audit。只有教材語意／正解更新等不相容變動才評估升版，不要因改CSS或語法相容就令草稿失效。

## 六、Claude接手的優先順序

### 立即
1. 驗證ZIP的雜湊與快速測試，先讀目前狀態，不回退已完成的功能。
2. 向使用者取得實際平板與錯誤狀況，確認是否為Safari啟動錯誤、網址／網路問題或按鈕無反應；最好在實體裝置重現。
3. 以原正式網址驗證版本，確認平板修正版有沒有真正改善。若仍失敗，先找第一個失敗邊界，再小範圍修正。

### 之後仍有價值、但尚未完成
- 三年級以上分成各年級，規劃對應教材後再實作；不能把目前共用題庫直接宣稱逐年級匹配。
- 二下康軒115正式清單：等待可核實資料，逐課核對；不能自行假造課名、生字或圈詞。
- 既有備份功能增加合適的定期提醒，而非再造一套備份或未要求的雲端帳號。
- 程式大型IIFE的整理可後續小步做，先保留行為、資料相容性和測試，避免一次重寫。

## 七、驗證與發布原則

TEST_RESULTS.json是本交接重新執行的結果，與較早文件的歷史測試紀錄分開看。check-tablet.cjs是舊API缺失與語法風險的模擬，不是真實Safari引擎或實體iPad測試。

發布使用原GitHub/Vercel專案；沒有必要換網址。若換網域或瀏覽器，localStorage紀錄不會自動跟過去。
確認遠端main與改檔內容→適當回歸測試→檢查目標團隊／專案→發布→等部署成功→實際抓正式站版號和檔案→實測操作，才回報上線。

## 交接時新發現的測試設定問題
完整重跑時，原check-dictation.cjs先require check.cjs，會執行整套測試並遺留page=quiz和未完成的英文session。之後直接呼叫startDictation，會讓render的續作包裝保存舊session，使「整份data不變」斷言失敗；真實UI入口會先navigate到dictation。
本包將該測試改為讀取curriculum-runtime.cjs的新VM並navigate('dictation')，保留原本所有聽寫斷言。runtime只新增navigate測試匯出，網站app.js完全未變。這兩個測試檔的隔離修正只在交接包，尚未提交GitHub。原始檔在handoff/original-tests，初次失敗完整輸出在TEST_RESULTS_INITIAL.json。若改用GitHub新clone，請先比較並套用這兩個測試檔差異。
